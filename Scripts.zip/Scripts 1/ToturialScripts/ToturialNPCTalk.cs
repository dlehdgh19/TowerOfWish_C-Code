using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToturialNPCTalk : MonoBehaviour
{
    public GameObject TalkingCanvas;
    public AudioSource ClickSound;

    private bool Playernearbool;
    // Start is called before the first frame update
    void Start()
    {
        TalkingCanvas.SetActive(false);
        Playernearbool = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.G) && Playernearbool == true &&
            MainCharacterController.Dashingbool == false)
        {
            ToturialPortalManager.CantPressESCbool = true;
            ClickSound.Play();
            MainCharacterController.CharacterCantMovebool = true;
            TalkingCanvas.SetActive(true);
        }
    }

    public void OutofTalkCanvasButton()
    {
        ToturialPortalManager.CantPressESCbool = false;
        ClickSound.Play();
        MainCharacterController.CharacterCantMovebool = false;
        TalkingCanvas.SetActive(false);
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            Playernearbool = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            Playernearbool = false;
        }
    }
}
