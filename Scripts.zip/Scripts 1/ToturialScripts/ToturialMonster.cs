using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ToturialMonster : MonoBehaviour
{
    private int health;
    private SpriteRenderer SR;
    private Animator animator;
    private bool Hitbool;
    private float Hittime;
    private bool CantHitbool = false;

    [SerializeField]
    private GameObject[] Hiteffect;

    [SerializeField]
    private AudioSource[] HitAndDeadAudio;

    /*
        HitAndDeadAudio[0] = Hit1
        HitAndDeadAudio[1] = Hit2
        HitAndDeadAudio[2] = Dead
    */

    // Start is called before the first frame update
    void Start()
    {
        animator = GetComponent<Animator>();
        SR = GetComponent<SpriteRenderer>();
        animator.SetBool("Deadbool", false);
        health = 5;
        SR.color = new Color(1, 1, 1, 1);
        Hittime = 0;
        GetComponent<CapsuleCollider2D>().enabled = true;
    }

    // Update is called once per frame
    void Update()
    {
        if(Hitbool == true && health > 0)
        {
            
            Hittime += Time.deltaTime;
            if(Hittime > 0 && Hittime < 0.15f)
            {
                SR.color = new Color(1, 0, 0, 1);
            }
            if(Hittime > 0.15f)
            {
                SR.color = new Color(1, 1, 1, 1);
                Hittime = 0;
                Hitbool = false;
                CantHitbool = false;
            }
            
        }

        if(Hitbool == true && health <= 0)
        {
            
            EnemyPatrol.Stopbool = true;
            SR.color = new Color(1, 1, 1, 1);
            GetComponent<CapsuleCollider2D>().enabled = false;
            Hittime += Time.deltaTime;
            animator.SetBool("Deadbool", true);
            
            if (Hittime > 1f && Hittime < 4f)
            {
                SR.color = new Color(1, 1, 1, 0);
            }
            if(Hittime > 4f)
            {
                Hittime = 0f;
                SR.color = new Color(1, 1, 1, 1);
                health = 5;
                Hitbool = false;
                animator.SetBool("Deadbool", false);
                GetComponent<CapsuleCollider2D>().enabled = true;
                CantHitbool = false;
                EnemyPatrol.Stopbool = false;
            }
        }

        
    }

    

    private void OnTriggerEnter2D(Collider2D other)
    {
        if ((other.tag == "Slash1" || other.tag == "Slash2" || other.tag == "Slash3"))
        {
            if (CantHitbool == false)
            {
                if (health > 0)
                {
                    Instantiate(Hiteffect[Random.Range(0, 2)], this.gameObject.transform.position, Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360))));
                    HitAndDeadAudio[Random.Range(0, 2)].Play();
                    Hitbool = true;
                    CantHitbool = true;
                    health -= 1;
                }
                
                if(health <= 0)
                {
                    Instantiate(Hiteffect[Random.Range(0, 2)], this.gameObject.transform.position, Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360))));
                    Hitbool = true;
                    CantHitbool = true;
                    HitAndDeadAudio[2].Play();
                }
            }
        }
    }

}
