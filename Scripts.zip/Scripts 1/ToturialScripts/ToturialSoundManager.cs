using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Rendering.Universal;

public class ToturialSoundManager : MonoBehaviour
{
    public AudioSource BGM;
    public AudioSource[] EffectSound;

    public Slider BGMSlider;
    public Slider EffectSlider;
    public Slider GammaSlider;

    public Text BGMText;
    public Text EffectText;
    public Text GammaText;
    public Light2D GlobalLight;
    public Light2D FireLight;
    // Start is called before the first frame update
    void Start()
    {
        BGMSlider.value = SaveThings.BGMVolume;
        EffectSlider.value = SaveThings.EffectVolume;
        GammaSlider.value = SaveThings.GammaVolume;
    }

    // Update is called once per frame
    void Update()
    {
        SaveThings.BGMVolume = (int)BGMSlider.value;
        SaveThings.EffectVolume = (int)EffectSlider.value;
        SaveThings.GammaVolume = (int)GammaSlider.value;
        BGM.volume = BGMSlider.value * 0.01f;
        EffectSound[0].volume = EffectSlider.value * 0.01f;
        EffectSound[1].volume = EffectSlider.value * 0.01f;
        EffectSound[2].volume = EffectSlider.value * 0.01f;
        EffectSound[3].volume = EffectSlider.value * 0.01f;
        EffectSound[4].volume = EffectSlider.value * 0.01f;
        EffectSound[5].volume = EffectSlider.value * 0.01f;
        EffectSound[6].volume = EffectSlider.value * 0.01f;
        EffectSound[7].volume = EffectSlider.value * 0.01f;
        EffectSound[8].volume = EffectSlider.value * 0.01f;
        EffectSound[9].volume = EffectSlider.value * 0.01f;
        GlobalLight.intensity = 0.1f + GammaSlider.value * 0.018f;
        FireLight.intensity = 0.1f + +GammaSlider.value * 0.027f;

        BGMText.text = ((int)BGMSlider.value).ToString() + "%";
        EffectText.text = ((int)EffectSlider.value).ToString() + "%";
        GammaText.text = ((int)GammaSlider.value).ToString() + "%";
    }
}
