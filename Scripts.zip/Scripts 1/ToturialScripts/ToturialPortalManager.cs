using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ToturialPortalManager : MonoBehaviour
{
    [SerializeField]
    private GameObject MainCharacter;

    public GameObject StartCanvas;
    public AudioSource ClickButtonSound;

    private bool CharacterInbool;
    public static bool Screenbool = false;
    public GameObject SettingCanvas;
    private bool Settingbool = false;

    public Slider BGMSlider;
    public Slider EffectSlider;
    public Slider GammaSlider;

    public GameObject TalkingCanvas;

    public static bool CantPressESCbool = false;
    // Start is called before the first frame update
    void Start()
    {
        CharacterInbool = false;
        StartCanvas.SetActive(false);
        Screenbool = false;
        SettingCanvas.SetActive(false);
        Settingbool = false;
        TalkingCanvas.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        if(Input.GetKeyDown(KeyCode.UpArrow) && CharacterInbool == true &&
            MainCharacter.GetComponent<Rigidbody2D>().velocity.x == 0 && MainCharacter.GetComponent<Rigidbody2D>().velocity.y == 0
            && MainCharacterController.Dashingbool == false)
        {
            MainCharacterController.CharacterCantMovebool = true;
            TalkingCanvas.SetActive(false);
            StartCanvas.SetActive(true);
            CharacterInbool = false;
        }

        if(Input.GetKeyDown(KeyCode.Escape) && CantPressESCbool == false)
        {
            if (Settingbool == false)
            {
                
                ClickButtonSound.Play();
                SettingCanvas.SetActive(true);
                Settingbool = true;
            }
            else if (Settingbool == true)
            {
                
                SaveThings.BGMVolume = (int)BGMSlider.value;
                SaveThings.EffectVolume = (int)EffectSlider.value;
                SaveThings.GammaVolume = (int)GammaSlider.value;

                ClickButtonSound.Play();
                SettingCanvas.SetActive(false);
                Settingbool = false;
            }

        }

        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            CharacterInbool = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            CharacterInbool = false;
        }
    }

    public void StartGameButton()
    {
        
        ClickButtonSound.Play();
        Screenbool = true;
        StartCanvas.SetActive(false);
    }
    public void SettingCanvasOnButton()
    {
        if (Settingbool == false)
        {

            ClickButtonSound.Play();
            SettingCanvas.SetActive(true);
            Settingbool = true;
        }
        else if (Settingbool == true)
        {

            SaveThings.BGMVolume = (int)BGMSlider.value;
            SaveThings.EffectVolume = (int)EffectSlider.value;
            SaveThings.GammaVolume = (int)GammaSlider.value;

            ClickButtonSound.Play();
            SettingCanvas.SetActive(false);
            Settingbool = false;
        }
    }

    public void SettingCanvasOffButton()
    {
        SaveThings.BGMVolume = (int)BGMSlider.value;
        SaveThings.EffectVolume = (int)EffectSlider.value;
        SaveThings.GammaVolume = (int)GammaSlider.value;
        ClickButtonSound.Play();
        SettingCanvas.SetActive(false);
        Settingbool = false;
    }
}
