using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayButtonManager : MonoBehaviour
{

    public GameObject MainCharacter;
    public GameObject MainCamera;
    public static Vector3 MainCharacterPosition;

    public static bool CantPressPausebool;
    public GameObject PauseCanvas;
    public GameObject SettingCanvas;
    public GameObject MainMenuAskingCanvas;
    public GameObject ExitAskingCanvas;
    public GameObject HowtoPlayCanvas;
    public Scrollbar HowtoPlayScrollbar;

    private bool Pausebool;
    public static bool Scenebool;

    public AudioSource ClickSound;
    private bool CharacterPositionbool;

    public static int nPCProgressInt;
    public GameObject[] NPCs;
    public GameObject[] Portals;
    public GameObject[] TransparentWall;
    public GameObject[] GodRay;

    public static int BossesInt;
    public GameObject[] Bosses;

    public GameObject PauseButton;
    // Start is called before the first frame update
    void Start()
    {
        Pausebool = false;
        PauseCanvas.SetActive(false);
        SettingCanvas.SetActive(false);
        MainMenuAskingCanvas.SetActive(false);
        ExitAskingCanvas.SetActive(false);
        HowtoPlayCanvas.SetActive(false);
        Scenebool = false;
        CharacterPositionbool = false;
        CantPressPausebool = false;
        HowtoPlayScrollbar.value = 1;
        PauseButton.SetActive(true);
    }

    private void Awake()
    {
        
        if (!PlayerPrefs.HasKey("BossesInt"))   // ���ο� ������ ���۵ɶ�
        {
            for(int i = 0; i < Bosses.Length; i++)
            {
                Bosses[i].SetActive(true);
            }
        }
        if (PlayerPrefs.HasKey("BossesInt"))
        {
            BossesInt = PlayerPrefs.GetInt("BossesInt");

            
            //---------------------------------------------------------------------------------------------
            if (BossesInt == 4)
            {
                Bosses[0].SetActive(false);
                Bosses[1].SetActive(false);
                Bosses[2].SetActive(false);
                Bosses[3].SetActive(false);
                for (int i = 4; i < Bosses.Length; i++)
                {
                    Bosses[i].SetActive(true);
                }
            }
            if (BossesInt == 8)
            {
                Bosses[0].SetActive(false);
                Bosses[1].SetActive(false);
                Bosses[2].SetActive(false);
                Bosses[3].SetActive(false);
                Bosses[4].SetActive(false);
                Bosses[5].SetActive(false);
                Bosses[6].SetActive(false);
                Bosses[7].SetActive(false);
                for (int i = 8; i < Bosses.Length; i++)
                {
                    Bosses[i].SetActive(true);
                }
            }

            if (BossesInt == 12)
            {
                Bosses[0].SetActive(false);
                Bosses[1].SetActive(false);
                Bosses[2].SetActive(false);
                Bosses[3].SetActive(false);
                Bosses[4].SetActive(false);
                Bosses[5].SetActive(false);
                Bosses[6].SetActive(false);
                Bosses[7].SetActive(false);
                Bosses[8].SetActive(false);
                Bosses[9].SetActive(false);
                Bosses[10].SetActive(false);
                Bosses[11].SetActive(false);
                for (int i = 12; i < Bosses.Length; i++)
                {
                    Bosses[i].SetActive(true);
                }
            }
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(MapNPC20_1.FirstEpisodeEndbool == true)
        {
            PauseButton.SetActive(false);
        }
        
        NPCProgressInt();
        if (Input.GetKeyDown(KeyCode.Escape) && StoryScreen.CantPressESCButtonbool == false && CantPressPausebool == false)
        {
            if (Pausebool == false)
            {
                Time.timeScale = 0;
                ClickSound.Play();
                PauseCanvas.SetActive(true);
                Pausebool = true;
            }
            else if (Pausebool == true)
            {
                Time.timeScale = 1;
                ClickSound.Play();
                PauseCanvas.SetActive(false);
                SettingCanvas.SetActive(false);
                MainMenuAskingCanvas.SetActive(false);
                ExitAskingCanvas.SetActive(false);
                HowtoPlayCanvas.SetActive(false);
                HowtoPlayScrollbar.value = 1;
                Pausebool = false;
            }

        }

        MainCharacterPosition = MainCharacter.transform.position;

        if(!PlayerPrefs.HasKey("Saved") && CharacterPositionbool == false)   // ���ο� ������ ���۵ɶ�
        {
            nPCProgressInt = 0;
            MainCharacter.transform.position = new Vector3(-10, 0, 0);
            MainCamera.transform.position = new Vector3(-10, 1, -10);
            CharacterPositionbool = true;
            BossesInt = 0;
        }
        if (PlayerPrefs.HasKey("Saved") && CharacterPositionbool == false)  
        {
            nPCProgressInt = PlayerPrefs.GetInt("NPCProgressint");
            MainCharacter.transform.position = new Vector3(PlayerPrefs.GetFloat("X_Position"), PlayerPrefs.GetFloat("Y_Position"), PlayerPrefs.GetFloat("Z_Position"));
            MainCamera.transform.position = new Vector3(PlayerPrefs.GetFloat("X_Position"), PlayerPrefs.GetFloat("Y_Position") + 1.5f, -10);

            CharacterPositionbool = true;
        }


    }

    public void PauseOnButton()
    {
        if (Pausebool == false && CantPressPausebool == false)
        {
            
            Time.timeScale = 0;
            ClickSound.Play();
            PauseCanvas.SetActive(true);
            Pausebool = true;
        }
        else if (Pausebool == true && CantPressPausebool == false)
        {
            
            Time.timeScale = 1;
            ClickSound.Play();
            PauseCanvas.SetActive(false);
            SettingCanvas.SetActive(false);
            MainMenuAskingCanvas.SetActive(false);
            ExitAskingCanvas.SetActive(false);
            HowtoPlayCanvas.SetActive(false);
            HowtoPlayScrollbar.value = 1;
            Pausebool = false;
        }
    }
    public void ResumeButton()
    {
        Time.timeScale = 1;
        ClickSound.Play();
        PauseCanvas.SetActive(false);
        SettingCanvas.SetActive(false);
        MainMenuAskingCanvas.SetActive(false);
        ExitAskingCanvas.SetActive(false);
        HowtoPlayCanvas.SetActive(false);
        Pausebool = false;
    }

    public void HowtoPlayButton()
    {
        HowtoPlayScrollbar.value = 0;
        ClickSound.Play();
        PauseCanvas.SetActive(false);
        HowtoPlayCanvas.SetActive(true);
    }

    public void HowtoPlayOutButton()
    {
        ClickSound.Play();
        PauseCanvas.SetActive(true);
        HowtoPlayCanvas.SetActive(false);
    }

    public void SettingOnButton()
    {
        ClickSound.Play();
        PauseCanvas.SetActive(false);
        SettingCanvas.SetActive(true);
    }

    public void SettingOffButton()
    {
        ClickSound.Play();
        PauseCanvas.SetActive(true);
        SettingCanvas.SetActive(false);
    }

    public void MainMenuAskingButton()
    {
        ClickSound.Play();
        PauseCanvas.SetActive(false);
        MainMenuAskingCanvas.SetActive(true);
    }

    public void MainMenuAskingInButton()
    {
        Time.timeScale = 1;

        ClickSound.Play();
        //CharacterPositionbool = false;
        PauseCanvas.SetActive(false);
        MainMenuAskingCanvas.SetActive(false);
        PlaceTextManager.revealbool = false;
        PlaceTextManager.revealTime = 0;
        PlaceTextManager.AudioPlayOncebool = false;
        AreaTextControl.inbool = false;
        PlayerPrefs.SetFloat("X_Position", MainCharacterPosition.x);
        PlayerPrefs.SetFloat("Y_Position", MainCharacterPosition.y);
        PlayerPrefs.SetFloat("Z_Position", MainCharacterPosition.z);
        PlayerPrefs.SetString("Saved", SaveThings.SaveString);
        PlayerPrefs.SetInt("MapInt", PlayPortalManager.MapInt);
        PlayerPrefs.SetInt("NPCProgressint", nPCProgressInt);
        PlayerPrefs.SetInt("DeerMatchInt", FirstDeerMatch.FirstMatchDeerInt);
        PlayerPrefs.SetInt("SecondMatchDeerInt", SecondDeerMatch.SecondMatchDeerInt);
        PlayerPrefs.SetInt("Health", CharacterUI_HP_SkillCoolDown.HealthValue);
        PlayerPrefs.SetFloat("RevivePosition_X", ReviveStatue.Save_X);
        PlayerPrefs.SetFloat("RevivePosition_Y", ReviveStatue.Save_Y);
        PlayerPrefs.SetFloat("RevivePosition_Z", ReviveStatue.Save_Z);
        PlayerPrefs.SetInt("ReviveMapInt", ReviveStatue.ReviveMapInt);

        PlayerPrefs.SetInt("BossesInt", BossesInt);
        CharacterUI_HP_SkillCoolDown.Activebool = true;
        MainCharacterController.DashingTime = 0;
        //PlayerPrefs.Save();
        Scenebool = true;
    }

    public void MainMenuAskingOutButton()
    {
        ClickSound.Play();
        PauseCanvas.SetActive(true);
        MainMenuAskingCanvas.SetActive(false);
    }

    public void ExitAskingButton()
    {
        ClickSound.Play();
        PauseCanvas.SetActive(false);
        ExitAskingCanvas.SetActive(true);
    }

    public void ExitAskingYesButton()
    {
        Time.timeScale = 1;

        ClickSound.Play();
        //CharacterPositionbool = false;
        PlaceTextManager.revealbool = false;
        PlaceTextManager.revealTime = 0;
        PlaceTextManager.AudioPlayOncebool = false;
        AreaTextControl.inbool = false;
        PlayerPrefs.SetFloat("X_Position", MainCharacterPosition.x);
        PlayerPrefs.SetFloat("Y_Position", MainCharacterPosition.y);
        PlayerPrefs.SetFloat("Z_Position", MainCharacterPosition.z);
        PlayerPrefs.SetString("Saved", SaveThings.SaveString);
        PlayerPrefs.SetInt("MapInt", PlayPortalManager.MapInt);
        PlayerPrefs.SetInt("NPCProgressint", nPCProgressInt);
        PlayerPrefs.SetInt("DeerMatchInt", FirstDeerMatch.FirstMatchDeerInt);
        PlayerPrefs.SetInt("SecondMatchDeerInt", SecondDeerMatch.SecondMatchDeerInt);
        PlayerPrefs.SetInt("Health", CharacterUI_HP_SkillCoolDown.HealthValue);
        PlayerPrefs.SetFloat("RevivePosition_X", ReviveStatue.Save_X);
        PlayerPrefs.SetFloat("RevivePosition_Y", ReviveStatue.Save_Y);
        PlayerPrefs.SetFloat("RevivePosition_Z", ReviveStatue.Save_Z);
        PlayerPrefs.SetInt("ReviveMapInt", ReviveStatue.ReviveMapInt);
        PlayerPrefs.SetInt("BossesInt", BossesInt);
        CharacterUI_HP_SkillCoolDown.Activebool = true;
        MainCharacterController.DashingTime = 0;
        //PlayerPrefs.Save();
        Application.Quit();
    }

    public void ExitAskingNoButton()
    {

        ClickSound.Play();
        PauseCanvas.SetActive(true);
        ExitAskingCanvas.SetActive(false);
    }

    private void NPCProgressInt()
    {
        if(nPCProgressInt == 0)
        {
            NPCs[0].SetActive(true);  // ù��° npc����
            NPCs[1].SetActive(false);  // ���� ����
            NPCs[2].SetActive(false);  // ������ �̵�
            NPCs[3].SetActive(false);  // ������ ������
            NPCs[4].SetActive(true);  // '��ƽ�Ʈ' ����Ʈ�� ���� ù��° �̵�
            Portals[0].SetActive(false);
            Portals[1].SetActive(false);
            Portals[2].SetActive(false);
            Portals[3].SetActive(false);
            Portals[4].SetActive(false);
            Portals[5].SetActive(false);
            GodRay[0].SetActive(false);
            GodRay[1].SetActive(false);
        }
        else if (nPCProgressInt == 1)
        {
            NPCs[0].SetActive(false);
            NPCs[1].SetActive(true);
            NPCs[2].SetActive(true);  // ������ �̵�
            NPCs[3].SetActive(true);  // ������ ������
            NPCs[4].SetActive(true);  // '��ƽ�Ʈ' ����Ʈ�� ���� ù��° �̵�
            Portals[0].SetActive(true);
            Portals[1].SetActive(false);
            Portals[2].SetActive(false);
            Portals[3].SetActive(false);
            Portals[4].SetActive(false);
            Portals[5].SetActive(false);
            GodRay[0].SetActive(false);
            GodRay[1].SetActive(false);
        }
        else if (nPCProgressInt == 2)
        {
            NPCs[0].SetActive(false);
            NPCs[1].SetActive(true);
            NPCs[2].SetActive(true);  // ������ �̵�
            NPCs[3].SetActive(true);  // ������ ������
            NPCs[4].SetActive(true);  // '��ƽ�Ʈ' ����Ʈ�� ���� ù��° �̵�
            Portals[0].SetActive(true);
            Portals[1].SetActive(true);
            Portals[2].SetActive(true);
            Portals[3].SetActive(false);
            Portals[4].SetActive(false);
            Portals[5].SetActive(false);
            TransparentWall[0].SetActive(true);
            TransparentWall[1].SetActive(true);
            GodRay[0].SetActive(false);
            GodRay[1].SetActive(false);
        }
        else if (nPCProgressInt == 3)
        {
            NPCs[0].SetActive(false);
            NPCs[1].SetActive(false);
            NPCs[2].SetActive(false);  // ������ �̵�
            NPCs[3].SetActive(false);  // ������ ������
            NPCs[4].SetActive(true);  // '��ƽ�Ʈ' ����Ʈ�� ���� ù��° �̵�
            Portals[0].SetActive(true);
            Portals[1].SetActive(true);
            Portals[2].SetActive(true);
            Portals[3].SetActive(false);
            Portals[4].SetActive(false);
            Portals[5].SetActive(false);
            TransparentWall[0].SetActive(false);
            TransparentWall[1].SetActive(true);
            GodRay[0].SetActive(false);
            GodRay[1].SetActive(false);
        }
        else if (nPCProgressInt == 4)
        {
            NPCs[0].SetActive(false);
            NPCs[1].SetActive(false);
            NPCs[2].SetActive(false);  // ������ �̵�
            NPCs[3].SetActive(false);  // ������ ������
            NPCs[4].SetActive(true);  // '��ƽ�Ʈ' ����Ʈ�� ���� ù��° �̵�
            Portals[0].SetActive(true);
            Portals[1].SetActive(true);
            Portals[2].SetActive(true);
            Portals[3].SetActive(true);
            Portals[4].SetActive(true);
            Portals[5].SetActive(true);
            TransparentWall[0].SetActive(false);
            TransparentWall[1].SetActive(true);
            GodRay[0].SetActive(true);
            GodRay[1].SetActive(true);
        }

        else if (nPCProgressInt == 5)
        {
            NPCs[0].SetActive(false);
            NPCs[1].SetActive(false);
            NPCs[2].SetActive(false);  // ������ �̵�
            NPCs[3].SetActive(false);  // ������ ������
            NPCs[4].SetActive(false);  // '��ƽ�Ʈ' ����Ʈ�� ���� ù��° �̵�
            Portals[0].SetActive(true);
            Portals[1].SetActive(true);
            Portals[2].SetActive(true);
            Portals[3].SetActive(true);
            Portals[4].SetActive(true);
            Portals[5].SetActive(true);
            TransparentWall[0].SetActive(false);
            TransparentWall[1].SetActive(false);
            GodRay[0].SetActive(true);
            GodRay[1].SetActive(true);
        }
    }
}
