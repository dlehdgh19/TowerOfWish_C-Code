using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class TalkingTest : MonoBehaviour
{
    public TMP_Text Testtext;

    public string dialogue;
    

    void Start()
    {
        
        StartCoroutine(Typing(dialogue));
    }

    IEnumerator Typing(string talk)
    {
        Testtext.text = null;
        if (talk.Contains("  ")) talk = talk.Replace("  ", "\n");
        for(int i = 0; i < talk.Length; i++)
        {
            Testtext.text += talk[i];

            yield return new WaitForSeconds(0.05f);
        }
    }
}

