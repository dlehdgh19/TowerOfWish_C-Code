using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CharacterUI_HP_SkillCoolDown : MonoBehaviour
{
    public static bool Activebool;
    public GameObject HealthCanvas;
    public GameObject HealCanvas;

    public Text CoolDownText;
    public Slider HealthSlider;
    public static int HealthValue;
    public Text HealthText;
    public GameObject Fill;
    public Text HealText;
    private int HealInt;

    public GameObject DashImage;
    public GameObject HealIamge;

    public static bool Deadbool = false;
    public static bool Revivebool = false;
    public static bool Hurtingbool = false;
    // Start is called before the first frame update
    void Start()
    {
        HealCanvas.SetActive(false);

        if (!PlayerPrefs.HasKey("Saved"))   // ���ο� ������ ���۵� ��
        {
            HealthCanvas.SetActive(false);
            HealthValue = 100;
            Fill.SetActive(true);
            DashImage.SetActive(true);
            HealIamge.SetActive(true);
            Activebool = false;
        }
        if (PlayerPrefs.HasKey("Saved")) // ����� ������ ���۵� ��
        {
            HealthSlider.value = PlayerPrefs.GetInt("Health");
            Fill.SetActive(true);
            DashImage.SetActive(true);
            HealIamge.SetActive(true);
            Activebool = false;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(PlayPortalManager.MapInt >= 8 && Activebool == false && MapNPC20_1.FirstEpisodeEndbool == false)
        {
            HealthCanvas.SetActive(true);
        }
        else
        {
            HealthCanvas.SetActive(false);
        }

        if(PlayButtonManager.nPCProgressInt >= 3)
        {
            HealCanvas.SetActive(true);
        }

        else
        {
            HealCanvas.SetActive(false);
        }

        if(MainCharacterController.DashingTime == 0)
        {
            DashImage.SetActive(true);
            CoolDownText.text = "";
        }
        else if (MainCharacterController.DashingTime > 0 && MainCharacterController.DashingTime <= 1)
        {
            DashImage.SetActive(false);
            CoolDownText.text = "3";
        }
        else if (MainCharacterController.DashingTime > 1 && MainCharacterController.DashingTime <= 2)
        {
            
            CoolDownText.text = "2";
        }
        else if (MainCharacterController.DashingTime > 2)
        {
            
            CoolDownText.text = "1";
        }

        if(MainCharacterController.healtime == 0)
        {
            HealIamge.SetActive(true);
            HealText.text = "";
        }

        else if(MainCharacterController.healtime != 0)
        {
            HealIamge.SetActive(false);
            HealInt = (int)MainCharacterController.healtime;
            HealText.text = (30 - HealInt).ToString();
        }

        HealthValueUI();
        Hurt();
    }

    public void HealthValueUI()
    {
        if(HealNPCPrefab.HealUpbool == true)
        {
            HealthValue = 15 +(int)HealthSlider.value;
            HealthSlider.value = HealthValue;
            HealthText.text = HealthValue + " / 100";
            HealNPCPrefab.HealUpbool = false;
            HealNPCPrefab.HealOncebool = true;
        }
        if(HealNPCPrefab.HealUpbool == false)
        {
            HealthValue = (int)HealthSlider.value;
            HealthText.text = HealthValue + " / 100";
        }
        

        if(HealthValue <= 0)
        {
            Fill.SetActive(false);
        }
        else if (HealthValue > 0)
        {
            Fill.SetActive(true);
        }

        if(HealthValue > 100)
        {
            HealthValue = 100;
        }

        if(HealthValue <= 0 && Revivebool == false)
        {
            Deadbool = true;
        }

        if(Revivebool == true)
        {
            HealthValue = 100;
            HealthSlider.value = HealthValue;
            Deadbool = false;
            Revivebool = false;
        }
    }

    public void Hurt()
    {
        if(MainCharacterController.Hurtbool1 == true)
        {
            if(Hurtingbool == false)
            {
                HealthValue = (int)HealthSlider.value - 10;
                HealthSlider.value = HealthValue;
                Hurtingbool = true;
            }
        }
        if (MainCharacterController.Hurtbool2 == true)
        {
            if (Hurtingbool == false)
            {
                HealthValue = (int)HealthSlider.value - 15;
                HealthSlider.value = HealthValue;
                Hurtingbool = true;
            }
        }
        if (MainCharacterController.Hurtbool3 == true)
        {
            if (Hurtingbool == false)
            {
                HealthValue = (int)HealthSlider.value - 20;
                HealthSlider.value = HealthValue;
                Hurtingbool = true;
            }
        }
        if (MainCharacterController.Hurtbool4 == true)
        {
            if (Hurtingbool == false)
            {
                HealthValue = (int)HealthSlider.value - 30;
                HealthSlider.value = HealthValue;
                Hurtingbool = true;
            }
        }
        if (MainCharacterController.Hurtbool5 == true)
        {
            if (Hurtingbool == false)
            {
                HealthValue = (int)HealthSlider.value - 50;
                HealthSlider.value = HealthValue;
                Hurtingbool = true;
            }
        }
        if (MainCharacterController.Hurtbool6 == true)
        {
            if (Hurtingbool == false)
            {
                HealthValue = (int)HealthSlider.value - 60;
                HealthSlider.value = HealthValue;
                Hurtingbool = true;
            }
        }
        if (MainCharacterController.Hurtbool7 == true)
        {
            if (Hurtingbool == false)
            {
                HealthValue = (int)HealthSlider.value - 100;
                HealthSlider.value = HealthValue;
                Hurtingbool = true;
            }
        }
    }
}
