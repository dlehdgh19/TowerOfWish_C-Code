using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SecondDeerMatch : MonoBehaviour
{
    private Rigidbody2D rigid;
    private Animator anim;
    private SpriteRenderer rend;
    private bool MainCharacternearbool;
    public static int SecondMatchDeerInt;
    private float ActionTime;
    public AudioSource DeerRunSound;
    public GameObject EndDeerMatchCanvas;
    public AudioSource ClickSound;
    private bool PlayOnceAudiobool;

    private void Awake()
    {
        rigid = gameObject.GetComponent<Rigidbody2D>();
        rend = gameObject.GetComponent<SpriteRenderer>();
        anim = gameObject.GetComponent<Animator>();

        if (!PlayerPrefs.HasKey("Saved"))   // ���ο� ������ ���۵ɶ�
        {
            MainCharacternearbool = false;
            ActionTime = 0;
            rend.flipX = true;
            anim.SetBool("Foundbool", false);
            EndDeerMatchCanvas.SetActive(false);
            PlayOnceAudiobool = false;
        }
        if (PlayerPrefs.HasKey("Saved"))
        {
            if (PlayerPrefs.GetInt("SecondMatchDeerInt") == 0) // ���ϰ� ���츦 ���� ���� ���� ���·� ������ �ҷ����� ���� ��
            {
                this.gameObject.SetActive(true);
                MainCharacternearbool = false;
                ActionTime = 0;
                rend.flipX = true;
                anim.SetBool("Foundbool", false);
                EndDeerMatchCanvas.SetActive(false);
                PlayOnceAudiobool = false;
            }
            if (PlayerPrefs.GetInt("SecondMatchDeerInt") == 1)  // ���ϰ� ���찡 ���� ���·� ������ �ҷ����� ���� ��
            {
                this.gameObject.SetActive(false);

            }

        }
    }

    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (MainCharacternearbool == true)
        {
            ActionTime += Time.deltaTime;
            if (ActionTime > 0 && ActionTime < 2)
            {
                MainCharacterController.CharacterCantMovebool = true;
            }
            
            if (ActionTime >= 2 && ActionTime < 4)
            {
                anim.SetBool("Foundbool", true);
                rend.flipX = false;
                this.gameObject.transform.position = this.gameObject.transform.position + new Vector3(4 * Time.deltaTime, 0, 0);

                if (PlayOnceAudiobool == false)
                {
                    DeerRunSound.Play();
                    PlayOnceAudiobool = true;
                }
            }
            if (ActionTime >= 4)
            {
                rend.color = new Color(1, 1, 1, 0);
                DeerRunSound.Stop();
                anim.SetBool("Foundbool", false);
                SecondMatchDeerInt = 1;
            }
            if (ActionTime >= 5)
            {
                EndDeerMatchCanvas.SetActive(true);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            MainCharacternearbool = true;
            PlayButtonManager.CantPressPausebool = true;
        }
    }

    public void OutCanvasButton()
    {
        ClickSound.Play();
        PlayButtonManager.CantPressPausebool = false;
        MainCharacterController.CharacterCantMovebool = false;
        EndDeerMatchCanvas.SetActive(false);
        ActionTime = 0;
        MainCharacternearbool = false;
        PlayOnceAudiobool = false;
        this.gameObject.SetActive(false);
    }
}

