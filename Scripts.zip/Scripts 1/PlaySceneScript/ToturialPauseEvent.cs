using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ToturialPauseEvent : MonoBehaviour
{
    public GameObject SettingCanvas;
    private bool onbool;
    // Start is called before the first frame update
    void Start()
    {
        SettingCanvas.SetActive(false);
        onbool = false;
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
