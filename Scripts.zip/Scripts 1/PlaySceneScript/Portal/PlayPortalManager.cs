using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayPortalManager : MonoBehaviour
{
    public static bool Portalbool = false;
    public static int MapInt;

    public AudioSource[] BGMs;
    public GameObject[] BackGrounds;
    public static bool BGMPlayOncebool;
    // Start is called before the first frame update
    void Start()
    {
        Portalbool = false;
        BGMPlayOncebool = false;
        for(int b = 0; b < BackGrounds.Length; b++)
        {
            BackGrounds[b].SetActive(false);
        }
    }

    private void Awake()
    {
        if (!PlayerPrefs.HasKey("Saved"))   // ���ο� ������ ���۵� ��
        {
            MapInt = 0;
        }
        if (PlayerPrefs.HasKey("Saved"))  // ����� ������ ������ ��
        {
            MapInt = PlayerPrefs.GetInt("MapInt");
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(BGMPlayOncebool == false)
        {
            
            if((MapInt == 0 || MapInt == 1 || MapInt == 2) && GateOpen.BGMStopbool == false)
            {
                BGMs[1].Play(); // FirstBGM
                BGMs[0].Stop(); // CityAroundBGM
                BGMs[2].Stop(); // InsidetowerFisrtBGM
                BGMs[3].Stop(); // MiddleBoss1BGM
                BGMs[4].Stop(); // MiddleBoss2BGM
                BGMs[5].Stop(); // West BGM
                BGMs[6].Stop(); // East BGM
                BGMs[7].Stop(); // LastBoss BGM
                BGMs[8].Stop(); // Middle Path
                BGMPlayOncebool = true;
            }
            if ((MapInt == 3 || MapInt == 4 || MapInt == 5 || MapInt == 6 || MapInt == 7) && GateOpen.BGMStopbool == false)
            {
                BGMs[0].Play();
                BGMs[1].Stop();
                BGMs[2].Stop();
                BGMs[3].Stop();
                BGMs[4].Stop();
                BGMs[5].Stop();
                BGMs[6].Stop(); // East BGM
                BGMs[7].Stop(); // LastBoss BGM
                BGMs[8].Stop(); // Middle Path
                BGMPlayOncebool = true;
            }
            
            if((MapInt == 8 || MapInt == 9 || MapInt == 10 || MapInt == 11 || MapInt == 12)
                && GateOpen.BGMStopbool == false && MiddleBoss1.BGMChangetoMiddleBoss1bool == false && MiddleBoss2.BGMStopbool == false && MiddleBoss2.BGMChangebool == false)
            {
                BGMs[0].Stop();
                BGMs[1].Stop();
                BGMs[2].Play();
                BGMs[3].Stop();
                BGMs[4].Stop();
                BGMs[5].Stop();
                BGMs[6].Stop(); // East BGM
                BGMs[7].Stop(); // LastBoss BGM
                BGMs[8].Stop(); // Middle Path
                BGMPlayOncebool = true;
            }

            if ((MapInt == 13 || MapInt == 14)
                && GateOpen.BGMStopbool == false && MiddleBoss1.BGMChangetoMiddleBoss1bool == false && MiddleBoss2.BGMStopbool == false && MiddleBoss2.BGMChangebool == false)
            {
                BGMs[0].Stop();
                BGMs[1].Stop();
                BGMs[2].Stop();
                BGMs[3].Stop();
                BGMs[4].Stop();
                BGMs[5].Play();
                BGMs[6].Stop(); // East BGM
                BGMs[7].Stop(); // LastBoss BGM
                BGMs[8].Stop(); // Middle Path
                BGMPlayOncebool = true;
            }

            if ((MapInt == 15 || MapInt == 16 || MapInt == 17)
                && GateOpen.BGMStopbool == false && MiddleBoss1.BGMChangetoMiddleBoss1bool == false 
                && MiddleBoss2.BGMStopbool == false && MiddleBoss2.BGMChangebool == false 
                && LastBoss1.StartBGMbool1 == false && LastBoss1.StopBGMbool == false && LastBoss1.AfterLastBossDeadbool == false)
            {
                BGMs[0].Stop();
                BGMs[1].Stop();
                BGMs[2].Stop();
                BGMs[3].Stop();
                BGMs[4].Stop();
                BGMs[5].Stop();
                BGMs[6].Play(); // East BGM
                BGMs[7].Stop(); // LastBoss BGM
                BGMs[8].Stop(); // Middle Path
                BGMPlayOncebool = true;
            }

            if ((MapInt == 15 || MapInt == 16 || MapInt == 17)
                && GateOpen.BGMStopbool == false && MiddleBoss1.BGMChangetoMiddleBoss1bool == false
                && MiddleBoss2.BGMStopbool == false && MiddleBoss2.BGMChangebool == false
                && LastBoss1.StartBGMbool1 == false && LastBoss1.StopBGMbool == false && LastBoss1.AfterLastBossDeadbool == true)
            {
                BGMs[0].Stop();
                BGMs[1].Stop();
                BGMs[2].Stop();
                BGMs[3].Stop();
                BGMs[4].Stop();
                BGMs[5].Stop();
                BGMs[7].Stop();// LastBoss BGM
                BGMs[6].Play(); // East BGM
                BGMs[8].Stop(); // Middle Path
                BGMPlayOncebool = true;
            }

            if ((MapInt == 18 || MapInt == 19 || MapInt == 20) && GateOpen.BGMStopbool == false)
            {
                BGMs[0].Stop();
                BGMs[1].Stop();
                BGMs[2].Stop();
                BGMs[3].Stop();
                BGMs[4].Stop();
                BGMs[5].Stop();
                BGMs[6].Stop();// LastBoss BGM
                BGMs[7].Stop(); // East BGM
                BGMs[8].Play(); // Middle Path
                BGMPlayOncebool = true;
            }

            if (MapInt == 16 && LastBoss1.AfterLastBossDeadbool == true)
            {
                BGMs[7].Stop();
                BGMs[6].Play();
                BGMs[8].Stop(); // Middle Path
                BGMPlayOncebool = true;
            }

            if (MapInt == 13 && MiddleBoss1.BGMChangetoMiddleBoss1bool == true)
            {
                BGMs[0].Stop();
                BGMs[1].Stop();
                BGMs[2].Stop();
                BGMs[3].Play();
                BGMs[4].Stop();
                BGMs[5].Stop();
                BGMs[6].Stop(); // East BGM
                BGMs[7].Stop(); // LastBoss BGM
                BGMs[8].Stop(); // Middle Path
                BGMPlayOncebool = true;
            }
            if (MapInt == 14 && MiddleBoss2.BGMChangebool == true)
            {
                BGMs[0].Stop();
                BGMs[1].Stop();
                BGMs[2].Stop();
                BGMs[3].Stop();
                BGMs[4].Play();
                BGMs[5].Stop();
                BGMs[6].Stop(); // East BGM
                BGMs[7].Stop(); // LastBoss BGM
                BGMs[8].Stop(); // Middle Path
                BGMPlayOncebool = true;
            }
            if (MapInt == 16 && LastBoss1.StartBGMbool1 == true && LastBoss1.StopBGMbool == false)
            {
                BGMs[0].Stop();
                BGMs[1].Stop();
                BGMs[2].Stop();
                BGMs[3].Stop();
                BGMs[4].Stop();
                BGMs[5].Stop();
                BGMs[6].Stop(); // East BGM
                BGMs[7].Play(); // LastBoss BGM
                BGMs[8].Stop(); // Middle Path
                BGMPlayOncebool = true;
            }
        }

        if (GateOpen.BGMStopbool == true || MiddleBoss1.BGMStopbool == true
            || MainCharacterController.Resetbool == true || MiddleBoss2.BGMStopbool == true
            || LastBoss1.StopBGMbool == true || MapNPC20_1.FirstEpisodeEndbool == true)
        {
            BGMs[0].Stop();
            BGMs[1].Stop();
            BGMs[2].Stop();
            BGMs[3].Stop();
            BGMs[4].Stop();
            BGMs[5].Stop();
            BGMs[6].Stop(); // East BGM
            BGMs[7].Stop(); // LastBoss BGM
            BGMs[8].Stop(); // Middle Path
        }
        
        switch (MapInt)
        {
            case 0:
                BackGrounds[0].SetActive(true);
                BackGrounds[1].SetActive(false);
                break;
            case 1:
                BackGrounds[0].SetActive(false);
                BackGrounds[1].SetActive(true);
                BackGrounds[2].SetActive(false);
                break;
            case 2:
                BackGrounds[1].SetActive(false);
                BackGrounds[2].SetActive(true);
                BackGrounds[3].SetActive(false);
                break;

            case 3:
                BackGrounds[2].SetActive(false);
                BackGrounds[3].SetActive(true);
                BackGrounds[4].SetActive(false);
                break;

            case 4:
                BackGrounds[3].SetActive(false);
                BackGrounds[4].SetActive(true);
                BackGrounds[5].SetActive(false);
                break;
            case 5:
                BackGrounds[4].SetActive(false);
                BackGrounds[5].SetActive(true);
                break;
            case 6:
                BackGrounds[5].SetActive(false);
                break;
            case 7:
                break;
            case 8:
                break;
            case 9:
                break;
            case 10:
                break;
            case 11:
                break;
            case 12:
                break;
            case 13:
                break;
            case 14:
                break;
            case 15:
                break;
            case 16:
                break;
            case 17:
                break;
            case 18:
                break;
            case 19:
                break;
            case 20:
                break;
            default:
                return;
        }
    }
}
