using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class ReviveStatue : MonoBehaviour
{
    public Transform MainCharacterTransform;

    private bool inbool;

    public AudioSource ClickButtonAudio;
    public GameObject SavePositionCanvas;

    public static int RememberMapInt;
    public static int ReviveMapInt;
    private bool CanvasOnBool;

    public Text WhereText;

    public static float Save_X;
    public static float Save_Y;
    public static float Save_Z;

    // Start is called before the first frame update
    private void Awake()
    {
        SavePositionCanvas.SetActive(false);
        CanvasOnBool = false;
        if (!PlayerPrefs.HasKey("Saved"))   // ���ο� ������ ���۵ɶ�
        {
            RememberMapInt = 0;
        }
        if (PlayerPrefs.HasKey("Saved"))
        {

            Save_X = PlayerPrefs.GetFloat("RevivePosition_X");
            Save_Y = PlayerPrefs.GetFloat("RevivePosition_Y");
            Save_Z = PlayerPrefs.GetFloat("RevivePosition_Z");
            RememberMapInt = PlayerPrefs.GetInt("ReviveMapInt");
            ReviveMapInt = PlayerPrefs.GetInt("ReviveMapInt");
        }
    }

    // Update is called once per frame
    void Update()
    {

        if (inbool == true)
        {
            if(Input.GetKeyDown(KeyCode.G))
            {
                if(CanvasOnBool == false)
                {
                    MainCharacterController.CharacterCantMovebool = true;
                    SavePositionCanvas.SetActive(true);
                    ClickButtonAudio.Play();
                    CanvasOnBool = true;
                }
                else if (CanvasOnBool == true)
                {
                    MainCharacterController.CharacterCantMovebool = false;
                    SavePositionCanvas.SetActive(false);
                    ClickButtonAudio.Play();
                    CanvasOnBool = false;
                }
            }

            
        }

        if(RememberMapInt == 0)
        {
            WhereText.text = "����";
        }
        if (RememberMapInt == 13)
        {
            WhereText.text = "ž�� ������ ���� �α�\n'��ƽ�Ʈ'�� ���� ���Ժ�";
        }
        if (RememberMapInt == 14)
        {
            WhereText.text = "ž�� ������ ���� �α�\n'��ƽ�Ʈ'�� ���� �߰�����";
        }
        if (RememberMapInt == 15)
        {
            WhereText.text = "ž�� ������ ���� �α�\n'��ƽ�Ʈ'�� ���� ��������";
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.tag == "Player")
        {
            inbool = true;
            
        }
    }

    

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            inbool = false;
        }
    }

    public void SaveButton()
    {
        Save_X = MainCharacterTransform.position.x;
        Save_Y = MainCharacterTransform.position.y;
        Save_Z = MainCharacterTransform.position.z;
        PlayerPrefs.SetFloat("RevivePosition_X", Save_X);
        PlayerPrefs.SetFloat("RevivePosition_Y", Save_Y);
        PlayerPrefs.SetFloat("RevivePosition_Z", Save_Z);
        PlayerPrefs.SetInt("ReviveMapInt", PlayPortalManager.MapInt);
        ReviveMapInt = PlayPortalManager.MapInt;
        RememberMapInt = ReviveMapInt;
        ClickButtonAudio.Play();
        SavePositionCanvas.SetActive(false);
        MainCharacterController.CharacterCantMovebool = false;
        CharacterUI_HP_SkillCoolDown.Revivebool = true;
        CanvasOnBool = false;
    }

    public void OutButton()
    {
        SavePositionCanvas.SetActive(false);
        MainCharacterController.CharacterCantMovebool = false;
        CharacterUI_HP_SkillCoolDown.Revivebool = true;
        ClickButtonAudio.Play();
        CanvasOnBool = false;
    }
}
