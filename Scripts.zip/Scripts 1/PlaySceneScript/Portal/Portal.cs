using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Portal : MonoBehaviour
{
    [SerializeField]
    private GameObject MainCharacter;

    public Vector3 MainCharacterPosition;

    [SerializeField]
    private SpriteRenderer BlackScreen;

    [SerializeField]
    private GameObject MainCameraPosition;

    public Vector3 MainCameraVector;
    public int ChangeMapIntValue;

    private bool WhenPortalOnbool;
    private bool Playernearbool;
    private float MoveTermTime;

    // Start is called before the first frame update
    void Start()
    {
        MoveTermTime = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (Playernearbool == true && WhenPortalOnbool == false && 
            MainCharacter.GetComponent<Rigidbody2D>().velocity.x == 0 && MainCharacter.GetComponent<Rigidbody2D>().velocity.y == 0
            && MainCharacterController.Dashingbool == false)
        {
            if (Input.GetKeyDown(KeyCode.UpArrow))
            {
                PlayButtonManager.CantPressPausebool = true;
                MainCharacterController.CharacterCantMovebool = true;
                CameraFollow.CameraControlbool = true;
                WhenPortalOnbool = true;
            }
        }

        if(WhenPortalOnbool == true)
        {
            MoveTermTime += Time.deltaTime;
            if(MoveTermTime > 0 && MoveTermTime < 1)
            {
                BlackScreen.color = new Color(0, 0, 0, MoveTermTime);
                
            }
            if(MoveTermTime >= 1 && MoveTermTime < 1.25f)
            {
                MainCameraPosition.transform.position = MainCameraVector;
                BlackScreen.color = new Color(0, 0, 0, 1);
                MainCharacter.transform.position = MainCharacterPosition;
                PlayPortalManager.MapInt = ChangeMapIntValue;
            }
            if (MoveTermTime >= 1.25f && MoveTermTime < 2)
            {
                CameraFollow.CameraControlbool = false;
                PlayPortalManager.BGMPlayOncebool = false;
                BlackScreen.color = new Color(0, 0, 0, 3 - MoveTermTime);
            }
            if (MoveTermTime >= 2f && MoveTermTime < 3)
            {

                BlackScreen.color = new Color(0, 0, 0, 3 - MoveTermTime);
            }
            if (MoveTermTime >= 3)
            {
                BlackScreen.color = new Color(0, 0, 0, 0);
                MainCharacterController.CharacterCantMovebool = false;
                PlayButtonManager.CantPressPausebool = false;
                WhenPortalOnbool = false;
                MoveTermTime = 0;
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            Playernearbool = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            Playernearbool = false;
        }
    }
}
