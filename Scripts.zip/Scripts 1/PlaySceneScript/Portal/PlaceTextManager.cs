using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlaceTextManager : MonoBehaviour
{
    [SerializeField]
    private Text placeText;

    public static float revealTime;
    public static bool revealbool;
    public static bool AudioPlayOncebool;
    public AudioSource textRevealAudio;
    // Start is called before the first frame update
    void Start()
    {
        revealTime = 0;
        revealbool = false;
        AudioPlayOncebool = false;
    }

    // Update is called once per frame
    void Update()
    {
        
        if (AreaTextControl.inbool == true && GateOpen.BGMStopbool == false)
        {
            
            revealbool = true;
        }

        if(revealbool == true)
        {
            revealTime += Time.deltaTime;
            if(revealTime > 2 && revealTime < 4)
            {
                if(AudioPlayOncebool == false)
                {
                    textRevealAudio.Play();
                    AudioPlayOncebool = true;
                }
                placeText.color = new Color(1, 1, 1, 0.5f * (revealTime - 2));
            }

            if (revealTime > 6 && revealTime < 8)
            {
                placeText.color = new Color(1, 1, 1, 0.5f * (8 - revealTime));
            }
            if (revealTime > 8)
            {
                placeText.color = new Color(1, 1, 1, 0);
                revealbool = false;
            }
        }
    }

    
}
