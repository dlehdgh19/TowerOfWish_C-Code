using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AreaTextControl : MonoBehaviour
{
    [SerializeField]
    private Text placeText;

    public static bool inbool;
    public static bool OnceTextbool;
    public Transform MainCharacter;

    // Start is called before the first frame update
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        if (MainCharacter.position.x > -11 && MainCharacter.position.x < 194 
            && MainCharacter.position.y > 77 && MainCharacter.position.y < 137)
        {
            placeText.text = "�����η� ���ϴ� ��";
            inbool = true;
        }
        else if (MainCharacter.position.x > 203 && MainCharacter.position.x < 350 
            && MainCharacter.position.y > 86 && MainCharacter.position.y < 120)
        {
            placeText.text = "ž�� ������\n\n�õ��� ���� ��";
            inbool = true;
        }
        else if (MainCharacter.position.x > 70 && MainCharacter.position.x < 163 
            && MainCharacter.position.y > 160 && MainCharacter.position.y < 250)
        {
            placeText.text = "ž�� ������ ���� �α�\n\n'��ƽ�Ʈ'�� ���� ���Ժ�";
            inbool = true;
        }

        else if ((MainCharacter.position.x > 68 && MainCharacter.position.x < 122
            && MainCharacter.position.y > 262 && MainCharacter.position.y < 323)
            || (MainCharacter.position.x > 13 && MainCharacter.position.x < 68
            && MainCharacter.position.y > 158 && MainCharacter.position.y < 177))
        {
            placeText.text = "ž�� ������ ���� �α�\n\n'��ƽ�Ʈ'�� ���� �߰�����";
            inbool = true;
        }

        else if ((MainCharacter.position.x > -37.5f && MainCharacter.position.x < 44
            && MainCharacter.position.y > 211 && MainCharacter.position.y < 385.4f)
            || (MainCharacter.position.x > -83f && MainCharacter.position.x < -41.5f
            && MainCharacter.position.y > 250 && MainCharacter.position.y < 300f))
        {
            placeText.text = "ž�� ������ ���� �α�\n\n'��ƽ�Ʈ'�� ����";
            inbool = true;
        }

        else if ((MainCharacter.position.x > 361f && MainCharacter.position.x < 396
            && MainCharacter.position.y > 112 && MainCharacter.position.y < 181f)
            || (MainCharacter.position.x > 411f && MainCharacter.position.x < 444f
            && MainCharacter.position.y > 92 && MainCharacter.position.y < 105f))
        {
            placeText.text = "�߸������ ���ϴ� ��";
            inbool = true;
        }

        else if (MainCharacter.position.x > 449f && MainCharacter.position.x < 499.9f
            && MainCharacter.position.y > 94 && MainCharacter.position.y < 128f)
        {
            placeText.text = "ž�� �߰��� ���\n\n�߸�����";
            inbool = true;
        }

        else
        {
            inbool = false;
            placeText.color = new Color(1, 1, 1, 0);
            PlaceTextManager.revealbool = false;
            PlaceTextManager.revealTime = 0;
            PlaceTextManager.AudioPlayOncebool = false;
        }
    }
}
