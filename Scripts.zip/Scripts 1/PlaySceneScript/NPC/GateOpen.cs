using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GateOpen : MonoBehaviour
{
    public GameObject MainCharacter;
    public GameObject ManCamera;
    public GameObject BeforeTalk;
    public GameObject NPCCanvas;
    public GameObject BackButton;
    public GameObject NextButton;
    public GameObject outButton;
    public GameObject enterButton;
    public GameObject MainCharacterImage;
    public Text Dialoguetext;
    private string[] Dialogue = new string[12];
    private int DialogueInt;

    public AudioSource ClickSound;

    private int TextInt;
    private bool Playernearbool;
    private bool CanvasOnbool;
    public Sprite[] Image = new Sprite[6];
    private SpriteRenderer presentImage;
    public SpriteRenderer BlackScreen;

    public static bool BGMStopbool;

    private float gateOpenTime;
    private bool gateOpenbool;
    private bool PlayAudioOnceAduiobool;
    public GameObject GateOpeningAudio;
    public GameObject GateShutorFullyOpenAudio;

    public GameObject FirstChapterCanvas;
    private float FirstChapterCancasTime;
    public Text FirstChapterText;
    public Text FirstBelowText;

    // Start is called before the first frame update
    void Start()
    {
        presentImage = GetComponent<SpriteRenderer>();
        NPCCanvas.SetActive(false);
        CanvasOnbool = false;
        MainCharacterImage.SetActive(false);
        DialogueInt = 12;
        TextInt = 0;
        gateOpenTime = 0;
        BeforeTalk.SetActive(true);

        BGMStopbool = false;
        gateOpenbool = false;
        PlayAudioOnceAduiobool = false;
        presentImage.sprite = Image[0];

        FirstChapterText.color = new Color(1, 1, 1, 0);
        FirstBelowText.color = new Color(1, 1, 1, 0);
        FirstChapterCanvas.SetActive(false);

        GateOpeningAudio.SetActive(false);
        GateShutorFullyOpenAudio.SetActive(false);
    }

    void Update()
    {
        TextIntString();
        ImageOnWhen();

        if (Playernearbool == true)
        {
            if (Input.GetKeyDown(KeyCode.G) && CanvasOnbool == false
                && MainCharacter.GetComponent<Rigidbody2D>().velocity.x == 0 && MainCharacter.GetComponent<Rigidbody2D>().velocity.y == 0
                && MainCharacterController.Dashingbool == false)
            {
                PlayButtonManager.CantPressPausebool = true;
                ClickSound.Play();
                NPCCanvas.SetActive(true);
                MainCharacterController.CharacterCantMovebool = true;
                CanvasOnbool = true;
            }
        }

        if(gateOpenbool == true)
        {
            gateOpenTime += Time.deltaTime;
            if(gateOpenTime > 1 && gateOpenTime < 1.3f)
            {
                if(PlayAudioOnceAduiobool == false)
                {
                    GateOpeningAudio.SetActive(true);
                    PlayAudioOnceAduiobool = true;
                }
                CameraFollow.CameraControlbool = true;
                presentImage.sprite = Image[1];
            }
            if (gateOpenTime > 1.3f && gateOpenTime < 1.6f)
            {
                presentImage.sprite = Image[2];
            }
            if (gateOpenTime > 1.6f && gateOpenTime < 1.9f)
            {
                presentImage.sprite = Image[3];
            }
            if (gateOpenTime > 1.9f && gateOpenTime < 2.2f)
            {
                presentImage.sprite = Image[4];
            }
            if (gateOpenTime > 2.2f && gateOpenTime < 2.5f)
            {
                presentImage.sprite = Image[5];
            }
            if (gateOpenTime > 2.5f && gateOpenTime < 3.5f)
            {
                GateOpeningAudio.SetActive(false);
                if (PlayAudioOnceAduiobool == true)
                {
                    GateShutorFullyOpenAudio.SetActive(true);
                    PlayAudioOnceAduiobool = false;
                }
            }
            if(gateOpenTime > 3.5f && gateOpenTime < 4.5f)
            {
                BlackScreen.color = new Color(0, 0, 0, gateOpenTime - 3.5f);
                FirstChapterCanvas.SetActive(true);
            }
            if (gateOpenTime > 6f && gateOpenTime < 7f)
            {
                GateShutorFullyOpenAudio.SetActive(false);
                BlackScreen.color = new Color(0, 0, 0, 1);
                FirstChapterText.color = new Color(1, 1, 1, gateOpenTime - 6f);
                if (PlayAudioOnceAduiobool == false)
                {
                    GateOpeningAudio.SetActive(true);
                    PlayAudioOnceAduiobool = true;
                }
                ManCamera.transform.position = new Vector3(18.8f, 83.8f, -10);
                PlayPortalManager.MapInt = 8;
            }
            if (gateOpenTime > 7.5f && gateOpenTime < 8.5f)
            {
                MainCharacter.transform.position = new Vector3(2.32f, 82f, 0);
                FirstBelowText.color = new Color(1, 1, 1, gateOpenTime - 7.5f);
            }
            if (gateOpenTime > 8.5f && gateOpenTime < 9.5f)
            {
                GateOpeningAudio.SetActive(false);
                if (PlayAudioOnceAduiobool == true)
                {
                    GateShutorFullyOpenAudio.SetActive(true);
                    PlayAudioOnceAduiobool = false;
                }
                CameraFollow.CameraControlbool = false;
            }
            if (gateOpenTime > 11.5f && gateOpenTime < 12.5f)
            {
                BlackScreen.color = new Color(0, 0, 0, 12.5f - gateOpenTime);
                FirstChapterText.color = new Color(1, 1, 1, 12.5f - gateOpenTime);
                FirstBelowText.color = new Color(1, 1, 1, 12.5f - gateOpenTime);
                BGMStopbool = false;
                PlayPortalManager.BGMPlayOncebool = false;
            }
            if (gateOpenTime > 12.5f && gateOpenTime < 13.5f)
            {
                BlackScreen.color = new Color(0, 0, 0, 0);
                FirstChapterText.color = new Color(1, 1, 1, 0);
                FirstBelowText.color = new Color(1, 1, 1, 0);
                PlayButtonManager.CantPressPausebool = false;
                MainCharacterController.CharacterCantMovebool = false;
                
            }
            if(gateOpenTime >= 13.5f)
            {
                GateShutorFullyOpenAudio.SetActive(false);
                FirstChapterCanvas.SetActive(false);
                gateOpenbool = false;
                gateOpenTime = 0;
            }
        }
    }


    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            Playernearbool = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            Playernearbool = false;
        }
    }

    public void OutButton()
    {
        ClickSound.Play();
        PlayButtonManager.CantPressPausebool = false;
        NPCCanvas.SetActive(false);
        MainCharacterController.CharacterCantMovebool = false;
        CanvasOnbool = false;
        TextInt = 0;
    }

    public void NextOnButton()
    {
        ClickSound.Play();
        if (TextInt >= 0 && TextInt < DialogueInt && CanvasOnbool == true)
        {
            TextInt += 1;
        }
    }

    public void BeforeOnButton()
    {
        ClickSound.Play();
        if (TextInt > 0 && TextInt <= DialogueInt && CanvasOnbool == true)
        {
            TextInt -= 1;
        }

    }

    public void EnterOnButton()
    {
        BeforeTalk.SetActive(false);
        BGMStopbool = true;
        TextInt = 0;
        NPCCanvas.SetActive(false);
        CanvasOnbool = true;
        gateOpenbool = true;
    }

    private void ImageOnWhen()
    {
        switch (TextInt)
        {
            case 0:
                Dialoguetext.text = Dialogue[TextInt];
                MainCharacterImage.SetActive(false);
                NextButton.SetActive(true);
                BackButton.SetActive(false);
                outButton.SetActive(true);
                enterButton.SetActive(false);
                break;
            case 1:
                Dialoguetext.text = Dialogue[TextInt];
                BackButton.SetActive(true);
                break;
            case 2:
                Dialoguetext.text = Dialogue[TextInt];
                break;
            case 3:
                Dialoguetext.text = Dialogue[TextInt];
                break;
            case 4:
                Dialoguetext.text = Dialogue[TextInt];
                break;
            case 5:
                Dialoguetext.text = Dialogue[TextInt];
                break;
            case 6:
                Dialoguetext.text = Dialogue[TextInt];
                MainCharacterImage.SetActive(false);
                break;
            case 7:
                Dialoguetext.text = Dialogue[TextInt];
                MainCharacterImage.SetActive(true);
                break;
            case 8:
                Dialoguetext.text = Dialogue[TextInt];
                MainCharacterImage.SetActive(false);
                break;
            case 9:
                Dialoguetext.text = Dialogue[TextInt];
                break;
            case 10:
                Dialoguetext.text = Dialogue[TextInt];
                NextButton.SetActive(true);
                outButton.SetActive(true);
                enterButton.SetActive(false);
                break;
            case 11:
                Dialoguetext.text = Dialogue[TextInt];
                NextButton.SetActive(false);
                outButton.SetActive(false);
                enterButton.SetActive(true);
                break;

            default:
                return;
        }
    }

    private void TextIntString()
    {
        Dialogue[0] = "������ �ٶ󺸴� ���⿡�� �Ŵ��� ž�� �־���.";
        Dialogue[1] = "��ο��� �� �������� �ʾ����� ���� ���� ž�� �� ����.";
        Dialogue[2] = "�׳�� �������� �̰� ������� ����� ã�� �ظŴ� '�ҿ��� ž'���� Ȯ���ߴ�.";
        Dialogue[3] = "������� ���� ž�̶�� ���� ���� ���̶�� �����ϰ���... �̷� ���̶�� �Ƹ� ����� ��ã������ �𸣰ڴٰ� �׳�� �����ߴ�.";
        Dialogue[4] = "������ ������ �ʾҴٸ� �Ƹ� �ڽŵ� ���� ã���ظű⸸ �߰���...";
        Dialogue[5] = "�׳�� ������ ž�� �ٶ󺻴� ������ �ѹ� �Ĵٺ����� �̹��� ž�� �Ŵ��� �� �տ� ����.";
        Dialogue[6] = "������ ������ ���ſ����̴� ���� ���� ������ ������.";
        Dialogue[7] = "�̰�... ������� �ϰ���?";
        Dialogue[8] = "�׳డ ������ ����� ���� �о�� �õ��ϴ� ����... ";
        Dialogue[9] = "��������....\n������ ��ġ �׳డ �������� �� ȯ���ϵ� ���ſ� �Ҹ��� ���� ������ �����ߴ�...";
        Dialogue[10] = "���ſ� ������ ������... \n������ ���� �ٶ��� �׳��� ���͸� ���ȴ�.";
        Dialogue[11] = "�� ���� ���� �� ó�� ž ���ʵ� ������ ��ο� ������. \n����......\n�ȿ����� ���� ���� ��������...?";
    }

}
