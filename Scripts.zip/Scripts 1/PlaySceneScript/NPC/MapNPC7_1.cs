using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MapNPC7_1 : MonoBehaviour
{
    public GameObject MainCharacter;
    public GameObject NPCCanvas;
    public GameObject BackButton;
    public GameObject NextButton;
    public GameObject NPCImage;
    public GameObject MainCharacterImage;
    public Text Dialoguetext;
    private string[] Dialogue = new string[8];
    private int DialogueInt;

    public AudioSource ClickSound;

    private int TextInt;
    private bool Playernearbool;
    private bool CanvasOnbool;
    private SpriteRenderer Rend;

    // Start is called before the first frame update
    void Start()
    {
        NPCCanvas.SetActive(false);
        CanvasOnbool = false;
        Rend = GetComponent<SpriteRenderer>();
        NPCImage.SetActive(false);
        MainCharacterImage.SetActive(false);
        DialogueInt = 8;
        TextInt = 0;
    }

    // Update is called once per frame
    void Update()
    {
        Flip();
        TextIntString();
        ImageOnWhen();

        if (Playernearbool == true)
        {
            if (Input.GetKeyDown(KeyCode.G) && CanvasOnbool == false
                && MainCharacter.GetComponent<Rigidbody2D>().velocity.x == 0 && MainCharacter.GetComponent<Rigidbody2D>().velocity.y == 0
                && MainCharacterController.Dashingbool == false)
            {
                PlayButtonManager.CantPressPausebool = true;
                ClickSound.Play();
                NPCCanvas.SetActive(true);
                MainCharacterController.CharacterCantMovebool = true;
                CanvasOnbool = true;
            }
        }

    }

    private void Flip()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            Playernearbool = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            Playernearbool = false;
        }
    }

    public void OutButton()
    {
        PlayButtonManager.CantPressPausebool = false;
        NPCCanvas.SetActive(false);
        ClickSound.Play();
        MainCharacterController.CharacterCantMovebool = false;
        CanvasOnbool = false;
        TextInt = 0;
    }

    public void NextOnButton()
    {
        ClickSound.Play();
        if (TextInt >= 0 && TextInt < DialogueInt && CanvasOnbool == true)
        {
            TextInt += 1;
        }
    }

    public void BeforeOnButton()
    {
        ClickSound.Play();
        if (TextInt > 0 && TextInt <= DialogueInt && CanvasOnbool == true)
        {
            TextInt -= 1;
        }

    }

    private void ImageOnWhen()
    {
        switch (TextInt)
        {
            case 0:
                Dialoguetext.text = Dialogue[TextInt];
                NPCImage.SetActive(true);
                MainCharacterImage.SetActive(false);
                NextButton.SetActive(true);
                BackButton.SetActive(false);
                break;
            case 1:
                Dialoguetext.text = Dialogue[TextInt];
                NPCImage.SetActive(false);
                MainCharacterImage.SetActive(true);
                BackButton.SetActive(true);
                break;
            case 2:
                Dialoguetext.text = Dialogue[TextInt];
                NPCImage.SetActive(false);
                MainCharacterImage.SetActive(false);
                break;
            case 3:
                Dialoguetext.text = Dialogue[TextInt];
                NPCImage.SetActive(false);
                MainCharacterImage.SetActive(false);
                break;
            case 4:
                Dialoguetext.text = Dialogue[TextInt];
                NPCImage.SetActive(false);
                MainCharacterImage.SetActive(true);
                break;
            case 5:
                Dialoguetext.text = Dialogue[TextInt];
                NPCImage.SetActive(true);
                MainCharacterImage.SetActive(false);
                break;
            case 6:
                Dialoguetext.text = Dialogue[TextInt];
                NPCImage.SetActive(false);
                MainCharacterImage.SetActive(true);
                NextButton.SetActive(true);
                break;
            case 7:
                Dialoguetext.text = Dialogue[TextInt];
                NPCImage.SetActive(true);
                MainCharacterImage.SetActive(false);
                NextButton.SetActive(false);
                break;

            default:
                return;
        }
    }

    private void TextIntString()
    {
        Dialogue[0] = "......";
        Dialogue[1] = "......";
        Dialogue[2] = "�ϳ� ������ �ٰ����� ������ ��򰡸� ������ ���̿���.";
        Dialogue[3] = "�� �������� ���Ѻ��� ���Ŀ�� ���ֱ⸸ �� ��... ������ �������� ���� �� ������.";
        Dialogue[4] = "�� ������ ����� �Ŵ�?";
        Dialogue[5] = "......";
        Dialogue[6] = "��......�׷�... ������...?";
        Dialogue[7] = ".......";
    }
}
