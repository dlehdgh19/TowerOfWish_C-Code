using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealNPCPrefab : MonoBehaviour
{
    private float AnimTime;
    public GameObject NPCAnim;
    public GameObject DestroyAnim;

    public static bool HealUpbool = false;
    public static bool HealOncebool = false;
    // Start is called before the first frame update
    void Start()
    {
        
        AnimTime = 0;
        NPCAnim.SetActive(false);
        DestroyAnim.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        AnimTime += Time.deltaTime;
        if(AnimTime > 0 && AnimTime < 0.3f)
        {
            NPCAnim.SetActive(true);
            
        }
        if(AnimTime >= 0.3f && AnimTime < 3f)
        {
            
        }
        if (AnimTime >= 3f && AnimTime < 3.5f)
        {
            if(HealOncebool == false)
            {
                HealUpbool = true;
            }
                
        }
        if (AnimTime >= 3.5f)
        {
            
            NPCAnim.SetActive(false);
            DestroyAnim.SetActive(true);
            
        }
        if(AnimTime > 6f)
        {
            HealOncebool = false;
            Destroy(this.gameObject);
        }

       
    }
}
