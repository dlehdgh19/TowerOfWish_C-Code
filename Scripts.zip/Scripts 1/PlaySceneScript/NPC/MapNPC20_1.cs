using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MapNPC20_1 : MonoBehaviour
{
    public GameObject MainCharacter;
    public GameObject NPCCanvas;
    public GameObject BackButton;
    public GameObject NextButton;
    public GameObject EndButton;
    public GameObject MainCharacterImage;
    public GameObject BlueManImage;
    public GameObject WatcherImage;
    public GameObject SenatorImage;
    public GameObject GuadianImage;
    public Text Dialoguetext;
    private string[] Dialogue = new string[28];
    private int DialogueInt;

    public AudioSource ClickSound;
    private bool Clickbool;

    private int TextInt;
    private bool Playernearbool;
    private bool CanvasOnbool;
    private SpriteRenderer Rend;

    public static bool FirstEpisodeEndbool;

    public SpriteRenderer BackGround;
    public Transform MainCameraTransform;
    private float EndTime;

    public Text WhereText;             //ž �߰��� ���
    public Text CrowFirstText;         //'��ƽ�Ʈ'�� �Ҹ�Ǿ��ٶ�...
    public Text CrowSecondText;        //��ȹ�� �����ؾ߰ھ�...
    public Text ChapterEndText;        // é�� 1 - �� ���� ������
    public Text MakerNameText;         // ������ : Triple I (1�ΰ���)
    public Text UnityText;
    public Text HowlongtomakeText;
    public Text ArtText;
    public Text MusicText;
    public Text ThankText;

    public GameObject ToMainMenuButton;

    public GameObject BoomAudio;
    public GameObject LastBGM;

    // Start is called before the first frame update
    void Start()
    {
        NPCCanvas.SetActive(false);
        CanvasOnbool = false;
        Rend = GetComponent<SpriteRenderer>();
        BoomAudio.SetActive(false);
        LastBGM.SetActive(false);
        BlueManImage.SetActive(false);
        WatcherImage.SetActive(false);
        GuadianImage.SetActive(false);
        SenatorImage.SetActive(false);
        MainCharacterImage.SetActive(false);
        DialogueInt = 28;
        TextInt = 0;

        FirstEpisodeEndbool = false;
        BackGround.color = new Color(0, 0, 0, 0);
        ChapterEndText.color = new Color(1, 1, 1, 0);
        ThankText.color = new Color(1, 1, 1, 0);
        CrowFirstText.color = new Color(1, 1, 1, 0);
        CrowSecondText.color = new Color(1, 1, 1, 0);
        MakerNameText.color = new Color(1, 1, 1, 0);
        UnityText.color = new Color(1, 1, 1, 0);
        HowlongtomakeText.color = new Color(1, 1, 1, 0);
        ArtText.color = new Color(1, 1, 1, 0);
        MusicText.color = new Color(1, 1, 1, 0);
        ThankText.color = new Color(1, 1, 1, 0);
        WhereText.color = new Color(1, 1, 1, 0);
        ToMainMenuButton.SetActive(false);

        EndTime = 0;
        Clickbool = false;
    }

    // Update is called once per frame
    void Update()
    {
        TextIntString();
        ImageOnWhen();

        if (Playernearbool == true)
        {
            if (Input.GetKeyDown(KeyCode.G) && CanvasOnbool == false
                && MainCharacter.GetComponent<Rigidbody2D>().velocity.x == 0 && MainCharacter.GetComponent<Rigidbody2D>().velocity.y == 0
                && MainCharacterController.Dashingbool == false)
            {
                PlayButtonManager.CantPressPausebool = true;
                ClickSound.Play();
                NPCCanvas.SetActive(true);
                MainCharacterController.CharacterCantMovebool = true;
                CanvasOnbool = true;
            }
        }

        if(FirstEpisodeEndbool == true)
        {
            EndTime += Time.deltaTime;
            if(EndTime > 0 && EndTime < 2)
            {
                
                CameraFollow.CameraControlbool = true;
                BackGround.color = new Color(0, 0, 0, 1);
            }
            if (EndTime > 2 && EndTime < 4)
            {
                WhereText.color = new Color(1, 1, 1, 1);
                BackGround.color = new Color(0, 0, 0, 1);
            }
            if (EndTime > 4 && EndTime < 5)
            {
                
                MainCameraTransform.position = new Vector3(520.15f, 105.95f, -10);
                WhereText.color = new Color(1, 1, 1, 5 - EndTime);
                BackGround.color = new Color(0, 0, 0, 5 - EndTime);
            }
            if (EndTime > 5 && EndTime < 7)
            {
                WhereText.color = new Color(1, 1, 1, 0);
                BackGround.color = new Color(0, 0, 0, 0);
            }
            if (EndTime > 7 && EndTime < 11)
            {
                if(Clickbool == false)
                {
                    ClickSound.Play();
                    Clickbool = true;
                }
                   
                CrowFirstText.color = new Color(1, 1, 1, 1);
            }
            if (EndTime > 11 && EndTime < 13)
            {
                CrowFirstText.color = new Color(1, 1, 1, 0);
            }
            if (EndTime > 13 && EndTime < 17)
            {
                if (Clickbool == true)
                {
                    ClickSound.Play();
                    Clickbool = false;
                }
                CrowSecondText.color = new Color(1, 1, 1, 1);
            }
            if (EndTime > 17 && EndTime < 21f)
            {
                BoomAudio.SetActive(true);
                CrowSecondText.color = new Color(1, 1, 1, 0);
                BackGround.color = new Color(0, 0, 0, 1);
                ChapterEndText.color = new Color(1, 1, 1, 1);

            }
            if (EndTime > 21f && EndTime < 21.5f)
            {
                ChapterEndText.color = new Color(1, 1, 1, 0);

            }
            if (EndTime > 21.5f && EndTime < 26.5f)
            {
                LastBGM.SetActive(true);
                ToMainMenuButton.SetActive(true);
                MakerNameText.color = new Color(1, 1, 1, 1);
                UnityText.color = new Color(1, 1, 1, 0);
                HowlongtomakeText.color = new Color(1, 1, 1, 0);
                ArtText.color = new Color(1, 1, 1, 0);
                MusicText.color = new Color(1, 1, 1, 0);
                
            }
            if (EndTime > 26.5f && EndTime < 27f)
            {
                
                MakerNameText.color = new Color(1, 1, 1, 0);
            }
            if (EndTime > 27f && EndTime < 32f)
            {
                
                UnityText.color = new Color(1, 1, 1, 1);
                HowlongtomakeText.color = new Color(1, 1, 1, 0);
                ArtText.color = new Color(1, 1, 1, 0);
                MusicText.color = new Color(1, 1, 1, 0);
            }
            if (EndTime > 32f && EndTime < 32.5f)
            {
                
                UnityText.color = new Color(1, 1, 1, 0);
            }
            if (EndTime > 32.5f && EndTime < 37.5f)
            {
                
                HowlongtomakeText.color = new Color(1, 1, 1, 1);
                ArtText.color = new Color(1, 1, 1, 0);
                MusicText.color = new Color(1, 1, 1, 0);
            }
            if (EndTime > 37.5f && EndTime < 38f)
            {
                
                HowlongtomakeText.color = new Color(1, 1, 1, 0);
            }
            if (EndTime > 38f && EndTime < 43f)
            {
                
                ArtText.color = new Color(1, 1, 1, 1);
                MusicText.color = new Color(1, 1, 1, 0);
            }
            if (EndTime > 43f && EndTime < 43.5f)
            {
                
                ArtText.color = new Color(1, 1, 1, 0);
            }
            if (EndTime > 43.5f && EndTime < 48.5f)
            {
                MusicText.color = new Color(1, 1, 1, 1);
            }
            if (EndTime > 48.5f && EndTime < 49f)
            {
                MusicText.color = new Color(1, 1, 1, 0);
            }
            if (EndTime > 49f && EndTime < 54)
            {
                ThankText.color = new Color(1, 1, 1, 1);
            }
            if (EndTime > 54f && EndTime < 55)
            {
                ThankText.color = new Color(1, 1, 1, 55 - EndTime);
            }
            if (EndTime > 55f && EndTime < 56)
            {
                ThankText.color = new Color(1, 1, 1, 0);
                LastBGM.SetActive(false);
            }
            if (EndTime > 56f)
            {
                PlayerPrefs.DeleteAll();
                SceneManager.LoadScene("MainMenu");

            }
        }
    }

    public void LoadToMainMenuButton()
    {
        PlayerPrefs.DeleteAll();
        SceneManager.LoadScene("MainMenu");
    }

    private void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            Playernearbool = true;
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.tag == "Player")
        {
            Playernearbool = false;
        }
    }

    public void OutButton()
    {

        //PlayButtonManager.CantPressPausebool = false;
        NPCCanvas.SetActive(false);
        ClickSound.Play();
        //MainCharacterController.CharacterCantMovebool = false;
        CanvasOnbool = false;
        TextInt = 0;

        FirstEpisodeEndbool = true;
    }

    public void NextOnButton()
    {
        ClickSound.Play();
        if (TextInt >= 0 && TextInt < DialogueInt && CanvasOnbool == true)
        {
            TextInt += 1;
        }
    }

    public void BeforeOnButton()
    {
        ClickSound.Play();
        if (TextInt > 0 && TextInt <= DialogueInt && CanvasOnbool == true)
        {
            TextInt -= 1;
        }

    }

    private void ImageOnWhen()
    {
        switch (TextInt)
        {
            case 0:
                Dialoguetext.text = Dialogue[TextInt];
                Dialoguetext.color = new Color(1, 1, 1, 1);
                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(true);

                EndButton.SetActive(false);
                NextButton.SetActive(true);
                BackButton.SetActive(false);
                break;
            case 1:
                Dialoguetext.text = Dialogue[TextInt];
                BackButton.SetActive(true);

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);

                break;
            case 2:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(true);
                break;
            case 3:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 4:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(true);
                break;
            case 5:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(true);
                break;
            case 6:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(true);
                break;
            case 7:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(true);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 8:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 9:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(true);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 10:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(true);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 11:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(true);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 12:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(true);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 13:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(true);
                SenatorImage.SetActive(false);
                break;
            case 14:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 15:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(true);
                break;
            case 16:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(true);
                break;
            case 17:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(true);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 18:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 19:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(true);
                break;
            case 20:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 21:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(true);
                break;
            case 22:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(true);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 23:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 24:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(true);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);
                break;
            case 25:
                Dialoguetext.text = Dialogue[TextInt];

                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(true);
                break;
            case 26:
                Dialoguetext.text = Dialogue[TextInt];
                Dialoguetext.color = new Color(1, 1, 1, 1);
                MainCharacterImage.SetActive(false);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);

                EndButton.SetActive(false);
                NextButton.SetActive(true);
                break;
            case 27:
                Dialoguetext.text = Dialogue[TextInt];
                Dialoguetext.color = new Color(1, 0, 0, 1);
                MainCharacterImage.SetActive(true);
                BlueManImage.SetActive(false);
                WatcherImage.SetActive(false);
                GuadianImage.SetActive(false);
                SenatorImage.SetActive(false);

                EndButton.SetActive(true);
                NextButton.SetActive(false);
                break;

            default:
                return;
        }
    }

    private void TextIntString()
    {
        Dialogue[0] = "�����߱�. �� �ڰ� '��ƽ�Ʈ'�� �����߸� ���ΰ�?";
        Dialogue[1] = "(�����ϴ� �װ� �ٷ� �� �ٸ� ������ '����'�� �� ������. �Ķ� �߱��� ���� ���� �ѷ��� ����̿���.)";
        Dialogue[2] = "��ħ �̾߱⸦ �����Ϸ��� ���̳�... �����...";
        Dialogue[3] = "(�״� �׳డ �ٰ����� �ٷ� ���ħ�� �ϰ��� �������� ����.)";
        Dialogue[4] = "�ٽ� ��������... '��ƽ�Ʈ'�Ӹ� �ƴ϶� �ٸ� �̵鵵 ���������� ���ߴٴ°Ŵ�.";
        Dialogue[5] = "�츮�� �ִ� �� ���� ���� ��ȣ�ڰ� �����Ǿ���, ���������� ���ߴ�. ��ġ �̼��� �Ҿ���� �� ó��...";
        Dialogue[6] = "�׷��� �ϳ� ������ ������... �̷� ���� �����ϰ� ���� �� �ִ� �ɷ��� �ִ� �ڴ� �� �ڻ�... �츮�� â���ִ�, Ȥ��...";
        Dialogue[7] = "'�ƼҸ�'...";
        Dialogue[8] = "('���̸�'�� �����ߴٴ� �� '�ƼҸ�'��� �̸��� �������.)";
        Dialogue[9] = "'�ƼҸ�'�� �����ΰ���?";
        Dialogue[10] = "'�ƼҸ�'�� �츮���� ��ŵ��� ���� ���ڸ� ������ ���Դϴ�. ���� ���߾���? �ҿ����� ���ɾ��� �������� �����ִٴ�...";
        Dialogue[11] = "��...! ��... ����մϴ�.";
        Dialogue[12] = "�״� ���ڸ� �˷��� �� �Ӹ��ƴ϶� ���� ó������ ����� ������ �־���... â���ִ԰��� ���� �ٸ�... ";
        Dialogue[13] = "@&@$*$# ^%*&(>{[ &$(&#!";
        Dialogue[14] = "('����' ���� �ִ� ���ٴϴ� ���� ���𰡰� �׵��� ���� ���� ���ϴ� �� �ߴ�.)";
        Dialogue[15] = "�׷� ����... â���ִԲ��� �׷� ���� ���� ���� ����� �ƴ���.";
        Dialogue[16] = "'�ƼҸ�'������ �̷� ���� �Ұ�����... '��ƽ�Ʈ' ���� �� �ڷ� ���� ���������� �����Ѱɰž�... Ȯ����!";
        Dialogue[17] = "������... �츮���� �׷� ���� �� ������ �ֽ��ϱ�? ���� �׷� ���� �Ϸ��� �ܺ��� ������ �츮���� ������ �ʿ䰡 �����ٵ�...";
        Dialogue[18] = "(�״� Ȯ�ſ� �� ������ ������ ��Ҹ��� ���� �ָ� ���ߴ�.)";
        Dialogue[19] = "�� �ٸ� ���Ű� �ִٳ�... '�ƼҸ�'�� �����ϴ� ���� �߰��ؼ� �� ���� �ڷḦ ���� ���캸����...";
        Dialogue[20] = "(�״� �ڽ��� �ָӴϿ� ���� ������ � ���̿� ���� ���� ���´�. ��ε� �� ���̿� �ü��� ���ߵ��� �״� ���� �̾��.)";
        Dialogue[21] = "�̰� ������ ���� �������� �ڼ����� �� �� ������... �� �� �ִ� �κ��� ���ϸ�...";
        Dialogue[22] = "����ü... �籸��... ���ϼ�ü... ���� ����... ����...â��...����...";
        Dialogue[23] = "(�ϳ� �����ε��ٰ� ������ �κе� �־� �� ������ �ʾ����� ������ �۱Ͱ� Ȯ���ߴ�.)";
        Dialogue[24] = "��... Ȯ���� ������ ���� ���̳׿�... ";
        Dialogue[25] = "�׸��� �̰͵� ����...";
        Dialogue[26] = "(�װ� ���� ���� �Ѱܺ��� �̹��� �������� ���� �׸��� �׷����ְ� ����������...)";
        Dialogue[27] = "�ҿ��� ��...������ ���...?";
    }
}
