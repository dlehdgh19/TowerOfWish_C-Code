using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossBody : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Physics2D.IgnoreLayerCollision(6, 16);
        Physics2D.IgnoreLayerCollision(16, 20);
        Physics2D.IgnoreLayerCollision(18, 20);
    }
}
