using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Testing2 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Physics2D.IgnoreLayerCollision(6, 20);
        Physics2D.IgnoreLayerCollision(7, 20);
        Physics2D.IgnoreLayerCollision(8, 20);
        Physics2D.IgnoreLayerCollision(9, 20);
        Physics2D.IgnoreLayerCollision(16, 20);
        Physics2D.IgnoreLayerCollision(18, 20);
    }
}
