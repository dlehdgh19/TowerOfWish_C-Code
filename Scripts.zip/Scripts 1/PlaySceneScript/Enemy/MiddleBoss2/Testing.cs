using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Testing : MonoBehaviour
{
    public Transform MainCharacterTransform;
    private float RememberCharacterPosition_X;
    public Transform CurrentPosition;
    private float RememberBossPosition_X;
    private Animator animator;
    private Rigidbody2D rb;
    public float JumpForce;
    private bool groundbool;
    private bool jumpbool;
    private bool jumponcebool;
    private float time1;
    private float time2;

    private float distance;
    
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        time1 = 0;
        time2 = 0;
    }

    // Update is called once per frame
    void Update()
    {
        
         
        

        if(Input.GetKeyDown(KeyCode.B) && groundbool == true)
        {
            RememberCharacterPosition_X = MainCharacterTransform.position.x;
            RememberBossPosition_X = CurrentPosition.position.x;
            distance = RememberBossPosition_X - RememberCharacterPosition_X;
            Debug.Log(distance);
            Debug.Log(RememberCharacterPosition_X);
            Debug.Log(RememberBossPosition_X);
            animator.SetBool("Testbool1", true);
            jumpbool = true;
            time1 = 0;
        }

        if(jumpbool == true)
        {
            time1 += Time.deltaTime;
            if(time1 > 0.7f && time1 < 2.3f)
            {
                CurrentPosition.position = new Vector2(CurrentPosition.position.x - (distance * Time.deltaTime * 0.55f) , CurrentPosition.position.y);
            }
            if(time1 > 0.7f && jumponcebool == false)
            {
                rb.AddForce(Vector2.up * JumpForce, ForceMode2D.Impulse);
                jumponcebool = true;
                animator.SetBool("Testbool1", false);
            }
            if(time1 > 2.3f && time1 < 3.1f)
            {
                animator.SetBool("Testbool2", true);
            }
            if (time1 > 3.1f)
            {
                animator.SetBool("Testbool2", false);
                time1 = 0;
                jumpbool = false;
                jumponcebool = false;
            }

        }

    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.collider.CompareTag("Ground"))
        {
            groundbool = true;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Ground"))
        {
            groundbool = false;
        }
    }


}
