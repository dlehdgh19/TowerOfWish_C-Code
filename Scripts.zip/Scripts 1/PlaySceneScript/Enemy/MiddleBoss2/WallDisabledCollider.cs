using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WallDisabledCollider : MonoBehaviour
{
    private Animator anim;
    private bool AfterDeadbool;
    private BoxCollider2D Col;
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        if(PlayButtonManager.BossesInt >= 8)
        {
            AfterDeadbool = true;
            anim.SetBool("AfterDeadBool", true);
            GetComponent<BoxCollider2D>().enabled = false;
        }
        else if (PlayButtonManager.BossesInt < 8)
        {
            AfterDeadbool = false;
            anim.SetBool("AfterDeadBool", false);
            GetComponent<BoxCollider2D>().enabled = true;
        }
    }

    // Update is called once per frame
    void Update()
    {
        if(MiddleBoss2.AfterDeadbool == true)
        {
            AfterDeadbool = true;
        }

        if(AfterDeadbool == true)
        {
            anim.SetBool("AfterDeadBool", true);
            GetComponent<BoxCollider2D>().enabled = false;
        }
    }
}
