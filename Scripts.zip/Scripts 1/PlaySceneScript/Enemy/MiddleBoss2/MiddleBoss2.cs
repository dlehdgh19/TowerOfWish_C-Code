using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MiddleBoss2 : MonoBehaviour
{
    private Vector3 velocity = Vector3.zero;
    public Transform MainCharacter;
    public Transform BossTransform;
    public Transform MainCameraTransform;
    private Rigidbody2D rb;
    private SpriteRenderer SR;
    private bool groundbool;

    [SerializeField]
    private GameObject[] Audios;

    /*
        Audios[0] = RushAudio
        Audios[1] = ReadytoRushAudio
        Audios[2] = JumpAudio
        Audios[3] = WeakGroundAttackAudio
        Audios[4] = StrongGroundAttackAudio
        Audios[5] = FrontAttackAudio
        Audios[6] = SpitAudio
        Audios[7] = DeadAudio
        Audios[8] = DeadTextAudio
    */

    public GameObject[] Spears;
    public GameObject BelowBlock;

    [SerializeField]
    private GameObject[] HitEffect;

    [SerializeField]
    private AudioSource[] HitAudio;

    [SerializeField]
    private GameObject[] WaveSpawnObjects;

    private Animator animator;
    public GameObject RushEffect;
    public GameObject RushCollider;
    public GameObject WalkCollider;
    public GameObject AirCollider;
    public GameObject GroundAttackCollider;
    public GameObject SpitCollider;
    public GameObject OneLegGroundAttackCollider;

    public static bool FirstMatchbool;
    private float FirstMatchTime;
    private float FirstMatchTime2;

    private bool PatternStartbool;
    private float IdleRandomTime;
    private float IdleTime;
    private bool Idlebool;
    private int RandomPatternInt;
    private bool PatternProgressbool;
    private bool PatternDecidebool;
    private bool AfterPatternDecidedbool;
    private bool Pattern0bool;
    private bool Pattern1bool;
    private bool Pattern2bool;
    private bool Pattern3bool;
    private bool Pattern4bool;
    private bool Pattern5bool;
    private float PatternTime0;
    private float PatternTime1;
    private float PatternTime2_1;
    private float PatternTime2_2;
    private float PatternTime3;
    private bool SpawnWavebool;
    private float PatternTime4;
    private float PatternTime5;
    private bool WhereCharacterCheckbool;

    public static bool Deadbool;
    private float DeadTime;
    public Text DeadText;
    public Text BossNameText;
    public GameObject HealthCanvas;
    private int health;

    private bool hurtbool;

    public static bool BGMStopbool;
    public static bool BGMChangebool;

    private float distance;
    private bool Decidedistancebool;

    public static bool AfterDeadbool;

    // Start is called before the first frame update
    void Start()
    {
        FirstMatchTime2 = 0;
        for (int i = 0; i < Audios.Length; i++)
        {
            Audios[i].SetActive(false);
        }
        animator = GetComponent<Animator>();
        Deadbool = false;
        DeadTime = 0;
        HealthCanvas.SetActive(false);

        health = 300;
        hurtbool = false;
        BGMStopbool = false;
        BGMChangebool = false;
        DeadText.color = new Color(1, 1, 1, 0);
        BossNameText.color = new Color(1, 1, 1, 0);

        Spears[0].SetActive(false);
        Spears[1].SetActive(false);
        rb = GetComponent<Rigidbody2D>();
        RushEffect.SetActive(false);
        SR = GetComponent<SpriteRenderer>();
        SR.color = new Color(1, 1, 1, 1);
        this.transform.position = new Vector2(42.62f, 181f);
        
        groundbool = false;
        BelowBlock.SetActive(true);
        PatternStartbool = false;
        IdleTime = 0;
        Idlebool = false;
        PatternDecidebool = false;
        AfterPatternDecidedbool = false;
        WalkCollider.SetActive(false);
        WhereCharacterCheckbool = false;
        RushCollider.SetActive(false);
        AirCollider.SetActive(false);
        Decidedistancebool = false;
        GroundAttackCollider.SetActive(false);
        SpitCollider.SetActive(false);
        OneLegGroundAttackCollider.SetActive(false);
        SpawnWavebool = false;

        Pattern0bool = false;
        Pattern1bool = false;
        Pattern2bool = false;
        Pattern3bool = false;
        Pattern4bool = false;
        Pattern5bool = false;

        PatternTime0 = 0;
        PatternTime1 = 0;
        PatternTime2_1 = 0;
        PatternTime2_2 = 0;
        PatternTime3 = 0;
        PatternTime4 = 0;
        PatternTime5 = 0;

        AfterDeadbool = false;
    }

    // Update is called once per frame
    void Update()
    {
        AllReset();

        if (MainCharacter.position.x < 34 && MainCharacter.position.y > 160 && MainCharacter.position.y < 170 && FirstMatchbool == false && PatternStartbool == false && Deadbool == false)
        {
            BGMStopbool = true;

            PlayButtonManager.CantPressPausebool = true;
            Spears[0].SetActive(true);
            Spears[1].SetActive(true);
            HealthCanvas.SetActive(true);
            FirstMatchbool = true;
        }

        if(FirstMatchbool == true && PatternStartbool == false && Deadbool == false)
        {
            FirstMatchTime += Time.deltaTime;
            
            if(FirstMatchTime > 1f && FirstMatchTime < 1.5f)
            {
                BelowBlock.SetActive(false);
                CameraFollow.CameraControlbool = true;
                MainCharacterController.CharacterCantMovebool = true;
                MainCameraTransform.position = Vector3.SmoothDamp(MainCameraTransform.position, new Vector3(38.54f, 168.6f, -10), ref velocity, 0.2f);
                animator.SetBool("FirstMatchBool", true);
                
            }
            if(FirstMatchTime > 1.5f && FirstMatchTime < 2f)
            {
                MainCameraTransform.position = new Vector3(38.54f, 168.6f, -10);

            }
            
            if (FirstMatchTime > 1.5f)
            {
                if(groundbool == false)
                {
                    animator.SetBool("FirstMatchBool", true);
                }

                if (groundbool == true)
                {
                    animator.SetBool("FirstMatchBool", false);
                    Audios[4].SetActive(true);
                    FirstMatchTime2 += Time.deltaTime;
                    if(FirstMatchTime2 > 1.3f)
                    {
                        Audios[1].SetActive(true);
                    }
                }

            }
            if (FirstMatchTime > 2f && FirstMatchTime < 3f)
            {
                BossNameText.color = new Color(1, 1, 1, FirstMatchTime - 2f);
            }
            if (FirstMatchTime > 4.5f && FirstMatchTime < 5f)
            {
                MainCharacterController.CharacterCantMovebool = false;
            }
            if (FirstMatchTime > 4f && FirstMatchTime < 5f)
            {
                BossNameText.color = new Color(1, 1, 1, 5f - FirstMatchTime);
            }
            
            if (FirstMatchTime > 5f)
            {
                BossNameText.color = new Color(1, 1, 1, 0);

                BGMStopbool = false;
                BGMChangebool = true;
                PlayPortalManager.BGMPlayOncebool = false;
                Audios[1].SetActive(false);
                Audios[4].SetActive(false);
                FirstMatchTime = 0;
                PatternStartbool = true;
            }
        }

        if(PatternStartbool == true && Deadbool == false)
        {
            if(PatternProgressbool == false)
            {
                IdleTime += Time.deltaTime;
            }
            if (Idlebool == false && PatternProgressbool == false)
            {
                IdleRandomTime = Random.Range(0.5f, 1f);
                Idlebool = true;
            }
            if(IdleTime > IdleRandomTime && PatternProgressbool == false)
            {
                PatternProgressbool = true;
            }

            if(PatternProgressbool == true)
            {
                IdleTime = 0;
                Pattern();
                Case();
            }
        }

        if(Deadbool == true)
        {
            DeadTime += Time.deltaTime;
            if(DeadTime > 0 && DeadTime < 1.3f)
            {
                CharacterUI_HP_SkillCoolDown.Revivebool = true;

                
                DeadText.color = new Color(1, 1, 1, 0);
                BossNameText.color = new Color(1, 1, 1, 0);

                RushEffect.SetActive(false);

                rb.velocity = Vector2.zero;

                BelowBlock.SetActive(true);
                PatternStartbool = false;
                IdleTime = 0;
                Idlebool = false;
                PatternProgressbool = false;
                PatternDecidebool = false;
                AfterPatternDecidedbool = false;
                WalkCollider.SetActive(false);
                WhereCharacterCheckbool = false;
                RushCollider.SetActive(false);
                AirCollider.SetActive(false);
                Decidedistancebool = false;
                GroundAttackCollider.SetActive(false);
                SpitCollider.SetActive(false);
                OneLegGroundAttackCollider.SetActive(false);
                SpawnWavebool = false;
                WhereCharacterCheckbool = false;

                Pattern0bool = false;
                Pattern1bool = false;
                Pattern2bool = false;
                Pattern3bool = false;
                Pattern4bool = false;
                Pattern5bool = false;

                PatternTime0 = 0;
                PatternTime1 = 0;
                PatternTime2_1 = 0;
                PatternTime2_2 = 0;
                PatternTime3 = 0;
                PatternTime4 = 0;
                PatternTime5 = 0;

                animator.SetBool("SpitBool", false);
                animator.SetBool("FrontAttackBool", false);
                animator.SetBool("HighJumpBool", false);
                animator.SetBool("LowJumpBool", false);
                animator.SetBool("GroundAttachBool", false);
                animator.SetBool("RushReadyBool", false);
                animator.SetBool("RushBool", false);
                animator.SetBool("WalkBool", false);
                animator.SetBool("DeadBool", true);
                for (int i = 0; i < 7; i++)
                {
                    Audios[i].SetActive(false);
                }
                Audios[7].SetActive(true);

                BGMChangebool = false;
                BGMStopbool = true;
            }
            if (DeadTime > 1.3f && DeadTime < 2f)
            {
                SR.color = new Color(1, 1, 1, 0);
            }
            if (DeadTime > 3f && DeadTime < 4f)
            {
                Audios[8].SetActive(true);
                DeadText.color = new Color(0.8f, 0.8f, 0, DeadTime - 3);
            }
            if (DeadTime > 4f && DeadTime < 7f)
            {
                DeadText.color = new Color(0.8f, 0.8f, 0, 1);
            }
            if (DeadTime > 7f && DeadTime < 8f)
            {
                DeadText.color = new Color(0.8f, 0.8f, 0, 8 - DeadTime);
            }
            if (DeadTime > 8f && DeadTime < 9f)
            {
                BGMStopbool = false;
                PlayPortalManager.BGMPlayOncebool = false;
                DeadText.color = new Color(0.8f, 0.8f, 0, 0);
                CameraFollow.CameraControlbool = false;
                PlayButtonManager.CantPressPausebool = false;
                PlayButtonManager.BossesInt = 8;
                AfterDeadbool = true;
            }
            if (DeadTime > 10f)
            {
                this.gameObject.SetActive(false);
            }
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if((collision.tag == "Slash1" || collision.tag == "Slash2" || collision.tag == "Slash3") && Deadbool == false)
        {
            if(health > 0)
            {
                int damage = Random.Range(2, 4);
                Instantiate(HitEffect[Random.Range(0, 2)], 
                    (new Vector2(Random.Range(this.gameObject.transform.position.x - 1, this.gameObject.transform.position.x + 1), 
                    Random.Range(this.gameObject.transform.position.y - 2, this.gameObject.transform.position.y - 1))), 
                    Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360))));
                HitAudio[Random.Range(0, 2)].Play();
                health = health - damage;
            }
            if(health <= 0)
            {
                int damage = Random.Range(2, 4);
                Instantiate(HitEffect[Random.Range(0, 2)],
                    (new Vector2(Random.Range(this.gameObject.transform.position.x - 1, this.gameObject.transform.position.x + 1),
                    Random.Range(this.gameObject.transform.position.y - 2, this.gameObject.transform.position.y - 1))),
                    Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360))));
                health = health - damage;
                Deadbool = true;
            }
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Ground"))
        {
            groundbool = true;
        }
    }

    private void OnCollisionExit2D(Collision2D collision)
    {
        if (collision.collider.CompareTag("Ground"))
        {
            groundbool = false;
        }
    }

    private void Pattern()
    {
        if(PatternDecidebool == false && Detected.Detectedbool == true && Deadbool == false)
        {
            RandomPatternInt = Random.Range(1, 6);
            // 1 = Rush
            // 2 = Jump
            // 3 = HighJump
            // 4 = Leg Forward
            // 5 = Spit
            PatternTime0 = 0;
            PatternTime1 = 0;
            PatternTime2_1 = 0;
            PatternTime2_2 = 0;
            PatternTime3 = 0;
            PatternTime4 = 0;
            PatternTime5 = 0;
            PatternDecidebool = true;
        }
        if (PatternDecidebool == false && Detected.Detectedbool == false && Deadbool == false)
        {
            RandomPatternInt = Random.Range(0, 4);
            // 0 = Walk
            // 1 = Rush
            // 2 = Jump
            // 3 = HighJump
            PatternTime0 = 0;
            PatternTime1 = 0;
            PatternTime2_1 = 0;
            PatternTime2_2 = 0;
            PatternTime3 = 0;
            PatternTime4 = 0;
            PatternTime5 = 0;
            PatternDecidebool = true;
        }

        if(PatternDecidebool == true && Deadbool == false)
        {
            switch(RandomPatternInt)
            {
                case 0:
                    Pattern0bool = true;
                    break;
                case 1:
                    Pattern1bool = true;
                    break;
                case 2:
                    Pattern2bool = true;
                    break;
                case 3:
                    Pattern3bool = true;
                    break;
                case 4:
                    Pattern4bool = true;
                    break;
                case 5:
                    Pattern5bool = true;
                    break;

                default:
                    break;
            }
        }
    }

    private void Case()
    {
        if(Pattern0bool == true && Deadbool == false)
        {
            PatternTime0 += Time.deltaTime;
            if (PatternTime0 > 0 && PatternTime0 < 2)
            {
                animator.SetBool("WalkBool", true);
                if(MainCharacter.position.x > this.transform.position.x)
                {
                    if(WhereCharacterCheckbool == false)
                    {
                        this.transform.localScale = new Vector3(-6.5f, 6.5f, 6.5f);
                        WalkCollider.SetActive(true);
                        WhereCharacterCheckbool = true;
                    }
                }
                else if (MainCharacter.position.x <= this.transform.position.x)
                {
                    if (WhereCharacterCheckbool == false)
                    {
                        this.transform.localScale = new Vector3(6.5f, 6.5f, 6.5f);
                        WalkCollider.SetActive(true);
                        WhereCharacterCheckbool = true;
                    }
                }
                if(WhereCharacterCheckbool == true)
                {
                    if(this.transform.localScale.x > 0)
                    {
                        rb.velocity = Vector2.left * 2;
                    }
                    if (this.transform.localScale.x < 0)
                    {
                        rb.velocity = Vector2.right * 2;
                    }
                }
            }
            if (PatternTime0 > 2)
            {
                WalkCollider.SetActive(false);
                rb.velocity = Vector2.zero;
                animator.SetBool("WalkBool", false);
                //PatternTime0 = 0;
                Idlebool = false;
                PatternProgressbool = false;
                PatternDecidebool = false;
                IdleTime = 0;
                WhereCharacterCheckbool = false;
                Pattern0bool = false;
            }
        }

        if(Pattern1bool == true && Deadbool == false)
        {
            PatternTime1 += Time.deltaTime;
            if(PatternTime1 > 0f && PatternTime1 < 0.33f)
            {
                animator.SetBool("RushReadyBool", true);
                if (MainCharacter.position.x > this.transform.position.x)
                {
                    if (WhereCharacterCheckbool == false)
                    {
                        this.transform.localScale = new Vector3(-6.5f, 6.5f, 6.5f);
                        WhereCharacterCheckbool = true;
                    }
                }
                if (MainCharacter.position.x <= this.transform.position.x)
                {
                    if (WhereCharacterCheckbool == false)
                    {
                        this.transform.localScale = new Vector3(6.5f, 6.5f, 6.5f);
                        WhereCharacterCheckbool = true;
                    }
                }
            }
            if (PatternTime1 > 0.33f && PatternTime1 < 0.5f)
            {
                Audios[1].SetActive(true);
            }
            if (PatternTime1 > 1.08f && PatternTime1 < 2.5f)
            {
                RushCollider.SetActive(true);
                Audios[0].SetActive(true);
                animator.SetBool("RushReadyBool", false);
                animator.SetBool("RushBool", true);
                RushEffect.SetActive(true);
                if(this.transform.localScale.x > 0)
                {
                    rb.velocity = Vector2.left * 12f;
                }
                if (this.transform.localScale.x < 0)
                {
                    rb.velocity = Vector2.right * 12f;
                }
            }
            if (PatternTime1 > 2.5f)
            {
                Audios[0].SetActive(false);
                RushCollider.SetActive(false);
                RushEffect.SetActive(false);
                animator.SetBool("RushReadyBool", false);
                animator.SetBool("RushBool", false);
                rb.velocity = Vector2.zero;
                Audios[1].SetActive(false);
                //PatternTime1 = 0;
                Idlebool = false;
                PatternProgressbool = false;
                PatternDecidebool = false;
                IdleTime = 0;
                WhereCharacterCheckbool = false;
                Pattern1bool = false;
            }
        }

        if(Pattern2bool == true && Deadbool == false)
        {
            PatternTime2_1 += Time.deltaTime;
            
            if(PatternTime2_1 > 0 && PatternTime2_1 < 0.7f)
            {
                if (MainCharacter.position.x > this.transform.position.x)
                {
                    if (WhereCharacterCheckbool == false)
                    {
                        this.transform.localScale = new Vector3(-6.5f, 6.5f, 6.5f);
                        WhereCharacterCheckbool = true;
                    }
                }
                if (MainCharacter.position.x <= this.transform.position.x)
                {
                    if (WhereCharacterCheckbool == false)
                    {
                        this.transform.localScale = new Vector3(6.5f, 6.5f, 6.5f);
                        WhereCharacterCheckbool = true;
                    }
                }
                if (Decidedistancebool == false)
                {
                    distance = this.transform.position.x - MainCharacter.position.x;
                    animator.SetBool("LowJumpBool", true);
                    AirCollider.SetActive(true);
                    Decidedistancebool = true;
                }
                
            }
            if(PatternTime2_1 > 0.7f && PatternTime2_1 < 2.3f)
            {
                Audios[2].SetActive(true);
                this.transform.position = new Vector2(this.transform.position.x - (distance * 0.63f * Time.deltaTime), this.transform.position.y);
                if (Decidedistancebool == true)
                {
                    rb.AddForce(Vector2.up * 13.5f, ForceMode2D.Impulse);
                    Decidedistancebool = false;
                }
            }
            if (PatternTime2_1 > 2.3f)
            {
                if(groundbool == true)
                {
                    AirCollider.SetActive(false);
                    GroundAttackCollider.SetActive(true);
                    PatternTime2_2 += Time.deltaTime;
                    if (PatternTime2_2 > 0f && PatternTime2_2 < 0.8f)
                    {
                        Audios[3].SetActive(true);
                        animator.SetBool("GroundAttachBool", true);
                    }
                    if (PatternTime2_2 > 0.8f)
                    {
                        GroundAttackCollider.SetActive(false);
                        AirCollider.SetActive(false);
                        Audios[2].SetActive(false);
                        Audios[3].SetActive(false);
                        animator.SetBool("LowJumpBool", false);
                        animator.SetBool("GroundAttachBool", false);
                        rb.velocity = Vector2.zero;
                        //PatternTime2_1 = 0;
                        //PatternTime2_2 = 0;
                        Idlebool = false;
                        Decidedistancebool = false;
                        PatternProgressbool = false;
                        PatternDecidebool = false;
                        IdleTime = 0;
                        WhereCharacterCheckbool = false;
                        Pattern2bool = false;
                    }
                }
            }
        }

        if(Pattern3bool == true && Deadbool == false)
        {
            PatternTime3 += Time.deltaTime;
            if(PatternTime3 > 0 && PatternTime3 < 1.7)
            {
                rb.velocity = Vector2.zero;
                animator.SetBool("HighJumpBool", true);
                GroundAttackCollider.SetActive(true);
            }
            if (PatternTime3 > 0.7 && PatternTime3 < 1)
            {
                Audios[2].SetActive(true);
            }
            if (PatternTime3 > 1.7f && SpawnWavebool == false)
            {
                Audios[4].SetActive(true);
                Instantiate(WaveSpawnObjects[0], new Vector2((transform.position.x - 1), transform.position.y - 1.3f), Quaternion.identity);
                Instantiate(WaveSpawnObjects[1], new Vector2((transform.position.x + 1), transform.position.y - 1.3f), Quaternion.identity);
                SpawnWavebool = true;
            }
            if(PatternTime3 > 2.6f)
            {
                rb.velocity = Vector2.zero;
                GroundAttackCollider.SetActive(false);
                animator.SetBool("HighJumpBool", false);
                SpawnWavebool = false;
                Audios[2].SetActive(false);
                Audios[4].SetActive(false);
                Idlebool = false;
                Decidedistancebool = false;
                PatternProgressbool = false;
                PatternDecidebool = false;
                IdleTime = 0;
                WhereCharacterCheckbool = false;
                Pattern3bool = false;
            }
        }

        if (Pattern4bool == true && Deadbool == false)
        {
            PatternTime4 += Time.deltaTime;
            if (PatternTime4 > 0 && PatternTime4 < 0.4f)
            {
                if (MainCharacter.position.x > this.transform.position.x)
                {
                    if (WhereCharacterCheckbool == false)
                    {
                        this.transform.localScale = new Vector3(-6.5f, 6.5f, 6.5f);
                        WhereCharacterCheckbool = true;
                    }
                }
                else if (MainCharacter.position.x <= this.transform.position.x)
                {
                    if (WhereCharacterCheckbool == false)
                    {
                        this.transform.localScale = new Vector3(6.5f, 6.5f, 6.5f);
                        WhereCharacterCheckbool = true;
                    }
                }
                
                rb.velocity = Vector2.zero;
                animator.SetBool("FrontAttackBool", true);
            }
            if (PatternTime4 > 0.8f && PatternTime4 < 1.5f)
            {
                OneLegGroundAttackCollider.SetActive(true);
                Audios[5].SetActive(true);
            }
            if (PatternTime4 > 2.2f)
            {
                rb.velocity = Vector2.zero;
                animator.SetBool("FrontAttackBool", false);
                OneLegGroundAttackCollider.SetActive(false);
                Audios[5].SetActive(false);
                Idlebool = false;
                Decidedistancebool = false;
                PatternProgressbool = false;
                PatternDecidebool = false;
                IdleTime = 0;
                WhereCharacterCheckbool = false;
                Pattern4bool = false;
            }
        }

        if (Pattern5bool == true && Deadbool == false)
        {
            PatternTime5 += Time.deltaTime;
            if (PatternTime5 > 0 && PatternTime5 < 0.6f)
            {
                if (MainCharacter.position.x > this.transform.position.x)
                {
                    if (WhereCharacterCheckbool == false)
                    {
                        this.transform.localScale = new Vector3(-6.5f, 6.5f, 6.5f);
                        WhereCharacterCheckbool = true;
                    }
                }
                else if (MainCharacter.position.x <= this.transform.position.x)
                {
                    if (WhereCharacterCheckbool == false)
                    {
                        this.transform.localScale = new Vector3(6.5f, 6.5f, 6.5f);
                        WhereCharacterCheckbool = true;
                    }
                }
                
                rb.velocity = Vector2.zero;
                animator.SetBool("SpitBool", true);
            }
            if (PatternTime5 > 0.6f && PatternTime5 < 1f)
            {
                SpitCollider.SetActive(true);
                Audios[6].SetActive(true);
            }
            if (PatternTime5 > 1.9f)
            {
                rb.velocity = Vector2.zero;
                animator.SetBool("SpitBool", false);
                SpitCollider.SetActive(false);
                Audios[6].SetActive(false);
                Idlebool = false;
                Decidedistancebool = false;
                PatternProgressbool = false;
                PatternDecidebool = false;
                IdleTime = 0;
                WhereCharacterCheckbool = false;
                Pattern5bool = false;
            }
        }
    }

    private void AllReset()
    {
        if(MainCharacterController.Resetbool == true && Deadbool == false)
        {
            FirstMatchbool = false;
            FirstMatchTime = 0;
            FirstMatchTime2 = 0;
            for (int i = 0; i < Audios.Length; i++)
            {
                Audios[i].SetActive(false);
            }
            animator = GetComponent<Animator>();
            Deadbool = false;
            DeadTime = 0;
            HealthCanvas.SetActive(false);

            health = 300;
            hurtbool = false;
            BGMChangebool = false;
            BGMStopbool = false;
            DeadText.color = new Color(1, 1, 1, 0);
            BossNameText.color = new Color(1, 1, 1, 0);

            Spears[0].SetActive(false);
            Spears[1].SetActive(false);
            rb = GetComponent<Rigidbody2D>();
            RushEffect.SetActive(false);
            SR = GetComponent<SpriteRenderer>();
            SR.color = new Color(1, 1, 1, 1);
            this.transform.position = new Vector2(42.62f, 181f);

            
            groundbool = false;
            BelowBlock.SetActive(true);
            PatternStartbool = false;
            IdleTime = 0;
            Idlebool = false;
            PatternProgressbool = false;
            PatternDecidebool = false;
            AfterPatternDecidedbool = false;
            WalkCollider.SetActive(false);
            WhereCharacterCheckbool = false;
            RushCollider.SetActive(false);
            AirCollider.SetActive(false);
            Decidedistancebool = false;
            GroundAttackCollider.SetActive(false);
            SpitCollider.SetActive(false);
            OneLegGroundAttackCollider.SetActive(false);
            SpawnWavebool = false;
            WhereCharacterCheckbool = false;

            Pattern0bool = false;
            Pattern1bool = false;
            Pattern2bool = false;
            Pattern3bool = false;
            Pattern4bool = false;
            Pattern5bool = false;

            PatternTime0 = 0;
            PatternTime1 = 0;
            PatternTime2_1 = 0;
            PatternTime2_2 = 0;
            PatternTime3 = 0;
            PatternTime4 = 0;
            PatternTime5 = 0;

            this.transform.localScale = new Vector3(6.5f, 6.5f, 6.5f);

            animator.SetBool("SpitBool", false);
            animator.SetBool("FrontAttackBool", false);
            animator.SetBool("HighJumpBool", false);
            animator.SetBool("LowJumpBool", false);
            animator.SetBool("GroundAttachBool", false);
            animator.SetBool("RushReadyBool", false);
            animator.SetBool("RushBool", false);
            animator.SetBool("WalkBool", false);
            animator.Play("MiddleBoss2_Idle");
            AfterDeadbool = false;
        }
    }
        
}
