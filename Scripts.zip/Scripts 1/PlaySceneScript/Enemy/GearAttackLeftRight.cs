using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GearAttackLeftRight : MonoBehaviour
{
    public Rigidbody2D Gear1;
    public Rigidbody2D Gear2;
    public Rigidbody2D Gear3;

    public Vector3 Gear1Vec;
    public Vector3 Gear2Vec;
    public Vector3 Gear3Vec;

    private float MoveTime = 0;
    public float MoveSpeed;
    // Start is called before the first frame update
    void Start()
    {
        Gear1.transform.localPosition = Gear1Vec;
        Gear2.transform.localPosition = Gear2Vec;
        Gear3.transform.localPosition = Gear3Vec;
    }

    // Update is called once per frame
    void Update()
    {
        MoveTime += Time.deltaTime;
        if(MoveTime > 0 && MoveTime < 3)
        {
            Gear1.velocity = Vector2.right * MoveSpeed;
            Gear2.velocity = Vector2.left * MoveSpeed;
            Gear3.velocity = Vector2.right * MoveSpeed;
        }
        if (MoveTime > 3 && MoveTime < 8)
        {
            Gear1.velocity = Vector2.zero * MoveSpeed;
            Gear2.velocity = Vector2.zero * MoveSpeed;
            Gear3.velocity = Vector2.zero * MoveSpeed;

        }
        if (MoveTime > 8 && MoveTime < 11)
        {
            Gear1.velocity = Vector2.left * MoveSpeed;
            Gear2.velocity = Vector2.right * MoveSpeed;
            Gear3.velocity = Vector2.left * MoveSpeed;
        }
        if (MoveTime > 11 && MoveTime < 16)
        {
            Gear1.velocity = Vector2.zero * MoveSpeed;
            Gear2.velocity = Vector2.zero * MoveSpeed;
            Gear3.velocity = Vector2.zero * MoveSpeed;

        }
        if (MoveTime > 16)
        {
            Gear1.transform.localPosition = Gear1Vec;
            Gear2.transform.localPosition = Gear2Vec;
            Gear3.transform.localPosition = Gear3Vec;
            MoveTime = 0;
        }
    }
}
