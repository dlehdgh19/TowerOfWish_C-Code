using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Map15GearMove : MonoBehaviour
{
    public Rigidbody2D Gear1;
    public Rigidbody2D Gear2;
    public Rigidbody2D Gear3;
    public Rigidbody2D Gear4;
    public Rigidbody2D Gear5;
    public Rigidbody2D Gear6;
    public Rigidbody2D Gear7;
    public Rigidbody2D Gear8;

    public Vector3 Gear1Rigidbody2D;
    public Vector3 Gear2Rigidbody2D;
    public Vector3 Gear3Rigidbody2D;
    public Vector3 Gear4Rigidbody2D;
    public Vector3 Gear5Rigidbody2D;
    public Vector3 Gear6Rigidbody2D;
    public Vector3 Gear7Rigidbody2D;
    public Vector3 Gear8Rigidbody2D;

    private float TurningTime;
    // Start is called before the first frame leftdate
    void Start()
    {
        Gear1.transform.localPosition = Gear1Rigidbody2D;
        Gear2.transform.localPosition = Gear2Rigidbody2D;
        Gear3.transform.localPosition = Gear3Rigidbody2D;
        Gear4.transform.localPosition = Gear4Rigidbody2D;
        Gear5.transform.localPosition = Gear5Rigidbody2D;
        Gear6.transform.localPosition = Gear6Rigidbody2D;
        Gear7.transform.localPosition = Gear7Rigidbody2D;
        Gear8.transform.localPosition = Gear8Rigidbody2D;

        TurningTime = 0;
    }

    // leftdate is called once per frame
    void Update()
    {
        TurningTime += Time.deltaTime;
        if(TurningTime > 0 && TurningTime < 2)
        {
            Gear1.velocity = Vector2.right * 1.437f;
            Gear2.velocity = Vector2.right * 1.437f;
            Gear3.velocity = Vector2.right * 1.437f;
            Gear4.velocity = Vector2.right * 1.437f;
            Gear5.velocity = Vector2.right * 1.437f;
            Gear6.velocity = Vector2.right * 1.437f;
            Gear7.velocity = Vector2.right * 1.437f;
            Gear8.velocity = Vector2.right * 1.437f;
        }
        if (TurningTime > 2 && TurningTime < 4)
        {
            Gear1.velocity = Vector2.down * 1.437f;
            Gear2.velocity = Vector2.down * 1.437f;
            Gear3.velocity = Vector2.down * 1.437f;
            Gear4.velocity = Vector2.down * 1.437f;
            Gear5.velocity = Vector2.down * 1.437f;
            Gear6.velocity = Vector2.down * 1.437f;
            Gear7.velocity = Vector2.down * 1.437f;
            Gear8.velocity = Vector2.down * 1.437f;
        }
        if (TurningTime > 4 && TurningTime < 6)
        {
            Gear1.velocity = Vector2.left * 1.437f;
            Gear2.velocity = Vector2.left * 1.437f;
            Gear3.velocity = Vector2.left * 1.437f;
            Gear4.velocity = Vector2.left * 1.437f;
            Gear5.velocity = Vector2.left * 1.437f;
            Gear6.velocity = Vector2.left * 1.437f;
            Gear7.velocity = Vector2.left * 1.437f;
            Gear8.velocity = Vector2.left * 1.437f;
        }
        if (TurningTime > 6 && TurningTime < 8)
        {
            Gear1.velocity = Vector2.up * 1.437f;
            Gear2.velocity = Vector2.up * 1.437f;
            Gear3.velocity = Vector2.up * 1.437f;
            Gear4.velocity = Vector2.up * 1.437f;
            Gear5.velocity = Vector2.up * 1.437f;
            Gear6.velocity = Vector2.up * 1.437f;
            Gear7.velocity = Vector2.up * 1.437f;
            Gear8.velocity = Vector2.up * 1.437f;
        }
        if (TurningTime > 8)
        {
            Gear1.transform.localPosition = Gear1Rigidbody2D;
            Gear2.transform.localPosition = Gear2Rigidbody2D;
            Gear3.transform.localPosition = Gear3Rigidbody2D;
            Gear4.transform.localPosition = Gear4Rigidbody2D;
            Gear5.transform.localPosition = Gear5Rigidbody2D;
            Gear6.transform.localPosition = Gear6Rigidbody2D;
            Gear7.transform.localPosition = Gear7Rigidbody2D;
            Gear8.transform.localPosition = Gear8Rigidbody2D;
            TurningTime = 0;
        }
    }
}
