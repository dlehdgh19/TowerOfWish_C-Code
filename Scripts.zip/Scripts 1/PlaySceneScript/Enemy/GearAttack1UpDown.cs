using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GearAttack1UpDown : MonoBehaviour
{
    public Rigidbody2D Gear1;
    public Rigidbody2D Gear2;

    public Vector3 Gear1Vec;
    public Vector3 Gear2Vec;
    public Transform Gear2transform;

    private float MovingTime;
    public float MoveSpeed;
    // Start is called before the first frame update
    void Start()
    {
        MovingTime = 0;
        Gear1.transform.localPosition = Gear1Vec;
        Gear2.transform.localPosition = Gear2Vec;
    }

    // Update is called once per frame
    void Update()
    {
        MovingTime += Time.deltaTime;
        if(MovingTime > 0 && MovingTime < 2.5f)
        {
            Gear1.velocity = Vector2.down * MoveSpeed;
            Gear2.velocity = Vector2.up * MoveSpeed;
        }
        if (MovingTime > 2.5f && MovingTime < 3.5f)
        {
            Gear1.velocity = Vector2.zero * MoveSpeed;
            Gear2.velocity = Vector2.zero * MoveSpeed;
        }
        if (MovingTime > 3.5f && MovingTime < 6)
        {
            Gear2.velocity = Vector2.down * MoveSpeed;
            Gear1.velocity = Vector2.up * MoveSpeed;
        }
        if (MovingTime > 6 && MovingTime < 7)
        {
            Gear2.velocity = Vector2.zero * MoveSpeed;
            Gear1.velocity = Vector2.zero * MoveSpeed;
        }
        if (MovingTime > 7)
        {
            Gear1.transform.localPosition = Gear1Vec;
            Gear2.transform.localPosition = Gear2Vec;
            MovingTime = 0;
        }
    }
}
