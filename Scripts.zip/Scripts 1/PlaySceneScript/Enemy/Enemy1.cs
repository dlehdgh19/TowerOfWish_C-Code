using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy1 : MonoBehaviour
{
    [SerializeField]
    private Transform MainCharacter;

    private Animator animator;
    private SpriteRenderer SR;
    private float Hittime;
    private int health;
    private bool Deadbool;
    private bool CantHitbool;
    private bool Attackbool;
    private float AttackingTime;
    private bool Attackingbool;
    private bool lookbool;
    private Vector2 FirstPosition;

    public GameObject AttackCollider;

    [SerializeField]
    private GameObject[] Hiteffect;

    [SerializeField]
    private AudioSource[] HitAndDeadAudio;

    [SerializeField]
    private AudioSource SwingAttackAudio;

    private bool SwingAttackbool;


    private Rigidbody2D rb;
    public GameObject RayCastPos1;
    private RaycastHit2D ray1;
    private float Velocity_X;
    public float rayDist;
    // Start is called before the first frame update
    void Start()
    {
        
        Hittime = 0;
        AttackingTime = 0;
        animator = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        SR = GetComponent<SpriteRenderer>();
        animator.SetBool("StopBool", false);
        animator.SetBool("DeadBool", false);
        animator.SetBool("AttackBool", false);
        SR.color = new Color(1, 1, 1, 1);
        Deadbool = false;
        health = 100;
        FirstPosition = new Vector2(transform.position.x, transform.position.y);
        rb.velocity = new Vector2(1, 0);
        transform.localScale = new Vector3(5, 5, 5);
        AttackCollider.SetActive(false);
        SwingAttackbool = false;
    }

    // Update is called once per frame
    void Update()
    {
        Physics2D.IgnoreLayerCollision(16,19);
        Physics2D.IgnoreLayerCollision(7, 19);
        Physics2D.IgnoreLayerCollision(8, 19);
        Physics2D.IgnoreLayerCollision(9, 19);
        Physics2D.IgnoreLayerCollision(17, 19);
        Physics2D.IgnoreLayerCollision(18, 19);
        Physics2D.IgnoreLayerCollision(7, 17);
        Physics2D.IgnoreLayerCollision(8, 17);
        Physics2D.IgnoreLayerCollision(9, 17);
        Physics2D.IgnoreLayerCollision(7, 18);
        Physics2D.IgnoreLayerCollision(8, 18);
        Physics2D.IgnoreLayerCollision(9, 18);


        ray1 = Physics2D.Raycast(RayCastPos1.transform.position, Vector2.down, rayDist);
        if (ray1.collider == null && health > 0 && Attackbool == false && Attackingbool == false)
        {    
            rb.velocity = -rb.velocity;
            transform.localScale = new Vector3(-transform.localScale.x, 5, 5);
        }
        if(Attackbool == true && health > 0 && Deadbool == false)
        {
            AttackingTime += Time.deltaTime;
            if (MainCharacter.position.x > transform.position.x && lookbool == false)
            {
                transform.localScale = new Vector3(5, 5, 5);
                lookbool = true;
            }
            if (MainCharacter.position.x <= transform.position.x && lookbool == false)
            {
                transform.localScale = new Vector3(-5, 5, 5);
                lookbool = true;
            }
            if(AttackingTime > 0.5f && AttackingTime < 1f)
            {
                if (SwingAttackbool == false)
                {
                    SwingAttackAudio.Play();
                    SwingAttackbool = true;
                }
            }
            if (AttackingTime > 1f && AttackingTime < 1.5f)
            {
                if (SwingAttackbool == true)
                {
                    SwingAttackAudio.Play();
                    SwingAttackbool = false;
                }
            }
            if (AttackingTime > 0 && AttackingTime < 1.5f)
            {
                AttackCollider.SetActive(true);
                rb.velocity = new Vector2(0, 0);
                animator.SetBool("AttackBool", true);
            }
            if (AttackingTime > 1.5f && AttackingTime < 2.5f)
            {
                AttackCollider.SetActive(false);
                animator.SetBool("AttackBool", false);
                animator.SetBool("StopBool", true);
            }
            if (AttackingTime > 2.5f)
            {

                if(MainCharacter.position.x >= transform.position.x)
                {
                    animator.SetBool("StopBool", false);
                    rb.velocity = new Vector2(1, 0);
                    transform.localScale = new Vector3(5, 5, 5);
                    AttackingTime = 0;
                    Attackbool = false;
                    lookbool = false;
                }
                if (MainCharacter.position.x < transform.position.x)
                {
                    
                    animator.SetBool("StopBool", false);
                    rb.velocity = new Vector2(-1, 0);
                    transform.localScale = new Vector3(-5, 5, 5);
                    AttackingTime = 0;
                    lookbool = false;
                    Attackbool = false;
                }
            }
        }

        if(health <= 0 && Deadbool == true)
        {
            Attackbool = false;
            Hittime += Time.deltaTime;
            if(Hittime > 0 && Hittime < 1)
            {
                AttackCollider.SetActive(false);
                Velocity_X = rb.velocity.x;
                rb.velocity = new Vector2(0, 0);
                animator.SetBool("DeadBool", true);
            }
            if (Hittime > 3 && Hittime < 4)
            {
                SR.color = new Color(1, 1, 1, 0.5f);
            }
            if (Hittime > 4 && Hittime < 7)
            {
                SR.color = new Color(1, 1, 1, 0f);
            }
            if (Hittime > 7 && Hittime < 8)
            {
                SwingAttackbool = false;
                AttackCollider.SetActive(false);
                SR.color = new Color(1, 1, 1, 0.5f);
                transform.localScale = new Vector3(5, 5, 5);
                animator.SetBool("DeadBool", false);
                animator.SetBool("StopBool", false);
                animator.SetBool("AttackBool", false);
            }
            if (Hittime > 8)
            {
                
                rb.velocity = new Vector2(1, 0);
                SR.color = new Color(1, 1, 1, 1f);
                AttackingTime = 0;
                Hittime = 0;
                AttackingTime = 0;
                health = 100;
                Deadbool = false;
                lookbool = false;
                Attackbool = false;
            }
        }
    } 

     private void OnTriggerEnter2D(Collider2D collision)
     {

         if ((collision.tag == "Slash1" || collision.tag == "Slash2" || collision.tag == "Slash3") && Deadbool == false)
         {
             if (health > 0)
             {
                 Hittime = 0;
                 int damage = Random.Range(25, 40);
                 Instantiate(Hiteffect[Random.Range(0, 2)], this.gameObject.transform.position, Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360))));
                 HitAndDeadAudio[Random.Range(0, 2)].Play();
                 health = health - damage;
             }

             if (health <= 0)
             {
                 int damage = Random.Range(25, 40);
                 Instantiate(Hiteffect[Random.Range(0, 2)], this.gameObject.transform.position, Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360))));
                 health = health - damage;
                 HitAndDeadAudio[2].Play();
                 Deadbool = true;
            }
         }

         if(collision.tag == "Player")
         {
            
            Attackbool = true;
         }
     }

    private void OnTriggerStay2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            Attackbool = true;
        }
    }
}
