using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RightWaveAttack : MonoBehaviour
{
    private Rigidbody2D rb;
    public float RightSpeed;
    private float BiggerTime;
    // Start is called before the first frame update
    void Start()
    {
        BiggerTime = 0;
        rb = GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        Physics2D.IgnoreLayerCollision(16, 19);
        Physics2D.IgnoreLayerCollision(7, 19);
        Physics2D.IgnoreLayerCollision(8, 19);
        Physics2D.IgnoreLayerCollision(9, 19);
        Physics2D.IgnoreLayerCollision(17, 19);
        Physics2D.IgnoreLayerCollision(18, 19);
        Physics2D.IgnoreLayerCollision(7, 17);
        Physics2D.IgnoreLayerCollision(8, 17);
        Physics2D.IgnoreLayerCollision(9, 17);
        Physics2D.IgnoreLayerCollision(7, 18);
        Physics2D.IgnoreLayerCollision(8, 18);
        Physics2D.IgnoreLayerCollision(9, 18);

        BiggerTime += Time.deltaTime;
        if(BiggerTime > 0)
        {
            rb.velocity = Vector2.right * RightSpeed;
            transform.localScale = new Vector3(1 + BiggerTime * 3f, 5, 5);
        }
        if(BiggerTime > 2.5f)
        {
            Destroy(this.gameObject);
        }
        
    }

   
}
