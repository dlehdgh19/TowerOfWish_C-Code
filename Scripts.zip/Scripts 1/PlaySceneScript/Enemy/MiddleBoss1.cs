using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MiddleBoss1 : MonoBehaviour
{
    [SerializeField]
    private Transform MainCharacter;

    [SerializeField]
    private GameObject[] SideWalls;

    [SerializeField]
    private Transform MainCameraTransform;

    [SerializeField]
    private GameObject[] EffectAudio;

    [SerializeField]
    private GameObject[] Beams;

    [SerializeField]
    private GameObject[] HitEffect;

    [SerializeField]
    private AudioSource[] HitorDeadAudio;

    public GameObject ChargeAttack;

    public GameObject WaveAttackPrefab1;
    public GameObject WaveAttackPrefab2;
    private bool InstatiateOncebool;

    public Text BossNameText;
    public Slider HealthSlider;
    private int health;

    

    /*   ���� ����� ������
     
    EffectAudio[0] = BushAudio;
    EffectAudio[1] = 1ComboAudio;
    EffectAudio[2] = 2ComboAudio;
    EffectAudio[3] = 3ComboAudio;
    EffectAudio[4] = ChargeAudio;
    EffectAudio[5] = GroundAttackAudio;
    EffectAudio[6] = HugeAttackAudio;
    EffectAudio[7] = BeamAudio;
    EffectAudio[8] = DeadAudio;

    */


    private bool FirstMatchbool;
    private bool FirstMatchEndbool;
    private bool BGMOncePlaybool;
    public static bool BGMStopbool;
    public static bool BGMChangetoMiddleBoss1bool;
    private float FirstMatchTime;
    private Vector3 velocity = Vector3.zero;

    private Animator anim;
    private int RandomPatternInt;
    
    private Rigidbody2D rb;

    public GameObject ComboCollider;
    public GameObject GroundAttackCollider;

    private bool Detectedbool;
    private bool AttackProgressbool;
    private bool Pattern1bool;
    private bool Pattern2bool;
    private bool Pattern3bool;
    private bool Pattern4bool;
    private float PatternTime;
    private bool Instantiatebool;

    private bool Deadbool;
    private float DeadTime;
    private SpriteRenderer SR;

    public Text BossDeadText;
    // Start is called before the first frame update
    void Start()
    {
        anim = GetComponent<Animator>();
        GroundAttackCollider.SetActive(false);
        ComboCollider.SetActive(false);
        rb = GetComponent<Rigidbody2D>();
        FirstMatchbool = false;
        FirstMatchEndbool = false;
        FirstMatchTime = 0;

        for (int i = 0; i < EffectAudio.Length; i++)
        {
            EffectAudio[i].SetActive(false);
        }
        for (int i = 0; i < SideWalls.Length; i++)
        {
            SideWalls[i].SetActive(false);
        }
        for(int i = 0; i < Beams.Length; i++)
        {
            Beams[i].SetActive(false);
        }
        
        HealthSlider.value = 220;
        health = (int)HealthSlider.value;
        BGMChangetoMiddleBoss1bool = false;
        BGMStopbool = false;
        BGMOncePlaybool = false;
        Detectedbool = false;
        AttackProgressbool = false;
        PatternTime = 0;
        Instantiatebool = false;
        InstatiateOncebool = false;
        Deadbool = false;
        DeadTime = 0;
        ChargeAttack.SetActive(false);
        BossDeadText.color = new Color(0.8f, 0.8f, 0, 0);
        SR = GetComponent<SpriteRenderer>();
        BossNameText.color = new Color(1, 1, 1, 0);
    }

    // Update is called once per frame
    void Update()
    {
        if(MainCharacterController.Resetbool == true)
        {
            anim = GetComponent<Animator>();
            GroundAttackCollider.SetActive(false);
            ComboCollider.SetActive(false);
            rb = GetComponent<Rigidbody2D>();
            FirstMatchbool = false;
            FirstMatchEndbool = false;
            FirstMatchTime = 0;
            anim.Play("Idle1");
            for (int i = 0; i < EffectAudio.Length; i++)
            {
                EffectAudio[i].SetActive(false);
            }
            for (int i = 0; i < SideWalls.Length; i++)
            {
                SideWalls[i].SetActive(false);
            }
            for (int i = 0; i < Beams.Length; i++)
            {
                Beams[i].SetActive(false);
            }
            BossNameText.color = new Color(1, 1, 1, 0);
            HealthSlider.value = 220;
            health = (int)HealthSlider.value;
            BGMChangetoMiddleBoss1bool = false;
            BGMStopbool = false;
            BGMOncePlaybool = false;
            Detectedbool = false;
            AttackProgressbool = false;
            PatternTime = 0;
            Instantiatebool = false;
            InstatiateOncebool = false;
            Deadbool = false;
            DeadTime = 0;
            ChargeAttack.SetActive(false);
            anim.SetBool("GroundAttackBool", true);
            anim.SetBool("RunBool", false);
            anim.SetBool("ChargeBool", false);
            anim.SetBool("3ComboAttackBool", false);
            anim.SetBool("BeamAttackBool", false);
            anim.SetBool("GroundAttackBool", false);
            rb.velocity = Vector2.zero;
            transform.localScale = new Vector3(6.5f, 6.5f, 6.5f);
            this.transform.position = new Vector2(97.64f, 235.041f);

            Pattern1bool = false;
            Pattern2bool = false;
            Pattern3bool = false;
            Pattern4bool = false;
        }

        Physics2D.IgnoreLayerCollision(17, 18);
        Physics2D.IgnoreLayerCollision(7, 17);
        Physics2D.IgnoreLayerCollision(8, 17);
        Physics2D.IgnoreLayerCollision(9, 17);
        Physics2D.IgnoreLayerCollision(7, 18);
        Physics2D.IgnoreLayerCollision(8, 18);
        Physics2D.IgnoreLayerCollision(9, 18);

        FirstMatch();

        if (FirstMatchbool == true && MainCharacterController.Resetbool == false)
        {
            PlayButtonManager.CantPressPausebool = true;
            FirstMatchTime += Time.deltaTime;
            if (FirstMatchTime > 0f && FirstMatchTime < 0.5f)
            {
                MainCharacterController.CharacterCantMovebool = true;
                CameraFollow.CameraControlbool = true;
                BGMStopbool = true;
            }
            if (FirstMatchTime > 0.5f && FirstMatchTime < 1f)
            {
                CameraFollow.CameraControlbool = true;
            }
            if (FirstMatchTime >= 1f && FirstMatchTime < 3f)
            {
                MainCameraTransform.position = Vector3.SmoothDamp(MainCameraTransform.position, new Vector3(102.5f, 237, -10), ref velocity, 0.3f);
            }
            if (FirstMatchTime >= 3f && FirstMatchTime < 3.4f)
            {
                MainCameraTransform.position = new Vector3(102.5f, 237, -10);
                SideWalls[0].SetActive(true);
                SideWalls[1].SetActive(true);
                EffectAudio[0].SetActive(true);
            }


            if(FirstMatchTime >= 3.5f && FirstMatchTime < 4.5f)
            {
                BossNameText.color = new Color(1, 1, 1, FirstMatchTime - 3.5f);
            }
            if (FirstMatchTime >= 7.5f && FirstMatchTime < 8.5f)
            {
                BossNameText.color = new Color(1, 1, 1, 8.5f - FirstMatchTime);
            }
            if (FirstMatchTime >= 8.5f)
            {
                BossNameText.color = new Color(1, 1, 1, 0);
            }

            if (FirstMatchTime >= 3.4f && FirstMatchTime < 3.5f)
            {
                EffectAudio[0].SetActive(false);
            }
            if (FirstMatchTime >= 3.5f && FirstMatchTime < 3.9f)
            {
                SideWalls[2].SetActive(true);
                SideWalls[3].SetActive(true);
                EffectAudio[0].SetActive(true);
            }
            if (FirstMatchTime >= 3.9f && FirstMatchTime < 4f)
            {
                EffectAudio[0].SetActive(false);
            }
            if (FirstMatchTime >= 4f && FirstMatchTime < 4.4f)
            {
                SideWalls[4].SetActive(true);
                SideWalls[5].SetActive(true);
                EffectAudio[0].SetActive(true);
            }
            if (FirstMatchTime >= 4.4f && FirstMatchTime < 4.5f)
            {
                EffectAudio[0].SetActive(false);
            }
            if (FirstMatchTime >= 4.5f && FirstMatchTime < 4.9f)
            {
                SideWalls[6].SetActive(true);
                SideWalls[7].SetActive(true);
                EffectAudio[0].SetActive(true);
            }
            if (FirstMatchTime >= 4.9f && FirstMatchTime < 6f)
            {
                EffectAudio[0].SetActive(false);
            }
            if (FirstMatchTime >= 6f && FirstMatchTime < 7.5f)
            {
                anim.SetBool("FirstChargeBool", true);
                EffectAudio[4].SetActive(true);
            }
            if (FirstMatchTime >= 7.5f && FirstMatchTime < 8.08f)
            {
                anim.SetBool("FirstChargeBool", false);
                anim.SetBool("FirstGroundAttackBool",true);
                EffectAudio[4].SetActive(false);
                EffectAudio[5].SetActive(true);
            }
            if (FirstMatchTime > 8.08f)
            {
                anim.SetBool("FirstGroundAttackBool", false);
            }
            if (FirstMatchTime > 9f)
            {
                BossNameText.color = new Color(1, 1, 1, 0);
                EffectAudio[5].SetActive(false);
                FirstMatchEndbool = true;
                FirstMatchbool = false;
                FirstMatchTime = 0;
            }
        }

        if (FirstMatchEndbool == true && MainCharacterController.Resetbool == false && Deadbool == false)
        {
            PlayButtonManager.CantPressPausebool = true;
            MainCharacterController.CharacterCantMovebool = false;
            BGMStopbool = false;
            if (BGMOncePlaybool == false)
            {
                //HealthCanvas.SetActive(true);
                BGMChangetoMiddleBoss1bool = true;
                PlayPortalManager.BGMPlayOncebool = false;
                BGMOncePlaybool = true;
            }

            if(Detectedbool == false && AttackProgressbool == false && MainCharacterController.Resetbool == false)
            {
                if (MainCharacter.position.x >= transform.position.x)
                {
                    anim.SetBool("RunBool", true);
                    transform.localScale = new Vector3(6.5f, 6.5f, 6.5f);
                    rb.velocity = Vector2.right * 2.5f;
                }
                if (MainCharacter.position.x <= transform.position.x)
                {
                    anim.SetBool("RunBool", true);
                    transform.localScale = new Vector3(-6.5f, 6.5f, 6.5f);
                    rb.velocity = Vector2.left * 2.5f;
                }
            }
            if(Detectedbool == true && AttackProgressbool == false && MainCharacterController.Resetbool == false)
            {
                PatternTime = 0;
                InstatiateOncebool = false;
                rb.velocity = Vector2.zero;
                anim.SetBool("RunBool", false);
                anim.SetBool("ChargeBool", false);
                RandomPatternInt = Random.Range(1, 12);
                for (int i = 0; i < EffectAudio.Length; i++)
                {
                    EffectAudio[i].SetActive(false);
                }
                if (MainCharacter.position.x >= transform.position.x)
                {
                    transform.localScale = new Vector3(6.5f, 6.5f, 6.5f);
                }
                if (MainCharacter.position.x <= transform.position.x)
                {
                    transform.localScale = new Vector3(-6.5f, 6.5f, 6.5f);
                }
                AttackProgressbool = true;
            }

            if(AttackProgressbool == true && Pattern1bool == false && Pattern2bool == false && Pattern3bool == false && MainCharacterController.Resetbool == false)
            {
                switch(RandomPatternInt)
                {
                    case 1 :
                        Pattern1bool = true;
                        break;
                    case 2:
                        Pattern1bool = true;
                        break;
                    case 3:
                        Pattern1bool = true;
                        break;
                    case 4:
                        Pattern1bool = true;
                        break;
                    case 5:
                        Pattern2bool = true;
                        break;
                    case 6:
                        Pattern2bool = true;
                        break;
                    case 7:
                        Pattern3bool = true;
                        break;
                    case 8:
                        Pattern3bool = true;
                        break;
                    case 9:
                        Pattern4bool = true;
                        break;
                    case 10:
                        Pattern4bool = true;
                        break;
                    case 11:
                        Pattern4bool = true;
                        break;
                    default:
                        break;
                }
                
            }
            Pattern();
        }

        if (Deadbool == true)
        {
            DeadTime += Time.deltaTime;
            if (DeadTime > 0 && DeadTime < 0.9f)
            {
                CharacterUI_HP_SkillCoolDown.Revivebool = true;
                EffectAudio[0].SetActive(false);
                EffectAudio[1].SetActive(false);
                EffectAudio[2].SetActive(false);
                EffectAudio[3].SetActive(false);
                EffectAudio[4].SetActive(false);
                EffectAudio[5].SetActive(false);
                EffectAudio[6].SetActive(false);
                EffectAudio[7].SetActive(false);
                ComboCollider.SetActive(false);
                ChargeAttack.SetActive(false);
                anim.SetBool("DeadBool", true);
                anim.SetBool("GroundAttackBool", true);
                anim.SetBool("RunBool", false);
                anim.SetBool("ChargeBool", false);
                anim.SetBool("3ComboAttackBool", false);
                anim.SetBool("BeamAttackBool", false);
                anim.SetBool("GroundAttackBool", false);
                BGMStopbool = true;
                EffectAudio[8].SetActive(true);
                Beams[0].SetActive(false);
                Beams[1].SetActive(false);
                Beams[2].SetActive(false);
                Beams[3].SetActive(false);
                Beams[4].SetActive(false);
                Beams[5].SetActive(false);
                Beams[6].SetActive(false);
            }
            if (DeadTime > 0.9f && DeadTime < 3f)
            {
                SR.color = new Color(1, 1, 1, 0);
            }
            if (DeadTime > 3f && DeadTime < 5f)
            {
                //HealthCanvas.SetActive(false);
                EffectAudio[9].SetActive(true);
                BossDeadText.color = new Color(0.8f, 0.8f, 0, (DeadTime - 3) * 0.5f);
            }
            if (DeadTime > 8f && DeadTime < 11f)
            {
                BossDeadText.color = new Color(0.8f, 0.8f, 0, (11 - DeadTime) * 0.33f);
            }
            if (DeadTime > 11f && DeadTime < 12f)
            {
                BGMStopbool = false;
                BossDeadText.color = new Color(0.8f, 0.8f, 0, 0);
                CameraFollow.CameraControlbool = false;
                SideWalls[0].SetActive(false);
                SideWalls[1].SetActive(false);
                SideWalls[2].SetActive(false);
                SideWalls[3].SetActive(false);
                SideWalls[4].SetActive(false);
                SideWalls[5].SetActive(false);
                SideWalls[6].SetActive(false);
                SideWalls[7].SetActive(false);

            }
            if (DeadTime > 12f)
            {
                BGMChangetoMiddleBoss1bool = false;
                PlayButtonManager.CantPressPausebool = false;
                PlayButtonManager.BossesInt = 4;
                anim.SetBool("DeadBool", false);
                PlayPortalManager.MapInt = 13;
                PlayPortalManager.BGMPlayOncebool = false;
                this.gameObject.SetActive(false);
            }
        }

    }

    //if(anim.GetCurrentAnimatorStateInfo(0).IsName("BeamAttack1"))
    //if (anim.GetCurrentAnimatorStateInfo(0).IsName("Idle1"))
    //anim.GetCurrentAnimatorStateInfo(0).normalizedTime);
    private void FirstMatch()
    {
        if (MainCharacter.position.x < 109 && MainCharacter.position.y > 233 && MainCharacter.position.y < 243 && FirstMatchbool == false && FirstMatchEndbool == false)
        {
            FirstMatchbool = true;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if ((collision.tag == "Slash1" || collision.tag == "Slash2" || collision.tag == "Slash3") && Deadbool == false)
        {
            if (health > 0)
            {
                int damage = Random.Range(2, 4);
                Instantiate(HitEffect[Random.Range(0, 2)], this.gameObject.transform.position, Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360))));
                HitorDeadAudio[Random.Range(0, 2)].Play();
                health = health - damage;
                HealthSlider.value = health;
                health = (int)HealthSlider.value;
            }

            if (health <= 0)
            {
                int damage = Random.Range(2, 4);
                Instantiate(HitEffect[Random.Range(0, 2)], this.gameObject.transform.position, Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360))));
                health = health - damage;
                HealthSlider.value = health;
                health = (int)HealthSlider.value;
                Deadbool = true;
            }
        }
    }
    private void OnTriggerStay2D(Collider2D collision)
    {
        if(collision.tag == "Player" && Pattern1bool == false && Pattern2bool == false && Pattern3bool == false)
        {
            Detectedbool = true;
        }
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            Detectedbool = false;
        }
    }

    private void Pattern()
    {
        if(Pattern1bool == true && Deadbool == false)
        {
            rb.velocity = Vector2.zero;
            PatternTime += Time.deltaTime;
            if (PatternTime > 0 && PatternTime < 0.1f)
            {
                ComboCollider.SetActive(true);
                anim.SetBool("3ComboAttackBool", true);
            }
            if (PatternTime > 0.666f)
            {
                EffectAudio[1].SetActive(true);
            }
            if (PatternTime > 1.08f)
            {
                EffectAudio[2].SetActive(true);
            }
            if (PatternTime > 1.5f)
            {
                EffectAudio[3].SetActive(true);
            }
            if (PatternTime > 1.55f)
            {
                if(InstatiateOncebool == false)
                {
                    Instantiate(WaveAttackPrefab1, new Vector2((transform.position.x - 1), transform.position.y + 0.55f), Quaternion.identity);
                    Instantiate(WaveAttackPrefab2, new Vector2((transform.position.x + 1), transform.position.y + 0.55f), Quaternion.identity);
                    InstatiateOncebool = true;
                }
            }
            if (PatternTime > 2f)
            {
                ComboCollider.SetActive(false);
                anim.SetBool("3ComboAttackBool", false);
            }
            if (PatternTime > 2.4f)
            {
                Pattern1bool = false;
                Detectedbool = false;
                InstatiateOncebool = false;
                AttackProgressbool = false;
            }
        }
        if (Pattern2bool == true && Deadbool == false)
        {
            PatternTime += Time.deltaTime;
            if(PatternTime > 0f && PatternTime < 0.1f)
            {
                rb.velocity = Vector2.zero;
                anim.SetBool("BeamAttackBool", true);
            }
            if(PatternTime > 1.2f && PatternTime < 2.5f)
            {
                anim.SetBool("BeamAttackBool", false);
                Beams[0].SetActive(true);
                Beams[1].SetActive(true);
                Beams[2].SetActive(true);
                Beams[3].SetActive(true);
            }
            if (PatternTime > 1.8f && PatternTime < 1.9f)
            {
                EffectAudio[7].SetActive(true);
            }
            if (PatternTime > 2.5f && PatternTime < 2.6f)
            {
                Beams[0].SetActive(false);
                Beams[1].SetActive(false);
                Beams[2].SetActive(false);
                Beams[3].SetActive(false);
                EffectAudio[7].SetActive(false);
            }
            if (PatternTime > 2.6f && PatternTime < 3.9f)
            {
                Beams[4].SetActive(true);
                Beams[5].SetActive(true);
                Beams[6].SetActive(true);
            }
            if (PatternTime > 3.2f && PatternTime < 3.3f)
            {
                EffectAudio[7].SetActive(true);
            }
            if (PatternTime > 3.9f && PatternTime < 4f)
            {
                Beams[4].SetActive(false);
                Beams[5].SetActive(false);
                Beams[6].SetActive(false);
                EffectAudio[7].SetActive(false);
            }
            if (PatternTime > 4.1f)
            {
                Pattern2bool = false;
                Detectedbool = false;
                AttackProgressbool = false;
            }

        }
        if (Pattern3bool == true && Deadbool == false)
        {
            PatternTime += Time.deltaTime;
            if (PatternTime > 0f && PatternTime < 0.1f)
            {
                rb.velocity = Vector2.zero;
                anim.SetBool("BeamAttackBool", true);
            }
            if (PatternTime > 1.2f && PatternTime < 2.5f)
            {
                anim.SetBool("BeamAttackBool", false);
                Beams[4].SetActive(true);
                Beams[5].SetActive(true);
                Beams[6].SetActive(true);
            }
            if (PatternTime > 1.8f && PatternTime < 1.9f)
            {
                EffectAudio[7].SetActive(true);
            }
            if (PatternTime > 2.5f && PatternTime < 2.6f)
            {
                Beams[4].SetActive(false);
                Beams[5].SetActive(false);
                Beams[6].SetActive(false);
                EffectAudio[7].SetActive(false);
            }
            if (PatternTime > 2.6f && PatternTime < 3.9f)
            {
                Beams[0].SetActive(true);
                Beams[1].SetActive(true);
                Beams[2].SetActive(true);
                Beams[3].SetActive(true);
            }
            if (PatternTime > 3.1f && PatternTime < 3.2f)
            {
                EffectAudio[7].SetActive(true);
            }
            if (PatternTime > 3.9f && PatternTime < 4f)
            {
                Beams[0].SetActive(false);
                Beams[1].SetActive(false);
                Beams[2].SetActive(false);
                Beams[3].SetActive(false);
                EffectAudio[7].SetActive(false);
            }
            if (PatternTime > 4.1f)
            {
                Pattern3bool = false;
                Detectedbool = false;
                AttackProgressbool = false;
            }
        }

        if (Pattern4bool == true && Deadbool == false)
        {
            rb.velocity = Vector2.zero;
            PatternTime += Time.deltaTime;
            if (PatternTime > 0f && PatternTime < 1.5f)
            {
                EffectAudio[4].SetActive(true);
                anim.SetBool("ChargeBool", true);
            }
            if (PatternTime > 1.5f && PatternTime < 1.6f)
            {
                anim.SetBool("GroundAttackBool", true);
                EffectAudio[4].SetActive(false);
                ChargeAttack.SetActive(true);
            }
            if (PatternTime > 1.6f)
            {
                anim.SetBool("ChargeBool", false);
                EffectAudio[6].SetActive(true);
            }
            
            if (PatternTime > 1.8f)
            {
                if(InstatiateOncebool == false)
                {
                    Instantiate(WaveAttackPrefab1, new Vector2((transform.position.x - 1.5f), transform.position.y + 0.55f), Quaternion.identity);
                    Instantiate(WaveAttackPrefab2, new Vector2((transform.position.x + 1.5f), transform.position.y + 0.55f), Quaternion.identity);
                    InstatiateOncebool = true;
                }
            }
            if (PatternTime > 2.18f)
            {
                anim.SetBool("GroundAttackBool", false);
                ChargeAttack.SetActive(false);
            }
            if (PatternTime > 3)
            {
                EffectAudio[4].SetActive(false);
                EffectAudio[6].SetActive(false);
                Pattern4bool = false;
                Detectedbool = false;
                InstatiateOncebool = false;
                AttackProgressbool = false;
            }
        }
    }
}

