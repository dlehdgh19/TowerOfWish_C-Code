using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AxeExplosion : MonoBehaviour
{
    public float RotateSpeed;
    private SpriteRenderer SR;
    public GameObject EndObject;
    private float RotateTime;
    private Vector3 velocity = Vector3.zero;
    public GameObject SwingAudio;
    public GameObject BlastAudio;
    public Transform MainCharacterTransform;
    // Start is called before the first frame update
    private void OnEnable()
    {
        RotateTime = 0;
        EndObject.SetActive(false);
        SR = GetComponent<SpriteRenderer>();
        SR.color = new Color(1, 1, 1, 0);
        this.transform.localPosition = new Vector3(0.007f, -0.25f, 0);
        this.transform.rotation = Quaternion.Euler(0, 0, 0);
        GetComponent<CapsuleCollider2D>().enabled = false;
        SwingAudio.SetActive(false);
        BlastAudio.SetActive(false);
    }

    private void OnDisable()
    {
        RotateTime = 0;
        EndObject.SetActive(false);
        SR = GetComponent<SpriteRenderer>();
        SR.color = new Color(1, 1, 1, 0);
        this.transform.localPosition = new Vector3(0.007f, -0.25f, 0);
        this.transform.rotation = Quaternion.Euler(0, 0, 0);
        GetComponent<CapsuleCollider2D>().enabled = false;
        SwingAudio.SetActive(false);
        BlastAudio.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        Physics2D.IgnoreLayerCollision(7, 18);
        Physics2D.IgnoreLayerCollision(8, 18);
        Physics2D.IgnoreLayerCollision(9, 18);
        RotateTime += Time.deltaTime;
        if (RotateTime > 0 && RotateTime < 1)
        {
            GetComponent<CapsuleCollider2D>().enabled = false;
            SR.color = new Color(1, 1, 1, RotateTime);
        }
        if (RotateTime > 1 && RotateTime < 2)
        {
            GetComponent<CapsuleCollider2D>().enabled = false;
            SR.color = new Color(1, 1, 1, 1);
        }
        if (RotateTime > 2 && RotateTime < 7)
        {
            SwingAudio.SetActive(true);
            GetComponent<CapsuleCollider2D>().enabled = true;
            transform.Rotate(new Vector3(0f, 0f, 1f) * Time.deltaTime * RotateSpeed);
            transform.position = Vector3.SmoothDamp(transform.position, MainCharacterTransform.position, ref velocity, 0.9f);
        }
        if (RotateTime > 7 && RotateTime < 7.6f)
        {
            SR.color = new Color(1, 1, 1, 0);
            SwingAudio.SetActive(false);
            BlastAudio.SetActive(true);
            GetComponent<CapsuleCollider2D>().enabled = false;
            transform.Rotate(new Vector3(0f, 0f, 0f));
            EndObject.SetActive(true);
        }
        if (RotateTime > 7.6f)
        {
            EndObject.SetActive(false);
        }
        if (RotateTime > 8f)
        {
            SwingAudio.SetActive(false);
            BlastAudio.SetActive(false);
            this.gameObject.SetActive(false);
        }
    }
}
