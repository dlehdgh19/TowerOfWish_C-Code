using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LastBossAppear : MonoBehaviour
{
    public static bool BossAppearbool;
    public Transform MainCharacterTransform;
    // Start is called before the first frame update
    void Start()
    {
        BossAppearbool = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(MainCharacterTransform.position.y < 287 && PlayPortalManager.MapInt == 16 && BossAppearbool == false && LastBoss1.Deadbool == false)
        {
            BossAppearbool = true;
        }
    }

    
}
