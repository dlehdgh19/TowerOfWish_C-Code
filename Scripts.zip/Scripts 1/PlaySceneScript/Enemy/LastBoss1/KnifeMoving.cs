using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class KnifeMoving : MonoBehaviour
{
    public GameObject Knife;
    public SpriteRenderer RedLineSR;
    private float MovingTime;
    private int RandomInt;
    // Start is called before the first frame update
    

    private void OnEnable()
    {
        MovingTime = 0;
        RandomInt = Random.Range(0, 2);
        if (RandomInt == 0)
        {
            this.transform.rotation = Quaternion.Euler(0, 0, Random.Range(20, 160));
        }
        else if (RandomInt == 1)
        {
            this.transform.rotation = Quaternion.Euler(0, 0, Random.Range(200, 340));
        }

        Knife.transform.localPosition = new Vector3(20, 0, 0);
        RedLineSR.color = new Color(1, 1, 1, 1);
    }

    

    // Update is called once per frame
    void Update()
    {
        MovingTime += Time.deltaTime;
        if (MovingTime > 0 && MovingTime < 1.5f)
        {
            RedLineSR.color = new Color(1, 1, 1, 1);
            Knife.transform.localPosition = new Vector3(20, 0, 0);
        }
        if (MovingTime > 1.5f && MovingTime < 3.5f)
        {
            RedLineSR.color = new Color(1, 1, 1, 0);
            Knife.transform.localPosition = new Vector3((20 - (MovingTime - 1.5f) * 20), 0, 0);
        }
        
    }
}
