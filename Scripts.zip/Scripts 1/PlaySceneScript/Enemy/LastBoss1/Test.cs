using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Test : MonoBehaviour
{
    public GameObject Knife;
    public Rigidbody2D rb;
    private float MovingTime;
    // Start is called before the first frame update
    void Start()
    {
        MovingTime = 0;
        Knife.transform.localPosition = new Vector3(16, 0, 0);
    }

    // Update is called once per frame
    void Update()
    {
        MovingTime += Time.deltaTime;
        if (MovingTime > 0 && MovingTime < 2)
        {
            Knife.transform.localPosition = new Vector3(16, 0, 0);
        }
        if (MovingTime > 2 && MovingTime < 4)
        {
            Knife.transform.localPosition = new Vector3((16 - (MovingTime - 2) * 20), 0, 0);
        }
        if (MovingTime > 4)
        {
            Knife.transform.localPosition = new Vector3(16, 0, 0);
            MovingTime = 0;
        }
    }
}
