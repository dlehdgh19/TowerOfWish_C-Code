using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GroundAxe : MonoBehaviour
{
    private SpriteRenderer SR;
    private float ActiveTime;
    private float GroundTime;
    public GameObject GroundAttackAudio;
    public Transform WaveSpawnPosition;
    private Rigidbody2D rb;
    private bool Spawnbool;
    public GameObject LeftWave;
    public GameObject RightWave;
    
    // Start is called before the first frame update
    private void OnEnable()
    {
        GetComponent<CapsuleCollider2D>().enabled = false;
        SR = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
        SR.color = new Color(1, 1, 1, 0);
        ActiveTime = 0;
        GroundTime = 0;
        this.transform.localPosition = new Vector3(-0.007f, -0.18f, 0);
        GroundAttackAudio.SetActive(false);
        Spawnbool = false;
    }

    private void OnDisable()
    {
        GetComponent<CapsuleCollider2D>().enabled = false;
        SR = GetComponent<SpriteRenderer>();
        rb = GetComponent<Rigidbody2D>();
        SR.color = new Color(1, 1, 1, 0);
        ActiveTime = 0;
        GroundTime = 0;
        this.transform.localPosition = new Vector3(-0.007f, -0.18f, 0);
        GroundAttackAudio.SetActive(false);
    }

    // Update is called once per frame
    void Update()
    {
        Physics2D.IgnoreLayerCollision(7, 18);
        Physics2D.IgnoreLayerCollision(8, 18);
        Physics2D.IgnoreLayerCollision(9, 18);
        ActiveTime += Time.deltaTime;
        if(this.transform.position.y > -1.352f)
        {
            
            if (ActiveTime > 1 && ActiveTime < 2f)
            {
                
                SR.color = new Color(1, 1, 1, ActiveTime - 1);
            }
            if (ActiveTime > 2 && ActiveTime < 2.2f)
            {
                GetComponent<CapsuleCollider2D>().enabled = true;
                SR.color = new Color(1, 1, 1, 1);
            }
            if (ActiveTime > 2.2f && ActiveTime < 2.7f)
            {

                rb.AddForce(new Vector2(0,1)* 3);
            }
            if (ActiveTime > 2.7f && ActiveTime < 5f)
            {
                rb.AddForce(new Vector2(0, -1) * 10);
            }
        }

        if(this.transform.position.y <= 285.986f)
        {
            this.transform.position = new Vector3(this.transform.position.x, 285.986f, 0);
            GetComponent<CapsuleCollider2D>().enabled = false;
            GroundAttackAudio.SetActive(true);
            GroundTime += Time.deltaTime;
            if(GroundTime > 1 && GroundTime < 2)
            {
                SR.color = new Color(1, 1, 1, 2 - GroundTime);
            }
            if (GroundTime > 2)
            {
                SR.color = new Color(1, 1, 1, 0);
                this.gameObject.SetActive(false);
            }
            if(Spawnbool == false)
            {
                Instantiate(RightWave, new Vector3(WaveSpawnPosition.position.x + 1, WaveSpawnPosition.position.y + 0.6f, WaveSpawnPosition.position.z), Quaternion.Euler(new Vector3(0, 0, 0)));
                Instantiate(LeftWave, new Vector3(WaveSpawnPosition.position.x - 1, WaveSpawnPosition.position.y + 0.6f, WaveSpawnPosition.position.z), Quaternion.Euler(new Vector3(0, 0, 0)));
                Spawnbool = true;
            }
        }
    }

    
}
