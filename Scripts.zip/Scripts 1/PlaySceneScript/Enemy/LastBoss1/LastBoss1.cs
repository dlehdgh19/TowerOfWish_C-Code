using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class LastBoss1 : MonoBehaviour
{
    private Rigidbody2D rb;
    public Vector3 FirstPosition;
    private SpriteRenderer SR;
    public Transform MainCharacterTransform;
    public Transform MainCameraTransform;
    private float CameraShakeTime;
    private bool RandomCameraMovebool;
    public SpriteRenderer AppearBehindImage;
    private Animator anim;


    [SerializeField]
    private GameObject[] BattleAduio;

    //BattleAduio[0] = CastingAudio
    //BattleAduio[1] = EndCastAudio
    //BattleAduio[2] = KnifeAudio
    //BattleAduio[3] = SwordSlashAudio
    //BattleAduio[4] = AxeDownAudio
    //BattleAduio[5] = DisappearAudio
    //BattleAduio[6] = AppearAudio
    //BattleAduio[7] = HitAudio1
    //BattleAduio[8] = HitAudio2
    //BattleAduio[9] = DeadAudio
    //BattleAduio[10] = DeadTextAduio
    //BattleAduio[11] = FirstAppearAudio
    //BattleAduio[12] = SpineAudio
    //BattleAduio[13] = LighteningAudio
    //BattleAduio[14] = LozorAudio

    [SerializeField]
    private GameObject[] Spines;

    [SerializeField]
    private GameObject[] SpinesAlert;

    [SerializeField]
    private GameObject[] Lightening;

    [SerializeField]
    private GameObject[] SkyCast;

    [SerializeField]
    private GameObject[] LighteningAlert;

    [SerializeField]
    private GameObject RazorBackGround;

    [SerializeField]
    private GameObject[] Lazors;

    [SerializeField]
    private SpriteRenderer[] LazorSR;

    private int LighteningInt;
    private bool RandomLighteningbool;

    [SerializeField]
    private GameObject[] MagicCastBehind;

    [SerializeField]
    private SpriteRenderer[] MagicCastSR;

    [SerializeField]
    private GameObject[] Knife;

    

    public GameObject FollowAxe;
    public GameObject GroundAxe;
    private bool LazorRotationbool = false;

    private bool FirstMatchbool;
    private float FirstMatchTime;
    public static bool StopBGMbool;
    public static bool StartBGMbool1;
    private bool FirstStopbool;

    private bool PatternStartbool;

    private bool RandomPatternbool;
    private bool RandomPatternDecidebool;
    private float PatternDecideTime;
    private int RandomInt;
    private float PatternTime;
    private bool Pattern1bool;
    private bool Pattern2bool;
    private bool Pattern3bool;
    private bool Pattern4bool;
    private bool Pattern5bool;

    private bool KeepGoingbool;
    private int RandomKeepGoingInt;
    private bool KeepGoingDecidebool;
    private float KeepGoingTime;
    private bool KeepGoingPattern1bool;
    private bool KeepGoingPattern2bool;
    private bool KeepGoingPattern3bool;

    [SerializeField]
    private GameObject[] HitEffect;

    [SerializeField]
    private AudioSource[] HitAudio;

    public Text NameText;
    public GameObject HealthCanvas;
    public Slider HealthSlider;
    private int health;
    public static bool Deadbool;
    public static bool AfterLastBossDeadbool;
    private float DeadTime;

    public Text BossDeadText;
    

    // Start is called before the first frame update
    void Awake()
    {
        rb = GetComponent<Rigidbody2D>();
        SR = GetComponent<SpriteRenderer>();

        anim = GetComponent<Animator>();
        CameraShakeTime = 0;
        RandomCameraMovebool = false;
        FirstPosition = new Vector3(-2, 290.98f, 0);
        this.transform.position = FirstPosition;
        FirstMatchbool = false;
        FirstMatchTime = 0;
        StopBGMbool = false;
        StartBGMbool1 = false;
        for (int a = 0; a < BattleAduio.Length; a++)
        {
            BattleAduio[a].SetActive(false);
        }
        for (int b = 0; b < Spines.Length; b++)
        {
            Spines[b].SetActive(false);
        }
        for (int c = 0; c < MagicCastBehind.Length; c++)
        {
            MagicCastBehind[c].SetActive(false);
        }
        for (int d = 0; d < MagicCastSR.Length; d++)
        {
            MagicCastSR[d].color = new Color(1, 1, 1, 0);
        }
        for (int e = 0; e < Knife.Length; e++)
        {
            Knife[e].SetActive(false);
        }
        for (int f = 0; f < SpinesAlert.Length; f++)
        {
            SpinesAlert[f].SetActive(false);
        }
        for (int g = 0; g < Lightening.Length; g++)
        {
            Lightening[g].SetActive(false);
        }
        for (int h = 0; h < LighteningAlert.Length; h++)
        {
            LighteningAlert[h].SetActive(false);
        }
        for (int i = 0; i < SkyCast.Length; i++)
        {
            SkyCast[i].SetActive(false);
        }
        for (int j = 0; j < Lazors.Length; j++)
        {
            Lazors[j].GetComponent<BoxCollider2D>().enabled = false;
            Lazors[j].transform.localScale = new Vector3(10, 1, 10);
            Lazors[j].SetActive(false);
        }
        for (int k = 0; k < LazorSR.Length; k++)
        {
            LazorSR[k].color = new Color(1, 1, 1, 0.4f);
        }
        FollowAxe.SetActive(false);
        GroundAxe.SetActive(false);
        RazorBackGround.SetActive(false);

        LazorRotationbool = false;
        RandomLighteningbool = false;
        FirstStopbool = false;
        RandomPatternbool = false;
        RandomPatternDecidebool = false;
        PatternStartbool = false;
        PatternTime = 0;
        PatternDecideTime = 0;
        Pattern1bool = false;
        Pattern2bool = false;
        Pattern3bool = false;
        Pattern4bool = false;
        Pattern5bool = false;

        KeepGoingbool = false;
        KeepGoingTime = 0;
        KeepGoingDecidebool = false;
        KeepGoingPattern1bool = false;
        KeepGoingPattern2bool = false;
        KeepGoingPattern3bool = false;

        NameText.color = new Color(1, 1, 1, 0);
        HealthCanvas.SetActive(false);
        SR.color = new Color(1, 1, 1, 0);
        AppearBehindImage.color = new Color(1, 1, 1, 0);


        health = 270;
        HealthSlider.value = health;
        Deadbool = false;
        DeadTime = 0;
        AfterLastBossDeadbool = false;
        BossDeadText.color = new Color(1, 1, 1, 0);
        LastBossAppear.BossAppearbool = false;
    }

    // Update is called once per frame
    void Update()
    {
        if(LastBossAppear.BossAppearbool == true && FirstStopbool == false && Deadbool == false && MainCharacterController.Resetbool == false)
        {
            FirstMatchTime += Time.deltaTime;
            if (FirstMatchTime > 0f && FirstMatchTime < 1.5f)
            {
                PlayButtonManager.CantPressPausebool = true;
                MainCharacterController.CharacterCantMovebool = true;
                StopBGMbool = true;
            }
            if (FirstMatchTime > 1.5f && FirstMatchTime < 2.5f)
            {
                BattleAduio[11].SetActive(true);
                CameraFollow.CameraControlbool = true;
                CameraShake();
                MagicCastBehind[0].SetActive(true);
                AppearBehindImage.color = new Color(1, 1, 1, 1);
            }
            if (FirstMatchTime > 2.5f && FirstMatchTime < 3.5f)
            {
                CameraShake();
                HealthCanvas.SetActive(true);
                SR.color = new Color(1, 1, 1, FirstMatchTime - 2.5f);
                NameText.color = new Color(1, 1, 1, FirstMatchTime - 2.5f);
            }
            if (FirstMatchTime > 3.5f && FirstMatchTime < 4.5f)
            {
                CameraShake();
                AppearBehindImage.color = new Color(1, 1, 1, 4.5f - FirstMatchTime);
                SR.color = new Color(1, 1, 1, 1);
                NameText.color = new Color(1, 1, 1, 1);
            }
            if (FirstMatchTime > 4.5f && FirstMatchTime < 5.5f)
            {
                BattleAduio[11].SetActive(false);
                AppearBehindImage.color = new Color(1, 1, 1, 0);
                MagicCastBehind[0].SetActive(false);
            }
            if (FirstMatchTime > 5.5f && FirstMatchTime < 6.5f)
            {
                NameText.color = new Color(1, 1, 1, 6.5f - FirstMatchTime);

            }
            if (FirstMatchTime > 6.5f)
            {
                StopBGMbool = false;
                StartBGMbool1 = true;
                PlayPortalManager.BGMPlayOncebool = false;
                MainCharacterController.CharacterCantMovebool = false;
                CameraFollow.CameraControlbool = false;
                NameText.color = new Color(1, 1, 1, 0);
                FirstMatchTime = 0;
                RandomPatternbool = true;
                KeepGoingbool = true;
                PatternStartbool = true;
                FirstStopbool = true;
                FirstMatchTime = 0;
            }
        }


        if (RandomPatternbool == true && PatternStartbool == true && Deadbool == false && MainCharacterController.Resetbool == false)
        {
            FirstMatchTime = 0;
            RandomPattern();
        }

        if (KeepGoingbool == true && PatternStartbool == true && Deadbool == false && MainCharacterController.Resetbool == false)
        {
            FirstMatchTime = 0;
            KeepGoingPattern();
        }

        Dead();

        if(MainCharacterController.Resetbool == true)
        {
            rb = GetComponent<Rigidbody2D>();
            SR = GetComponent<SpriteRenderer>();

            anim = GetComponent<Animator>();
            CameraShakeTime = 0;
            RandomCameraMovebool = false;
            FirstPosition = new Vector3(-2, 290.98f, 0);
            this.transform.position = FirstPosition;
            FirstMatchbool = false;
            FirstMatchTime = 0;
            StopBGMbool = false;
            StartBGMbool1 = false;
            for (int a = 0; a < BattleAduio.Length; a++)
            {
                BattleAduio[a].SetActive(false);
            }
            for (int b = 0; b < Spines.Length; b++)
            {
                Spines[b].SetActive(false);
            }
            for (int c = 0; c < MagicCastBehind.Length; c++)
            {
                MagicCastBehind[c].SetActive(false);
            }
            for (int d = 0; d < MagicCastSR.Length; d++)
            {
                MagicCastSR[d].color = new Color(1, 1, 1, 0);
            }
            for (int e = 0; e < Knife.Length; e++)
            {
                Knife[e].SetActive(false);
            }
            for (int f = 0; f < SpinesAlert.Length; f++)
            {
                SpinesAlert[f].SetActive(false);
            }
            for (int g = 0; g < Lightening.Length; g++)
            {
                Lightening[g].SetActive(false);
            }
            for (int h = 0; h < LighteningAlert.Length; h++)
            {
                LighteningAlert[h].SetActive(false);
            }
            for (int i = 0; i < SkyCast.Length; i++)
            {
                SkyCast[i].SetActive(false);
            }
            for (int j = 0; j < Lazors.Length; j++)
            {
                Lazors[j].GetComponent<BoxCollider2D>().enabled = false;
                Lazors[j].transform.localScale = new Vector3(10, 1, 10);
                Lazors[j].SetActive(false);
            }
            for (int k = 0; k < LazorSR.Length; k++)
            {
                LazorSR[k].color = new Color(1, 1, 1, 0.4f);
            }
            FollowAxe.SetActive(false);
            GroundAxe.SetActive(false);
            RazorBackGround.SetActive(false);

            LazorRotationbool = false;
            RandomLighteningbool = false;
            FirstStopbool = false;
            RandomPatternbool = false;
            RandomPatternDecidebool = false;
            PatternStartbool = false;
            PatternTime = 0;
            PatternDecideTime = 0;
            Pattern1bool = false;
            Pattern2bool = false;
            Pattern3bool = false;
            Pattern4bool = false;
            Pattern5bool = false;

            KeepGoingbool = false;
            KeepGoingTime = 0;
            KeepGoingDecidebool = false;
            KeepGoingPattern1bool = false;
            KeepGoingPattern2bool = false;
            KeepGoingPattern3bool = false;

            NameText.color = new Color(1, 1, 1, 0);
            HealthCanvas.SetActive(false);
            SR.color = new Color(1, 1, 1, 0);
            AppearBehindImage.color = new Color(1, 1, 1, 0);


            health = 270;
            HealthSlider.value = health;
            Deadbool = false;
            DeadTime = 0;
            AfterLastBossDeadbool = false;
            BossDeadText.color = new Color(1, 1, 1, 0);

            LastBossAppear.BossAppearbool = false;

            anim.SetBool("TeleportBool", false);
            anim.SetBool("DeadBool", false);
        }
    }

    private void CameraShake()
    {
        CameraShakeTime += Time.deltaTime;
        if(CameraShakeTime > 0 && CameraShakeTime < 0.05f)
        {
            if(RandomCameraMovebool == false)
            {
                float A = Random.Range(0, 0.2f);
                MainCameraTransform.position = new Vector3(MainCameraTransform.position.x, MainCameraTransform.position.y + A, -10);
                RandomCameraMovebool = true;
            }
        }
        if (CameraShakeTime > 0.05f && CameraShakeTime < 0.1f)
        {
            if (RandomCameraMovebool == true)
            {
                float A = Random.Range(0, 0.2f);
                MainCameraTransform.position = new Vector3(MainCameraTransform.position.x, MainCameraTransform.position.y - A, -10);
                RandomCameraMovebool = false;
            }
        }
        if (CameraShakeTime > 0.1f)
        {
            RandomCameraMovebool = false;
            CameraShakeTime = 0;
        }
    }

    private void RandomPattern()
    {
        if(RandomPatternDecidebool == false)
        {
            PatternTime = 0;
            RandomInt = Random.Range(1, 9);
            RandomPatternDecidebool = true;
        }

        if(RandomPatternDecidebool == true)
        {
            switch (RandomInt)
            {
                case 1:
                    Pattern1bool = true;
                    break;
                case 2:
                    Pattern1bool = true;
                    break;
                case 3:
                    Pattern2bool = true;
                    break;
                case 4:
                    Pattern2bool = true;
                    break;
                case 5:
                    Pattern3bool = true;
                    break;
                case 6:
                    Pattern3bool = true;
                    break;
                case 7:
                    Pattern4bool = true;
                    break;
                case 8:
                    Pattern4bool = true;
                    break;
            }
        }

        if(Pattern1bool == true)    // FollowAxe
        {
            PatternTime += Time.deltaTime;
            if (PatternTime > 0f && PatternTime < 0.5f)
            {
                anim.SetBool("TeleportBool", true);
                BattleAduio[5].SetActive(true);
            }
            if (PatternTime > 0.5f && PatternTime < 1f)
            {
                SR.color = new Color(1, 1, 1, 0);
                this.transform.position = new Vector3(Random.Range(-12, 8), Random.Range(288, 292), 0);
            }
            if (PatternTime > 1f && PatternTime < 1.9f)
            {
                BattleAduio[6].SetActive(true);
                SR.color = new Color(1, 1, 1, 1);
            }
            if (PatternTime > 1.9f && PatternTime < 2)
            {
                anim.SetBool("TeleportBool", false);
            }

            if (PatternTime > 2 && PatternTime < 3f)
            {
                MagicCastBehind[4].SetActive(true);
            }
            if (PatternTime > 3 && PatternTime < 5f)
            {
                FollowAxe.SetActive(true);
            }
            if (PatternTime > 10 && PatternTime < 11f)
            {
                MagicCastBehind[4].SetActive(false);
            }
            if (PatternTime > 11f)
            {
                BattleAduio[5].SetActive(false);
                BattleAduio[6].SetActive(false);
                FollowAxe.SetActive(false);
                RandomPatternDecidebool = false;
                Pattern1bool = false;
                PatternTime = 0;
            }
        }

        if(Pattern2bool == true)   // GroundAxe
        {
            PatternTime += Time.deltaTime;
            
            if (PatternTime > 0f && PatternTime < 0.5f)
            {
                anim.SetBool("TeleportBool", true);
                BattleAduio[5].SetActive(true);
            }
            if (PatternTime > 0.5f && PatternTime < 1f)
            {
                SR.color = new Color(1, 1, 1, 0);
                this.transform.position = new Vector3(Random.Range(-12, 8), Random.Range(288, 292), 0);
            }
            if (PatternTime > 1f && PatternTime < 1.9f)
            {
                BattleAduio[6].SetActive(true);
                SR.color = new Color(1, 1, 1, 1);
            }
            if (PatternTime > 1.9f && PatternTime < 2)
            {
                anim.SetBool("TeleportBool", false);
            }
            if (PatternTime > 2f && PatternTime < 4)
            {
                MagicCastBehind[4].SetActive(true);
                GroundAxe.SetActive(true);
            }
            if (PatternTime > 4f && PatternTime < 7f)
            {
                MagicCastBehind[4].SetActive(false);
            }
            if (PatternTime > 7f)
            {
                BattleAduio[5].SetActive(false);
                GroundAxe.SetActive(false);
                RandomPatternDecidebool = false;
                Pattern2bool = false;
                PatternTime = 0;
            }
        }

        if (Pattern3bool == true)   //Just Teleport
        {
            PatternTime += Time.deltaTime;

            if (PatternTime > 0f && PatternTime < 0.5f)
            {
                anim.SetBool("TeleportBool", true);
                BattleAduio[5].SetActive(true);
            }
            if (PatternTime > 0.5f && PatternTime < 1f)
            {
                SR.color = new Color(1, 1, 1, 0);
                this.transform.position = new Vector3(Random.Range(-12, 8), Random.Range(288, 292), 0);
            }
            if (PatternTime > 1f && PatternTime < 1.9f)
            {
                BattleAduio[6].SetActive(true);
                SR.color = new Color(1, 1, 1, 1);
            }
            if (PatternTime > 1.9f && PatternTime < 2)
            {
                anim.SetBool("TeleportBool", false);
            }
            if (PatternTime > 2.5f)
            {
                BattleAduio[5].SetActive(false);
                BattleAduio[6].SetActive(false);
                RandomPatternDecidebool = false;
                Pattern3bool = false;
                PatternTime = 0;
            }
        }

        if (Pattern4bool == true)   // 8 direction , 2times Razors
        {
            PatternTime += Time.deltaTime;

            if (PatternTime > 0f && PatternTime < 0.5f)
            {
                anim.SetBool("TeleportBool", true);
                BattleAduio[5].SetActive(true);
            }
            if (PatternTime > 0.5f && PatternTime < 1f)
            {
                SR.color = new Color(1, 1, 1, 0);
                this.transform.position = new Vector3(Random.Range(-12, 8), Random.Range(291.8f, 292.4f), 0);
            }
            if (PatternTime > 1f && PatternTime < 1.9f)
            {
                BattleAduio[6].SetActive(true);
                SR.color = new Color(1, 1, 1, 1);
            }
            if (PatternTime > 1.9f && PatternTime < 2)
            {
                anim.SetBool("TeleportBool", false);
            }
            if (PatternTime > 2.5f && PatternTime < 3)
            {
                RazorBackGround.SetActive(true);
                if(LazorRotationbool == false)
                {
                    RazorBackGround.transform.rotation = Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360)));
                    LazorRotationbool = true;
                }
            }
            if (PatternTime > 3f && PatternTime < 4f)
            {
                
                for (int j = 0; j < Lazors.Length; j++)
                {
                    Lazors[j].GetComponent<BoxCollider2D>().enabled = false;
                    Lazors[j].transform.localScale = new Vector3(10, 1, 10);
                    Lazors[j].SetActive(true);
                }
                for (int k = 0; k < LazorSR.Length; k++)
                {
                    LazorSR[k].color = new Color(1, 1, 1, 0.4f);
                }
            }
            if (PatternTime > 4f && PatternTime < 4.5f)
            {
                BattleAduio[14].SetActive(true);
                for (int j = 0; j < Lazors.Length; j++)
                {
                    Lazors[j].GetComponent<BoxCollider2D>().enabled = true;
                    Lazors[j].transform.localScale = new Vector3(10, 5, 10);
                }
                for (int k = 0; k < LazorSR.Length; k++)
                {
                    LazorSR[k].color = new Color(1, 1, 1, 1f);
                }
            }
            if (PatternTime > 4.5f && PatternTime < 4.7f)
            {
                BattleAduio[14].SetActive(false);
                for (int j = 0; j < Lazors.Length; j++)
                {
                    Lazors[j].GetComponent<BoxCollider2D>().enabled = false;
                    Lazors[j].transform.localScale = new Vector3(10, 1, 10);
                    Lazors[j].SetActive(false);
                }
                for (int k = 0; k < LazorSR.Length; k++)
                {
                    LazorSR[k].color = new Color(1, 1, 1, 0.4f);
                }
                if (LazorRotationbool == true)
                {
                    RazorBackGround.transform.rotation = Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360)));
                    LazorRotationbool = false;
                }
            }
            if (PatternTime > 4.7f && PatternTime < 5.7f)
            {
                for (int j = 0; j < Lazors.Length; j++)
                {
                    Lazors[j].GetComponent<BoxCollider2D>().enabled = false;
                    Lazors[j].transform.localScale = new Vector3(10, 1, 10);
                    Lazors[j].SetActive(true);
                }
                for (int k = 0; k < LazorSR.Length; k++)
                {
                    LazorSR[k].color = new Color(1, 1, 1, 0.4f);
                }
            }
            if (PatternTime > 5.7f && PatternTime < 6.2f)
            {
                BattleAduio[14].SetActive(true);
                for (int j = 0; j < Lazors.Length; j++)
                {
                    Lazors[j].GetComponent<BoxCollider2D>().enabled = true;
                    Lazors[j].transform.localScale = new Vector3(10, 5, 10);
                }
                for (int k = 0; k < LazorSR.Length; k++)
                {
                    LazorSR[k].color = new Color(1, 1, 1, 1f);
                }
            }
            if (PatternTime > 6.2f && PatternTime < 6.4f)
            {
                BattleAduio[14].SetActive(false);

                for (int j = 0; j < Lazors.Length; j++)
                {
                    Lazors[j].GetComponent<BoxCollider2D>().enabled = false;
                    Lazors[j].transform.localScale = new Vector3(10, 1, 10);
                    Lazors[j].SetActive(false);
                }
                for (int k = 0; k < LazorSR.Length; k++)
                {
                    LazorSR[k].color = new Color(1, 1, 1, 0.4f);
                }
            }
            if (PatternTime > 6.6f && PatternTime < 6.8f)
            {
                RazorBackGround.SetActive(false);
            }
            if (PatternTime > 7f)
            {
                BattleAduio[5].SetActive(false);
                BattleAduio[6].SetActive(false);
                RandomPatternDecidebool = false;
                Pattern4bool = false;
                PatternTime = 0;
            }
        }
    }

    private void KeepGoingPattern()
    {
        if(KeepGoingDecidebool == false)
        {
            RandomKeepGoingInt = Random.Range(1, 4);
            KeepGoingDecidebool = true;
        }

        if(KeepGoingDecidebool == true)
        {
            switch(RandomKeepGoingInt)
            {
                case 1:
                    KeepGoingPattern1bool = true;
                    break;
                case 2:
                    KeepGoingPattern2bool = true;
                    break;
                case 3:
                    KeepGoingPattern3bool = true;
                    break;
            }
        }

        if (KeepGoingPattern1bool == true)
        {
            KeepGoingTime += Time.deltaTime;
            if (KeepGoingTime > 0 && KeepGoingTime < 1.6f)
            {
                BattleAduio[0].SetActive(true);
                MagicCastBehind[1].SetActive(true);
                MagicCastSR[0].color = new Color(1, 1, 1, 1);
            }
            if (KeepGoingTime > 1.6f && KeepGoingTime < 2.6f)
            {
                BattleAduio[0].SetActive(false);
                BattleAduio[1].SetActive(true);
                MagicCastSR[0].color = new Color(1, 1, 1, 2.6f - KeepGoingTime);
            }
            if (KeepGoingTime > 2.6f && KeepGoingTime < 3f)
            {
                MagicCastSR[0].color = new Color(1, 1, 1, 0);
                MagicCastBehind[1].SetActive(false);
            }
            if (KeepGoingTime > 3f && KeepGoingTime < 5f)
            {
                BattleAduio[1].SetActive(false);
                for (int e = 0; e < Knife.Length; e++)
                {
                    Knife[e].SetActive(true);
                }
            }
            if (KeepGoingTime > 5f && KeepGoingTime < 6f)
            {
                BattleAduio[2].SetActive(true);
            }
            if (KeepGoingTime > 6.5f && KeepGoingTime < 7f)
            {
                for (int e = 0; e < Knife.Length; e++)
                {
                    BattleAduio[2].SetActive(false);
                    Knife[e].SetActive(false);
                }
            }
            if (KeepGoingTime > 7.2f)
            {
                KeepGoingPattern1bool = false;
                KeepGoingDecidebool = false;
                KeepGoingTime = 0;
            }
        }

        if (KeepGoingPattern2bool == true)
        {
            KeepGoingTime += Time.deltaTime;
            if (KeepGoingTime > 0 && KeepGoingTime < 1.6f)
            {
                
                BattleAduio[0].SetActive(true);
                MagicCastBehind[2].SetActive(true);
                MagicCastSR[1].color = new Color(1, 1, 1, 1);
            }
            if (KeepGoingTime > 1.6f && KeepGoingTime < 2.6f)
            {
                BattleAduio[0].SetActive(false);
                BattleAduio[1].SetActive(true);
                MagicCastSR[1].color = new Color(1, 1, 1, 2.6f - KeepGoingTime);
            }
            if (KeepGoingTime > 2.6f && KeepGoingTime < 3f)
            {
                MagicCastSR[1].color = new Color(1, 1, 1, 0);
                MagicCastBehind[2].SetActive(false);
            }
            if (KeepGoingTime > 3f && KeepGoingTime < 4f)
            {
                
                for (int f = 0; f < Spines.Length; f++)
                {
                    SpinesAlert[f].SetActive(true);
                }
            }
            if (KeepGoingTime > 4f && KeepGoingTime < 5.7f)
            {
                for (int f = 0; f < Spines.Length; f++)
                {
                    SpinesAlert[f].SetActive(false);
                }
                BattleAduio[1].SetActive(false);
                for (int b = 0; b < Spines.Length; b++)
                {
                    Spines[b].SetActive(true);
                }
            }
            if (KeepGoingTime > 5f && KeepGoingTime < 5.5f)
            {
                BattleAduio[12].SetActive(true);
            }
            if (KeepGoingTime > 5.7f && KeepGoingTime < 8f)
            {
                for (int b = 0; b < Spines.Length; b++)
                {
                    Spines[b].SetActive(false);
                }
            }
            
            if (KeepGoingTime > 8f)
            {
                BattleAduio[12].SetActive(false);
                KeepGoingPattern2bool = false;
                KeepGoingDecidebool = false;
                KeepGoingTime = 0;
            }
        }

        if (KeepGoingPattern3bool == true)
        {
            KeepGoingTime += Time.deltaTime;
            if (KeepGoingTime > 0 && KeepGoingTime < 1.6f)
            {
                if (RandomLighteningbool == false)
                {
                    LighteningInt = Random.Range(1, 10);
                    RandomLighteningbool = true;
                }
                BattleAduio[0].SetActive(true);
                MagicCastBehind[3].SetActive(true);
                MagicCastSR[2].color = new Color(1, 1, 1, 1);
            }
            if (KeepGoingTime > 1.6f && KeepGoingTime < 2.6f)
            {
                BattleAduio[0].SetActive(false);
                BattleAduio[1].SetActive(true);
                MagicCastSR[2].color = new Color(1, 1, 1, 2.6f - KeepGoingTime);
            }
            if (KeepGoingTime > 2.6f && KeepGoingTime < 3f)
            {
                MagicCastSR[2].color = new Color(1, 1, 1, 0);
                MagicCastBehind[3].SetActive(false);
            }
            if (KeepGoingTime > 3f && KeepGoingTime < 4f)
            {
                RandomSkycast();
                LighteningAlertDecide();
            }
            
            if (KeepGoingTime > 4f && KeepGoingTime < 4.5f)
            {
                for (int h = 0; h < LighteningAlert.Length; h++)
                {
                    LighteningAlert[h].SetActive(false);
                }
                
                BattleAduio[1].SetActive(false);
            }
            if (KeepGoingTime > 4.5f && KeepGoingTime < 5.4f)
            {
                RandomLightening();
                BattleAduio[13].SetActive(true);
            }
            if (KeepGoingTime > 5.4f && KeepGoingTime < 6f)
            {
                for (int g = 0; g < Lightening.Length; g++)
                {
                    Lightening[g].SetActive(false);
                }
                for (int i = 0; i < SkyCast.Length; i++)
                {
                    SkyCast[i].SetActive(false);
                }
            }
            if (KeepGoingTime > 6f)
            {
                RandomLighteningbool = false;
                BattleAduio[13].SetActive(false);
                KeepGoingPattern3bool = false;
                KeepGoingDecidebool = false;
                KeepGoingTime = 0;
            }
        }
    }

    private void RandomLightening()
    {
        switch (LighteningInt)
        {
            case 1:
                Lightening[0].SetActive(true);
                Lightening[1].SetActive(true);
                Lightening[2].SetActive(true);
                break;
            case 2:
                Lightening[0].SetActive(true);
                Lightening[1].SetActive(true);
                Lightening[3].SetActive(true);
                break;
            case 3:
                Lightening[0].SetActive(true);
                Lightening[1].SetActive(true);
                Lightening[4].SetActive(true);
                break;
            case 4:
                Lightening[0].SetActive(true);
                Lightening[2].SetActive(true);
                Lightening[3].SetActive(true);
                break;
            case 5:
                Lightening[0].SetActive(true);
                Lightening[2].SetActive(true);
                Lightening[4].SetActive(true);
                break;
            case 6:
                Lightening[0].SetActive(true);
                Lightening[3].SetActive(true);
                Lightening[4].SetActive(true);
                break;
            case 7:
                Lightening[1].SetActive(true);
                Lightening[2].SetActive(true);
                Lightening[3].SetActive(true);
                break;
            case 8:
                Lightening[1].SetActive(true);
                Lightening[2].SetActive(true);
                Lightening[4].SetActive(true);
                break;
            case 9:
                Lightening[1].SetActive(true);
                Lightening[3].SetActive(true);
                Lightening[4].SetActive(true);
                break;
            case 10:
                Lightening[2].SetActive(true);
                Lightening[3].SetActive(true);
                Lightening[4].SetActive(true);
                break;
        }
    }

    private void LighteningAlertDecide()
    {
        switch (LighteningInt)
        {
            case 1:
                LighteningAlert[0].SetActive(true);
                LighteningAlert[1].SetActive(true);
                LighteningAlert[2].SetActive(true);
                break;
            case 2:
                LighteningAlert[0].SetActive(true);
                LighteningAlert[1].SetActive(true);
                LighteningAlert[3].SetActive(true);
                break;
            case 3:
                LighteningAlert[0].SetActive(true);
                LighteningAlert[1].SetActive(true);
                LighteningAlert[4].SetActive(true);
                break;
            case 4:
                LighteningAlert[0].SetActive(true);
                LighteningAlert[2].SetActive(true);
                LighteningAlert[3].SetActive(true);
                break;
            case 5:
                LighteningAlert[0].SetActive(true);
                LighteningAlert[2].SetActive(true);
                LighteningAlert[4].SetActive(true);
                break;
            case 6:
                LighteningAlert[0].SetActive(true);
                LighteningAlert[3].SetActive(true);
                LighteningAlert[4].SetActive(true);
                break;
            case 7:
                LighteningAlert[1].SetActive(true);
                LighteningAlert[2].SetActive(true);
                LighteningAlert[3].SetActive(true);
                break;
            case 8:
                LighteningAlert[1].SetActive(true);
                LighteningAlert[2].SetActive(true);
                LighteningAlert[4].SetActive(true);
                break;
            case 9:
                LighteningAlert[1].SetActive(true);
                LighteningAlert[3].SetActive(true);
                LighteningAlert[4].SetActive(true);
                break;
            case 10:
                LighteningAlert[2].SetActive(true);
                LighteningAlert[3].SetActive(true);
                LighteningAlert[4].SetActive(true);
                break;
        }
    }

    private void RandomSkycast()
    {
        switch (LighteningInt)
        {
            case 1:
                SkyCast[0].SetActive(true);
                SkyCast[1].SetActive(true);
                SkyCast[2].SetActive(true);
                break;
            case 2:
                SkyCast[0].SetActive(true);
                SkyCast[1].SetActive(true);
                SkyCast[3].SetActive(true);
                break;
            case 3:
                SkyCast[0].SetActive(true);
                SkyCast[1].SetActive(true);
                SkyCast[4].SetActive(true);
                break;
            case 4:
                SkyCast[0].SetActive(true);
                SkyCast[2].SetActive(true);
                SkyCast[3].SetActive(true);
                break;
            case 5:
                SkyCast[0].SetActive(true);
                SkyCast[2].SetActive(true);
                SkyCast[4].SetActive(true);
                break;
            case 6:
                SkyCast[0].SetActive(true);
                SkyCast[3].SetActive(true);
                SkyCast[4].SetActive(true);
                break;
            case 7:
                SkyCast[1].SetActive(true);
                SkyCast[2].SetActive(true);
                SkyCast[3].SetActive(true);
                break;
            case 8:
                SkyCast[1].SetActive(true);
                SkyCast[2].SetActive(true);
                SkyCast[4].SetActive(true);
                break;
            case 9:
                SkyCast[1].SetActive(true);
                SkyCast[3].SetActive(true);
                SkyCast[4].SetActive(true);
                break;
            case 10:
                SkyCast[2].SetActive(true);
                SkyCast[3].SetActive(true);
                SkyCast[4].SetActive(true);
                break;
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if ((collision.tag == "Slash1" || collision.tag == "Slash2" || collision.tag == "Slash3") && Deadbool == false)
        {
            if (health > 0)
            {
                int damage = Random.Range(2, 4);
                Instantiate(HitEffect[Random.Range(0, 2)],
                    (new Vector2(Random.Range(this.gameObject.transform.position.x - 0.2f, this.gameObject.transform.position.x + 0.2f),
                    Random.Range(this.gameObject.transform.position.y - 1f, this.gameObject.transform.position.y - 1.5f))),
                    Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360))));
                HitAudio[Random.Range(0, 2)].Play();
                health = health - damage;
            }
            if (health <= 0)
            {
                int damage = Random.Range(2, 4);
                Instantiate(HitEffect[Random.Range(0, 2)],
                    (new Vector2(Random.Range(this.gameObject.transform.position.x - 0.2f, this.gameObject.transform.position.x + 0.2f),
                    Random.Range(this.gameObject.transform.position.y - 1f, this.gameObject.transform.position.y - 1.5f))),
                    Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360))));
                health = health - damage;
                Deadbool = true;
            }
        }
    }

    private void Dead()
    {
        
        if(Deadbool == true)
        {
            BattleAduio[0].SetActive(false);
            BattleAduio[1].SetActive(false);
            BattleAduio[2].SetActive(false);
            BattleAduio[3].SetActive(false);
            BattleAduio[4].SetActive(false);
            BattleAduio[6].SetActive(false);
            BattleAduio[7].SetActive(false);
            BattleAduio[8].SetActive(false);
            BattleAduio[11].SetActive(false);
            BattleAduio[12].SetActive(false);
            BattleAduio[13].SetActive(false);
            BattleAduio[14].SetActive(false);
            for (int b = 0; b < Spines.Length; b++)
            {
                Spines[b].SetActive(false);
            }
            for (int c = 0; c < MagicCastBehind.Length; c++)
            {
                MagicCastBehind[c].SetActive(false);
            }
            for (int d = 0; d < MagicCastSR.Length; d++)
            {
                MagicCastSR[d].color = new Color(1, 1, 1, 0);
            }
            for (int e = 0; e < Knife.Length; e++)
            {
                Knife[e].SetActive(false);
            }
            for (int f = 0; f < SpinesAlert.Length; f++)
            {
                SpinesAlert[f].SetActive(false);
            }
            for (int g = 0; g < Lightening.Length; g++)
            {
                Lightening[g].SetActive(false);
            }
            for (int h = 0; h < LighteningAlert.Length; h++)
            {
                LighteningAlert[h].SetActive(false);
            }
            for (int i = 0; i < SkyCast.Length; i++)
            {
                SkyCast[i].SetActive(false);
            }
            for (int j = 0; j < Lazors.Length; j++)
            {
                Lazors[j].GetComponent<BoxCollider2D>().enabled = false;
                Lazors[j].transform.localScale = new Vector3(10, 1, 10);
                Lazors[j].SetActive(false);
            }
            for (int k = 0; k < LazorSR.Length; k++)
            {
                LazorSR[k].color = new Color(1, 1, 1, 0.0f);
            }
            FollowAxe.SetActive(false);
            GroundAxe.SetActive(false);
            RazorBackGround.SetActive(false);

            LazorRotationbool = false;
            RandomLighteningbool = false;
            FirstStopbool = false;
            RandomPatternbool = false;
            RandomPatternDecidebool = false;
            PatternStartbool = false;
            PatternTime = 0;
            PatternDecideTime = 0;
            Pattern1bool = false;
            Pattern2bool = false;
            Pattern3bool = false;
            Pattern4bool = false;
            Pattern5bool = false;

            KeepGoingbool = false;
            KeepGoingTime = 0;
            KeepGoingDecidebool = false;
            KeepGoingPattern1bool = false;
            KeepGoingPattern2bool = false;
            KeepGoingPattern3bool = false;



            DeadTime += Time.deltaTime;
            if (DeadTime > 0f && DeadTime < 0.5f)
            {
                StopBGMbool = true;
                anim.SetBool("TeleportBool", true);
                BattleAduio[5].SetActive(true);
            }
            if (DeadTime > 0.5f && DeadTime < 1f)
            {
                SR.color = new Color(1, 1, 1, 0);
                this.transform.position = new Vector3(-2f, 287.68f, 0);
            }
            if (DeadTime > 1f && DeadTime < 1.9f)
            {
                BattleAduio[6].SetActive(true);
                SR.color = new Color(1, 1, 1, 1);
            }
            if (DeadTime > 1.9f && DeadTime < 2)
            {
                anim.SetBool("TeleportBool", false);
            }
            if (DeadTime > 2f && DeadTime < 5.5f)
            {
                BattleAduio[9].SetActive(true);
                anim.SetBool("DeadBool", true);
            }
            if(DeadTime > 6.5f && DeadTime < 7.5f)
            {

                SR.color = new Color(1, 1, 1, 7.5f - DeadTime);
            }
            if (DeadTime > 7.5f && DeadTime < 9f)
            {
                BattleAduio[9].SetActive(false);
                SR.color = new Color(1, 1, 1, 0);
            }
            if (DeadTime > 9f && DeadTime < 10f)
            {
                BattleAduio[10].SetActive(true);
                BossDeadText.color = new Color(0.8f, 0.8f, 0, DeadTime - 9);
            }
            if (DeadTime > 10f && DeadTime < 13f)
            {
                BossDeadText.color = new Color(0.8f, 0.8f, 0, 1);
            }
            if (DeadTime > 13f && DeadTime < 14f)
            {
                BossDeadText.color = new Color(0.8f, 0.8f, 0, 14 - DeadTime);
            }
            if (DeadTime > 14f && DeadTime < 15f)
            {
                BattleAduio[10].SetActive(false);
                PlayButtonManager.nPCProgressInt = 4;
                StartBGMbool1 = false;
                StopBGMbool = false;
                AfterLastBossDeadbool = true;
                PlayPortalManager.BGMPlayOncebool = false;
                BossDeadText.color = new Color(0.8f, 0.8f, 0, 0);
                PlayButtonManager.CantPressPausebool = false;
            }
            if (DeadTime > 15f)
            {
                PlayButtonManager.BossesInt = 12;
            }
        }
    }
}
