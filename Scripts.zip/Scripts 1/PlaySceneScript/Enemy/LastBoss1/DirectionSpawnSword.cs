using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DirectionSpawnSword : MonoBehaviour
{
    public GameObject Sword1;
    public GameObject Sword2;
    public Transform SpawnPoint;
    public GameObject[] Alertline;
    private float SpawnTime;
    private bool Spawnbool;
    private bool Rotationbool;
    // Start is called before the first frame update
    private void OnEnable()
    {
        for(int i = 0; i < Alertline.Length; i++)
        {
            Alertline[i].SetActive(false);
        }
        SpawnTime = 0;
        Spawnbool = false;
        this.gameObject.transform.rotation = Quaternion.Euler(new Vector3(0, 0, Random.Range(0,360)));
        Rotationbool = false;
    }

    // Update is called once per frame
    void Update()
    {
        SpawnTime += Time.deltaTime;
        if(SpawnTime > 0 && SpawnTime < 0.5f)
        {
            for (int i = 0; i < Alertline.Length; i++)
            {
                Alertline[i].SetActive(true);
            }
        }
        if (SpawnTime > 0.5 && SpawnTime < 1f)
        {
            for (int i = 0; i < Alertline.Length; i++)
            {
                Alertline[i].SetActive(false);
            }
            if(Spawnbool == false)
            {
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 0)));
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 45)));
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 90)));
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 135)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 0)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 45)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 90)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 135)));
                Spawnbool = true;
            }
        }
        if(SpawnTime > 1f && SpawnTime < 3f)
        {
            if(Rotationbool == false)
            {
                this.gameObject.transform.rotation = Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360)));
                Rotationbool = true;
            }
        }
        if (SpawnTime > 3 && SpawnTime < 3.5f)
        {
            for (int i = 0; i < Alertline.Length; i++)
            {
                Alertline[i].SetActive(true);
            }
        }
        if (SpawnTime > 3.5f && SpawnTime < 4)
        {
            for (int i = 0; i < Alertline.Length; i++)
            {
                Alertline[i].SetActive(false);
            }
            if (Spawnbool == true)
            {
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 0)));
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 45)));
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 90)));
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 135)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 0)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 45)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 90)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 135)));
                Spawnbool = false;
            }
        }
        if (SpawnTime > 4f && SpawnTime < 6f)
        {
            if (Rotationbool == true)
            {
                this.gameObject.transform.rotation = Quaternion.Euler(new Vector3(0, 0, Random.Range(0, 360)));
                Rotationbool = false;
            }
        }
        if (SpawnTime > 6 && SpawnTime < 6.5f)
        {
            for (int i = 0; i < Alertline.Length; i++)
            {
                Alertline[i].SetActive(true);
            }
        }
        if (SpawnTime > 6.5f && SpawnTime < 7f)
        {
            for (int i = 0; i < Alertline.Length; i++)
            {
                Alertline[i].SetActive(false);
            }
            if (Spawnbool == false)
            {
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 0)));
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 45)));
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 90)));
                Instantiate(Sword1, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 135)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 0)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 45)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 90)));
                Instantiate(Sword2, SpawnPoint.position, Quaternion.Euler(new Vector3(0, 0, 135)));
                Spawnbool = true;
            }
        }

        if(SpawnTime > 8)
        {
            SpawnTime = 0;
            Rotationbool = false;
            SpawnTime = 0;
            //this.gameObject.SetActive(false);
        }
    }
}
