using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Rendering.Universal;

public class PlaySoundManager : MonoBehaviour
{
    [SerializeField]
    private AudioSource[] BGMAudio;

    [SerializeField]
    private AudioSource[] EffectAudio;

    public Slider BGMSlider;
    public Slider EffectSlider;
    public Slider GammaSlider;
    public Text BGMText;
    public Text EffectText;
    public Text GammaText;


    public Light2D GlobalLight2D;

    // Start is called before the first frame update
    void Start()
    {
        BGMSlider.value = SaveThings.BGMVolume;
        EffectSlider.value = SaveThings.EffectVolume;
        GammaSlider.value = SaveThings.GammaVolume;
    }

    // Update is called once per frame
    void Update()
    {
        SaveThings.BGMVolume = (int)BGMSlider.value;
        SaveThings.EffectVolume = (int)EffectSlider.value;
        SaveThings.GammaVolume = (int)GammaSlider.value;
        BGMText.text = ((int)BGMSlider.value).ToString() + "%";
        EffectText.text = ((int)EffectSlider.value).ToString() + "%";
        GammaText.text = ((int)GammaSlider.value).ToString() + "%";

        for (int i = 0; i < BGMAudio.Length; i++)
        {
            BGMAudio[i].volume = BGMSlider.value * 0.01f;
        }
        for (int i = 0; i < EffectAudio.Length; i++)
        {
            EffectAudio[i].volume = EffectSlider.value * 0.01f;
        }


        GlobalLight2D.intensity = 0.1f + GammaSlider.value * 0.018f;
    }
}
