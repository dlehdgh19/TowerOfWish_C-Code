using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class FirstGameMenuSecond : MonoBehaviour
{
    public SpriteRenderer TitleSR;
    public Transform TitleTransform;
    public GameObject Canvas;
    private float StartTime;
    private bool Startbool;
    // Start is called before the first frame update
    void Start()
    {
        StartTime = 0;
        TitleSR.color = new Color(1, 1, 1, 0);
        TitleTransform.position = new Vector3(0, 5.2f, 0);
        Canvas.SetActive(false);
        Startbool = false;
    }

    // Update is called once per frame
    void Update()
    {
        StartTime += Time.deltaTime;
        if(StartTime > 1f && StartTime < 3f)
        {
            TitleTransform.position = new Vector3(0, 4.5f - (StartTime * 0.2f), 0);
            TitleSR.color = new Color(1, 1, 1, (StartTime - 1) * 0.5f);
            
        }
        if (StartTime > 3 && Startbool == false)
        {
            TitleSR.color = new Color(1, 1, 1, 1);
            Canvas.SetActive(true);
            Startbool = true;
        }
    }
}
