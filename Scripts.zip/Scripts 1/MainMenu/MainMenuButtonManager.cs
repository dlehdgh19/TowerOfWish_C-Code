using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using UnityEngine.Rendering.Universal;

public class MainMenuButtonManager : MonoBehaviour
{
    [SerializeField]
    private GameObject[] Canvas;

    /*
     
    Canvas[0] = ���θ޴���ư��
    Canvas[1] = ���ν��ۼ���â
    Canvas[2] = �������� �������� ��Ʃ���� �������� �������� ���ϴ� â
    Canvas[3] = ����ϱ� â
    Canvas[4] = ���� ��� â
    Canvas[5] = ���� â
    
    */

    public AudioSource MainBGM;
    public AudioSource ButtonSound;
    public Light2D GlobalLight2D;
    private int CanvasInt;

    public Text BGMVolumeText;
    public Text EffectVolumeText;
    public Text GammaVolumeText;
    public Slider BGMVolumeSlider;
    public Slider EffectVolumeSlider;
    public Slider GammaVolumeSlider;
    public static int BGMVolume;
    public static int EffectVolume;
    public static int GammaVolume;

    private float ScreenTime;
    public SpriteRenderer BlackScreen;
    private bool ToturialScreenbool;

    private int GoSceneInt;

    private bool ResumeYesbool;

    public GameObject ResumeGoButton;
    public SpriteRenderer TitleSR;

    // Start is called before the first frame update

    private void Awake()
    {
        if (!PlayerPrefs.HasKey("Saved"))
        {
            BGMVolumeSlider.value = 50;
            EffectVolumeSlider.value = 50;
            GammaVolumeSlider.value = 50;
        }
        if(PlayerPrefs.HasKey("Saved"))
        {
            SaveThings.SaveString = PlayerPrefs.GetString("Saved");
            BGMVolumeSlider.value = PlayerPrefs.GetInt("BGMVolume");
            EffectVolumeSlider.value = PlayerPrefs.GetInt("EffectVolume");
            GammaVolumeSlider.value = PlayerPrefs.GetInt("GammaVolume");
            PlayerPrefs.GetFloat("X_Position");
            PlayerPrefs.GetFloat("Y_Position");
            PlayerPrefs.GetFloat("Z_Position");
        }
    }

    void Start()
    {
        for(int i = 1; i < CanvasInt; i++)
        {
            Canvas[i].SetActive(false);
        }
        Canvas[0].SetActive(false);
        MainBGM.Play();

        ScreenTime = 0;
        ToturialScreenbool = false;
        GoSceneInt = 0;
        ResumeYesbool = false;
    }

    // Update is called once per frame
    void Update()
    {

        if(!PlayerPrefs.HasKey("Saved"))
        {
            ResumeGoButton.SetActive(false);
        }
        else if(PlayerPrefs.HasKey("Saved"))
        {
            ResumeGoButton.SetActive(true);
        }
        BGMVolumeText.text = (int)BGMVolumeSlider.value + "%";
        EffectVolumeText.text = (int)EffectVolumeSlider.value + "%";
        GammaVolumeText.text = (int)GammaVolumeSlider.value + "%";

        BGMVolume = (int)BGMVolumeSlider.value;
        EffectVolume = (int)EffectVolumeSlider.value;
        GammaVolume = (int)GammaVolumeSlider.value;
        
        if(ToturialScreenbool == true)
        {
            TitleSR.color = new Color(1, 1, 1, 0);
            ScreenTime += Time.deltaTime;
            if(ScreenTime > 0 && ScreenTime <= 1)
            {
                BlackScreen.color = new Color(0, 0, 0, ScreenTime);
            }
            if(ScreenTime > 1)
            {
                BlackScreen.color = new Color(0, 0, 0, 1);
                ToturialScreenbool = false;
                ScreenTime = 0;
                if(GoSceneInt == 1)
                {
                    SaveThings.SceneSerialNum = 1;
                    GoSceneInt = 0;
                    SceneManager.LoadScene("ToturialScene");
                }
                else if (GoSceneInt == 2)
                {
                    SaveThings.SceneSerialNum = 2;
                    GoSceneInt = 0;
                    SceneManager.LoadScene("PlayScene");
                }
                
            }
        }

        if(ResumeYesbool == true)
        {
            TitleSR.color = new Color(1, 1, 1, 0);
            ScreenTime += Time.deltaTime;
            if (ScreenTime > 0 && ScreenTime <= 1)
            {
                BlackScreen.color = new Color(0, 0, 0, ScreenTime);
            }
            if (ScreenTime > 1)
            {
                BlackScreen.color = new Color(0, 0, 0, 1);
                ToturialScreenbool = false;
                ScreenTime = 0;
                if (GoSceneInt == 2)
                {
                    SaveThings.SceneSerialNum = 2;
                    GoSceneInt = 0;
                    SceneManager.LoadScene("PlayScene");
                }
            }
        }

        MainBGM.volume = BGMVolumeSlider.value * 0.01f;
        ButtonSound.volume = EffectVolumeSlider.value * 0.01f;
        GlobalLight2D.intensity = 0.1f + GammaVolumeSlider.value * 0.018f;
    }

    public void NewStartCanvasButton()
    {
        Canvas[1].SetActive(true);
        Canvas[0].SetActive(false);
        ButtonSound.Play();
    }

    public void NewStartYesButton()
    {
        PlayerPrefs.DeleteAll();
        BGMVolumeSlider.value = 50;
        EffectVolumeSlider.value = 50;
        GammaVolumeSlider.value = 50;
        Canvas[2].SetActive(true);
        Canvas[1].SetActive(false);
        ButtonSound.Play();
    }

    public void MainMenuButton()
    {
        Canvas[0].SetActive(true);
        Canvas[1].SetActive(false);
        Canvas[2].SetActive(false);
        Canvas[3].SetActive(false);
        Canvas[4].SetActive(false);
        Canvas[5].SetActive(false);
        ButtonSound.Play();
    }

    public void ToturialtProgressButton()
    {
        ButtonSound.Play();
        ToturialScreenbool = true;
        Canvas[0].SetActive(false);
        Canvas[1].SetActive(false);
        Canvas[2].SetActive(false);
        Canvas[3].SetActive(false);
        Canvas[4].SetActive(false);
        Canvas[5].SetActive(false);
        GoSceneInt = 1;
    }

    public void ToturialNoProgressButton()
    {
        ButtonSound.Play();
        ToturialScreenbool = true;
        Canvas[0].SetActive(false);
        Canvas[1].SetActive(false);
        Canvas[2].SetActive(false);
        Canvas[3].SetActive(false);
        Canvas[4].SetActive(false);
        Canvas[5].SetActive(false);
        GoSceneInt = 2;
    }

    public void ResumeCanvasButton()
    {
        Canvas[0].SetActive(false);
        Canvas[3].SetActive(true);
        ButtonSound.Play();
    }

    public void ResumeYesButton()
    {
        Canvas[3].SetActive(false);
        ButtonSound.Play();
        ResumeYesbool = true;
        GoSceneInt = 2;
    }

    public void HowtoPlayButton()
    {
        Canvas[0].SetActive(false);
        Canvas[4].SetActive(true);
        ButtonSound.Play();
    }

    public void SettingButton()
    {
        Canvas[0].SetActive(false);
        Canvas[5].SetActive(true);
        ButtonSound.Play();
    }

    public void ExitButton()
    {
        ButtonSound.Play();
        Application.Quit();
    }
}
