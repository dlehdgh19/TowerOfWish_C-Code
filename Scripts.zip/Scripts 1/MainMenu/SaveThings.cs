using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SaveThings : MonoBehaviour
{
    public static int BGMVolume;
    public static int EffectVolume;
    public static int GammaVolume;
    public static int SceneSerialNum;

    public static bool Savebool;

    public static string SaveString;
    private static List<string> dontDestroyObjects = new List<string>();
    // Start is called before the first frame update
    void Start()
    {
        //BGMVolume = MainMenuButtonManager.BGMVolume;
        //EffectVolume = MainMenuButtonManager.EffectVolume;
        //GammaVolume = MainMenuButtonManager.GammaVolume;
        SceneSerialNum = 0;
    }

    private void Awake()
    {
        if(dontDestroyObjects.Contains(gameObject.name))
        {
            Destroy(gameObject);
            return;
        }

        dontDestroyObjects.Add(gameObject.name);
        DontDestroyOnLoad(gameObject);
        
    }

    // Update is called once per frame
    void Update()
    {
        if(SceneSerialNum == 0)
        {
            BGMVolume = MainMenuButtonManager.BGMVolume;
            EffectVolume = MainMenuButtonManager.EffectVolume;
            GammaVolume = MainMenuButtonManager.GammaVolume;
        }

        if (SceneSerialNum == 2)
        {
            PlayerPrefs.SetInt("BGMVolume", BGMVolume);
            PlayerPrefs.SetInt("EffectVolume", EffectVolume);
            PlayerPrefs.SetInt("GammaVolume", GammaVolume);
        }
    }

    public void Save()
    {
        Savebool = true;

    }

    public void Load()
    {
        

    }

    public void Delete()
    {
        PlayerPrefs.DeleteAll();
    }
}
